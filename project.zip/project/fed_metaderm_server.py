"""
fed_metaderm_server.py
----------------------
Server-Side Orchestration for Fed-MetaDerm:
- Global Model Initialization
- Federated NAS (Neural Architecture Search - Eq. 3)
- Federated Meta-Learning (Prototypical Episodes - Eqs. 4-5)
- PROPOSED RUPA: Rarity- & Uncertainty-Aware Prototype Aggregation (Eqs. 13-15)
- Secure Aggregation:
    * SMPC (additive secret sharing over Z_{2^61})
    * Paillier Homomorphic Encryption (slot-packed prototype encryption)
    * Differential Privacy (L2 clipping + Gaussian noise + zCDP accountant)
    * Blockchain Ledger (SHA-256 hash chain with Merkle root)
    * PBFT Consensus Voting (n = 3f + 1 validators)
"""

import os
import json
import time
import copy
import hashlib
from typing import Dict, List, Tuple, Optional
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import pandas as pd
from PIL import Image
from torchvision import transforms

from model import FedMetaDermClientModel
from federated_nas import federated_nas, candidates_from_space, DEFAULT_SPACE
from federated_meta import federated_meta_learning as proto_federated_meta, EpisodeSampler
from rupa import (
    global_class_frequency, rarity_score, data_contribution,
    uncertainty_from_reliability, rupa_weights, aggregate_prototypes_plain
)
from secure_aggregation import (
    SecureAggregationServer, BlockchainLedger, PBFTCluster,
    ClientUpload, KeyAuthority, prepare_client_upload,
    float_keys, flatten, unflatten
)


# ---------------------------------------------------------------------------
# Legacy Support Utilities (for backwards compatibility)
# ---------------------------------------------------------------------------
class SimpleCNN(nn.Module):
    """Lightweight CNN architecture used for fast validation and legacy support."""
    def __init__(self, num_classes=7, hidden_dim=64, width=64, depth=2, **kwargs):
        super().__init__()
        dim = hidden_dim if hidden_dim != 64 else width
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.pool = nn.MaxPool2d(2, 2)
        self.gap = nn.AdaptiveAvgPool2d((1, 1))
        self.fc1 = nn.Linear(64, dim)
        self.fc2 = nn.Linear(dim, num_classes)

    def extract_features(self, x):
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        x = self.gap(x)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x):
        feat = self.extract_features(x)
        return self.fc2(feat)


class HospitalDataset(Dataset):
    def __init__(self, csv_path, images_dir, class_to_idx, image_size=224):
        self.df = pd.read_csv(csv_path)
        self.images_dir = Path(images_dir)
        self.class_to_idx = class_to_idx

        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        self.samples = []
        id_col = "image_id" if "image_id" in self.df.columns else self.df.columns[0]
        dx_col = "dx" if "dx" in self.df.columns else "label"

        for _, row in self.df.iterrows():
            fname = str(row[id_col])
            lbl = str(row[dx_col])
            img_path = self.images_dir / fname
            if not img_path.exists():
                candidates = list(self.images_dir.glob(f"**/{fname}*"))
                if candidates:
                    img_path = candidates[0]
            if img_path.exists() and lbl in self.class_to_idx:
                self.samples.append((str(img_path), self.class_to_idx[lbl]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label


def build_class_index(csv_paths):
    all_classes = set()
    for p in csv_paths:
        df = pd.read_csv(p)
        dx_col = "dx" if "dx" in df.columns else "label"
        all_classes.update(df[dx_col].dropna().unique().tolist())
    return {c: i for i, c in enumerate(sorted(all_classes))}


# ---------------------------------------------------------------------------
# Module 1: Federated NAS (Neural Architecture Search) - Eq. (3)
# ---------------------------------------------------------------------------
def federated_nas_search(hospital_data, num_classes: int, device,
                         candidates=None, search_epochs: int = 1,
                         steps: int = 20, pretrained: bool = True,
                         verbose: bool = True, **kwargs):
    """
    Executes Federated NAS on the client architecture space:
        A* = argmin_A sum_i p_i * l_i( w_i(A), D_i ),   p_i = |D_i| / sum_j |D_j|
    """
    print("[FedNAS] Starting Federated Neural Architecture Search across hospitals...")
    
    # If passed in DataLoader format, adapt to hospital_data list of dicts
    adapted = []
    if isinstance(hospital_data, list) and len(hospital_data) > 0 and isinstance(hospital_data[0], dict) and "train_loader" in hospital_data[0]:
        adapted = hospital_data
    elif isinstance(hospital_data, list):
        # List of train_loaders
        for loader in hospital_data:
            mask = torch.ones(num_classes, dtype=torch.bool)
            size = len(loader.dataset) if hasattr(loader, "dataset") else 100
            adapted.append({
                "train_loader": loader,
                "val_loader": loader,
                "present_mask": mask,
                "size": size,
            })
    else:
        raise ValueError("Invalid hospital_data structure for federated_nas")

    space = None
    if candidates is not None and isinstance(candidates, dict):
        space = candidates
    elif candidates is not None and isinstance(candidates, list) and len(candidates) > 0:
        if isinstance(candidates[0], dict) and "backbone_name" in candidates[0]:
            # Convert candidate list to search space
            space = {
                "backbone_name": list({c["backbone_name"] for c in candidates if "backbone_name" in c}),
                "feature_dim": list({c.get("feature_dim", 256) for c in candidates}),
                "dropout_p": list({c.get("dropout_p", 0.3) for c in candidates}),
            }

    best_cand, table = federated_nas(
        hospital_data=adapted,
        num_classes=num_classes,
        device=device,
        space=space,
        steps=steps,
        pretrained=pretrained,
        verbose=verbose,
    )
    return best_cand


# ---------------------------------------------------------------------------
# Module 2: Federated Meta-Learning (Prototypical Episodes) - Eqs. (4)-(5)
# ---------------------------------------------------------------------------
def federated_meta_learning(global_model, datasets, device,
                            meta_rounds: int = 2, episodes: int = 20,
                            n_way: int = 5, k_shot: int = 5, q_query: int = 5,
                            weights: Optional[List[float]] = None,
                            lr: float = 1e-4, seed: int = 42,
                            verbose: bool = True, **kwargs):
    """
    Prototypical Federated Meta-Learning across hospital edge datasets.
    """
    print(f"[Meta-Learning] Running {meta_rounds} Federated Prototypical Meta-Learning rounds...")
    if isinstance(global_model, int):
        global_model = FedMetaDermClientModel(num_classes=global_model).to(device)
    else:
        global_model = global_model.to(device)

    # If passed DataLoaders instead of Datasets, extract datasets
    clean_datasets = []
    for d in datasets:
        if hasattr(d, "dataset"):
            clean_datasets.append(d.dataset)
        else:
            clean_datasets.append(d)

    if weights is None:
        weights = [1.0 / len(clean_datasets)] * len(clean_datasets)

    try:
        global_model, history = proto_federated_meta(
            global_model=global_model,
            datasets=clean_datasets,
            weights=weights,
            device=device,
            rounds=meta_rounds,
            episodes=episodes,
            n_way=n_way,
            k_shot=k_shot,
            q_query=q_query,
            lr=lr,
            seed=seed,
            verbose=verbose,
        )
    except Exception as e:
        print(f"[Meta-Learning] Episodic meta-learning fallback ({e}), using Reptile on loaders...")
        # Graceful fallback to reptile if dataset has too few classes per client
        beta = 0.5
        for r in range(meta_rounds):
            w_sum = {k: torch.zeros_like(v) for k, v in global_model.state_dict().items()}
            for ds in clean_datasets:
                loc = copy.deepcopy(global_model)
                opt = torch.optim.SGD(loc.parameters(), lr=0.01)
                loader = DataLoader(ds, batch_size=16, shuffle=True)
                loc.train()
                for step, (x, y) in enumerate(loader):
                    if step >= 3:
                        break
                    x, y = x.to(device), y.to(device)
                    opt.zero_grad()
                    loss = F.cross_entropy(loc(x), y)
                    loss.backward()
                    opt.step()
                for k, v in loc.state_dict().items():
                    w_sum[k] += v
            avg = {k: v / len(clean_datasets) for k, v in w_sum.items()}
            new_st = {}
            for k, v in global_model.state_dict().items():
                new_st[k] = v + beta * (avg[k] - v)
            global_model.load_state_dict(new_st)

    return global_model


# ---------------------------------------------------------------------------
# Module 8: RUPA Adaptive Weighting - Eqs. (13)-(15)
# ---------------------------------------------------------------------------
def compute_rupa_weights(client_updates, hospital_rarity_scores=None, *args, **kwargs):
    """
    Computes exact RUPA weights:
      r_i   = sum_c (q_ic / pi_c)           (Eq. 13)
      rho_i = |D_i| / sum_j |D_j|           (Data contribution)
      u_i   = mean MC-dropout entropy       (Predictive uncertainty)
      w_i   = (r_i^gamma * rho_i) / (u_i + eps)  (Eq. 14)
    """
    if isinstance(client_updates, list) and len(client_updates) > 0 and isinstance(client_updates[0], dict):
        rarities = []
        rhos = []
        uncertainties = []

        total_samples = sum(c.get("num_samples", 100) for c in client_updates)
        for i, up in enumerate(client_updates):
            r = up.get("rarity_score")
            if r is None:
                r = hospital_rarity_scores[i] if (hospital_rarity_scores and i < len(hospital_rarity_scores)) else 1.0
            rarities.append(float(r))

            n = up.get("num_samples", 100)
            rhos.append(float(n) / max(total_samples, 1))

            u = up.get("uncertainty")
            if u is None:
                rel = up.get("reliability_score", 1.0)
                u = uncertainty_from_reliability(rel)
            uncertainties.append(float(u))

        weights = rupa_weights(rarities, rhos, uncertainties)
        return weights
    else:
        # Fallback signature: losses, rarities, sample_counts
        losses = client_updates
        rarities = hospital_rarity_scores if hospital_rarity_scores else [1.0] * len(losses)
        sample_counts = args[0] if args else [100] * len(losses)
        tot = sum(sample_counts) or 1
        rhos = [n / tot for n in sample_counts]
        weights = rupa_weights(rarities, rhos, [max(l, 0.01) for l in losses])
        return weights


# ---------------------------------------------------------------------------
# Module 10: Secure Aggregation Server
# (SMPC + Paillier HE + DP + Blockchain Audit + PBFT Consensus)
# ---------------------------------------------------------------------------
def secure_aggregate_round(client_updates, rupa_weights_list,
                           server: Optional[SecureAggregationServer] = None,
                           global_state: Optional[dict] = None,
                           num_smpc_parties: int = 3,
                           dp_epsilon: float = 1.0,
                           dp_clip_norm: float = 1.0,
                           dp_sigma: float = 0.01,
                           num_pbft_validators: int = 4,
                           paillier_bits: int = 512,
                           ledger: Optional[BlockchainLedger] = None,
                           round_num: int = 1, **kwargs):
    """
    Full cryptographic aggregation round:
      1. DP clipping and Gaussian noise perturbation with zCDP accountant
      2. SMPC additive secret sharing of model parameters over Z_{2^61}
      3. Paillier Homomorphic Encryption of disease class prototypes
      4. PBFT validator consensus vote (3f+1)
      5. SHA-256 Blockchain ledger audit with Merkle root logging
    """
    # Initialize SecureAggregationServer if not provided
    if server is None:
        server = SecureAggregationServer(
            num_parties=num_smpc_parties,
            paillier_bits=paillier_bits,
            clip_norm=dp_clip_norm,
            sigma=dp_sigma,
            pbft_validators=num_pbft_validators,
        )

    # Reference state
    if global_state is None:
        if isinstance(client_updates[0], dict) and "state_dict" in client_updates[0]:
            global_state = client_updates[0]["state_dict"]
        else:
            global_state = client_updates[0]

    # Convert client updates to ClientUpload packages if not already converted
    uploads = []
    for i, c_up in enumerate(client_updates):
        if isinstance(c_up, ClientUpload):
            uploads.append(c_up)
        else:
            loc_state = c_up["state_dict"] if isinstance(c_up, dict) and "state_dict" in c_up else c_up
            protos = c_up.get("prototypes", {}) if isinstance(c_up, dict) else {}
            rel = c_up.get("reliability_score", 0.9) if isinstance(c_up, dict) else 0.9
            u = c_up.get("uncertainty", uncertainty_from_reliability(rel)) if isinstance(c_up, dict) else 0.1
            r = c_up.get("rarity_score", 1.0) if isinstance(c_up, dict) else 1.0
            rho = rupa_weights_list[i] if i < len(rupa_weights_list) else 1.0 / len(client_updates)

            upload = prepare_client_upload(
                client_id=i,
                round_num=round_num,
                local_state=loc_state,
                global_state=global_state,
                prototypes=protos,
                r=r,
                rho=rho,
                u=u,
                num_parties=server.m,
                authority_pk=server.pk,
                slots=server.slots,
                clip_norm=dp_clip_norm,
                sigma=dp_sigma,
            )
            uploads.append(upload)

    # Server aggregate
    agg_res = server.aggregate(
        round_num=round_num,
        global_state=global_state,
        uploads=uploads,
        weight_fn=lambda r_l, rho_l, u_l: rupa_weights(r_l, rho_l, u_l),
    )

    # Sync ledger if external reference was supplied
    if ledger is not None:
        ledger.chain = server.ledger.chain

    # Consensus format
    consensus = {
        "accepted": len(agg_res["accepted"]) > 0,
        "agreement_count": sum(1 for v in agg_res["pbft"].values() if v.get("accepted")),
        "num_validators": num_pbft_validators,
        "pbft_details": agg_res["pbft"],
    }

    return {
        "global_state": agg_res["global_state"],
        "global_prototypes": agg_res["global_prototypes"],
        "consensus": consensus,
        "accepted": agg_res["accepted"],
        "epsilon": agg_res.get("epsilon"),
        "timing": agg_res.get("timing"),
        "server": server,
    }
