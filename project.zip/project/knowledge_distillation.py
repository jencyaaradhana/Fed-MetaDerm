"""
knowledge_distillation.py
--------------------------
Implements "Uncertainty-Guided Knowledge Distillation" (orange box):

  Global Model (Teacher) → Personalized Hospital Model (Student)

Standard KD (Hinton et al.) transfers the teacher's soft probability
distribution to the student. The *uncertainty-guided* variant adds a
per-sample gate: if the TEACHER itself is uncertain (high MC-Dropout
entropy), that sample's soft-label contribution is down-weighted —
avoiding distillation from noisy teacher predictions on hard/ambiguous
cases, which is especially important for rare tail-class images.

Loss = alpha * KL(soft_teacher || soft_student)
     + (1-alpha) * CE(hard_labels, student_logits)
     * uncertainty_gate(sample)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from config import Config
from uncertainty import mc_dropout_predict


# -----------------------------------------------------------------------
# Soft labels
# -----------------------------------------------------------------------
def soft_labels(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    """Returns temperature-scaled softmax probabilities."""
    return F.softmax(logits / temperature, dim=-1)


# -----------------------------------------------------------------------
# KD Loss (Hinton et al.)
# -----------------------------------------------------------------------
def kd_loss(student_logits: torch.Tensor,
            teacher_logits: torch.Tensor,
            hard_labels: torch.Tensor,
            alpha: float = Config.KD_ALPHA,
            temperature: float = Config.KD_TEMPERATURE,
            sample_weights: torch.Tensor = None) -> torch.Tensor:
    """
    Combined KD loss:
      soft_loss = KL(soft_teacher || soft_student)  * T²
      hard_loss = CrossEntropy(student_logits, hard_labels)
      total     = alpha * soft_loss + (1-alpha) * hard_loss

    sample_weights: (B,) per-sample multiplier from uncertainty gating.
                    None = uniform (standard KD).
    """
    T = temperature
    s_soft = F.log_softmax(student_logits / T, dim=-1)
    t_log_soft = F.log_softmax(teacher_logits.detach() / T, dim=-1)

    # KL divergence per sample with log_target=True prevents 0 * -inf = NaN
    kl_per_sample = F.kl_div(s_soft, t_log_soft, reduction="none", log_target=True).sum(dim=-1)

    if sample_weights is not None:
        kl_per_sample = kl_per_sample * sample_weights.to(kl_per_sample.device)

    soft_loss = kl_per_sample.mean() * (T ** 2)
    hard_loss = F.cross_entropy(student_logits, hard_labels)

    loss = alpha * soft_loss + (1.0 - alpha) * hard_loss
    return torch.nan_to_num(loss, nan=0.0)


# -----------------------------------------------------------------------
# Uncertainty gating
# -----------------------------------------------------------------------
@torch.no_grad()
def compute_uncertainty_gate(teacher, images: torch.Tensor,
                               threshold_quantile: float = Config.KD_UNCERTAINTY_GATE,
                               T: int = 10) -> torch.Tensor:
    """
    Runs MC-Dropout on the teacher model to estimate per-sample predictive
    entropy. Returns a gate weight in [0, 1] for each sample:
      - low-entropy (confident teacher) → gate ≈ 1.0 (use fully)
      - high-entropy (uncertain teacher) → gate → 0.0 (down-weight)

    Args:
        teacher            : teacher model (FedMetaDermClientModel)
        images             : (B, C, H, W) image batch on device
        threshold_quantile : entropy percentile above which gate = 0
        T                  : number of MC-Dropout passes

    Returns:
        gates : (B,) float tensor in [0, 1]
    """
    mean_probs, entropy, _, _ = mc_dropout_predict(teacher, images, T=T)
    # Normalize entropy to [0, 1] within this batch
    e_min, e_max = entropy.min(), entropy.max()
    if e_max - e_min < 1e-6:
        return torch.ones(images.size(0))
    norm_entropy = (entropy - e_min) / (e_max - e_min)

    # Gate: 1 if entropy below threshold quantile, linearly decay above
    thresh = torch.quantile(norm_entropy, threshold_quantile)
    gate = torch.clamp(1.0 - (norm_entropy - thresh) / (1.0 - thresh + 1e-6), 0.0, 1.0)
    return gate


# -----------------------------------------------------------------------
# Full distillation training loop
# -----------------------------------------------------------------------
def run_knowledge_distillation(teacher_model,
                                student_model,
                                train_loader,
                                cfg: Config = Config,
                                epochs: int = None,
                                verbose: bool = True,
                                max_batches: int = None) -> nn.Module:
    """
    Uncertainty-Guided Knowledge Distillation:
      - teacher = global model (after RUPA aggregation)
      - student = personalized hospital model

    Only the student's classification head is updated; backbone is frozen
    to keep distillation fast and privacy-preserving.

    Args:
        teacher_model : FedMetaDermClientModel (global, frozen)
        student_model : FedMetaDermClientModel (personalized, being refined)
        train_loader  : hospital's local DataLoader
        cfg           : Config
        epochs        : override cfg.KD_EPOCHS
        max_batches   : optional batch limit for fast mode smoke testing

    Returns:
        Refined student_model (in-place, also returned for clarity).
    """
    epochs = epochs or cfg.KD_EPOCHS
    device = cfg.DEVICE

    teacher_model.to(device).eval()   # teacher never updated
    for p in teacher_model.parameters():
        p.requires_grad = False

    # Only fine-tune student's head (backbone frozen)
    student_model.to(device)
    for p in student_model.backbone.parameters():
        p.requires_grad = False
    for p in [*student_model.feature_proj.parameters(),
              *student_model.classifier.parameters()]:
        p.requires_grad = True

    trainable = [p for p in student_model.parameters() if p.requires_grad]
    optimizer = AdamW(trainable, lr=cfg.KD_LR, weight_decay=cfg.WEIGHT_DECAY)
    scheduler = CosineAnnealingLR(optimizer, T_max=max(epochs, 1))

    print(f"\n[KD] Uncertainty-Guided Knowledge Distillation: {epochs} epochs")
    print(f"     temperature={cfg.KD_TEMPERATURE}, alpha={cfg.KD_ALPHA}, "
          f"gate_quantile={cfg.KD_UNCERTAINTY_GATE}")

    for ep in range(1, epochs + 1):
        student_model.train()
        total_loss, total_correct, n = 0.0, 0, 0

        for b_idx, (images, labels) in enumerate(train_loader):
            if max_batches is not None and b_idx >= max_batches:
                break
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()

            # Teacher forward (no grad)
            with torch.no_grad():
                teacher_logits = teacher_model(images)

            # Uncertainty gate from teacher MC-Dropout
            gates = compute_uncertainty_gate(
                teacher_model, images,
                threshold_quantile=cfg.KD_UNCERTAINTY_GATE,
                T=5   # fewer passes here for speed
            ).to(device)

            # Student forward
            student_logits = student_model(images)

            loss = kd_loss(
                student_logits, teacher_logits, labels,
                alpha=cfg.KD_ALPHA,
                temperature=cfg.KD_TEMPERATURE,
                sample_weights=gates,
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, max_norm=1.0)
            optimizer.step()

            total_loss    += loss.item() * labels.size(0)
            total_correct += (student_logits.argmax(1) == labels).sum().item()
            n += labels.size(0)

        scheduler.step()
        if verbose:
            print(f"  [KD] ep {ep}/{epochs}  "
                  f"loss={total_loss/max(n,1):.4f}  "
                  f"student_acc={total_correct/max(n,1):.4f}")

    # Re-enable all parameters
    for p in student_model.parameters():
        p.requires_grad = True

    print("[KD] Done.\n")
    return student_model
