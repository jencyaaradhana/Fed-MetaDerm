"""
personalization.py
------------------
Implements the "PROPOSED TAIL-AWARE PROTOTYPE PERSONALIZATION" block
(orange box in the architecture diagram):

  Global Prototype (theta_global) + Local Prototype (theta_p)
      → Adaptive Prototype Calibration
      → Personalized Disease Prototypes

Key insight: for COMMON classes, trust the local prototype (more data).
             for RARE (tail) classes, blend strongly toward the global
             prototype (which has aggregated information across all
             hospitals, reducing per-hospital rare-class noise).

After calibrating prototypes, we fine-tune only the classification head
with the personalized prototypes as additional supervision, while keeping
the backbone frozen — giving a fast, privacy-preserving personalization
without re-training the full model.
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW

from config import Config
from prototypes import PrototypeBank, prototypical_loss


# -----------------------------------------------------------------------
# Tail weight computation
# -----------------------------------------------------------------------
def compute_tail_weights(class_counts: "pd.Series",
                          class_names: list) -> torch.Tensor:
    """
    Returns a per-class tail weight in [0, 1] where:
      1.0 = very rare class  → blend strongly toward global prototype
      0.0 = very common class → trust local prototype

    Uses log-inverse-frequency with min-max normalisation so the
    weights stay interpretable regardless of the count distribution.

    Args:
        class_counts : pd.Series indexed by class name with integer counts.
        class_names  : ordered list of class names (matches model output dim).

    Returns:
        tail_weights : (num_classes,) float tensor on CPU.
    """
    import numpy as np
    import pandas as pd

    counts = torch.tensor(
        [max(class_counts.get(c, 0), 1) for c in class_names],
        dtype=torch.float32
    )
    log_inv = torch.log(counts.sum() / counts)          # higher = rarer
    # min-max normalise to [0, 1]
    lo, hi = log_inv.min(), log_inv.max()
    if hi - lo < 1e-6:
        return torch.zeros_like(log_inv)
    return (log_inv - lo) / (hi - lo)


# -----------------------------------------------------------------------
# Adaptive prototype calibration
# -----------------------------------------------------------------------
def calibrate_prototypes(local_proto_bank: PrototypeBank,
                          global_prototypes: dict,
                          tail_weights: torch.Tensor,
                          alpha: float = Config.PERSONALIZATION_ALPHA
                          ) -> PrototypeBank:
    """
    Produces a *personalized* prototype bank by interpolating local and
    global prototypes per class:

        P_personalized[c] = (1 - w[c]) * P_local[c] + w[c] * P_global[c]

    where  w[c] = alpha * tail_weight[c]
         (alpha is the global personalization strength from Config).

    For uninitialized local classes, the global prototype is used directly.
    For classes absent from the global (seen only locally), the local
    prototype is kept as-is.

    Args:
        local_proto_bank  : PrototypeBank trained on this hospital's data.
        global_prototypes : dict {class_idx (int): embedding tensor (D,)}
        tail_weights      : (num_classes,) per-class tail weight.
        alpha             : overall global blend strength.

    Returns:
        personalized_bank : new PrototypeBank with calibrated prototypes.
    """
    personalized = copy.deepcopy(local_proto_bank)
    device = local_proto_bank.device
    tail_weights = tail_weights.to(device)

    for c in range(local_proto_bank.num_classes):
        global_has_c = c in global_prototypes
        local_has_c  = local_proto_bank.initialized[c].item()

        if global_has_c and local_has_c:
            w = alpha * tail_weights[c].item()
            g_proto = global_prototypes[c].to(device)
            l_proto = local_proto_bank.prototypes[c]
            personalized.prototypes[c] = (
                (1.0 - w) * l_proto + w * g_proto
            )
        elif global_has_c and not local_has_c:
            # use global prototype for rare classes unseen locally
            personalized.prototypes[c] = global_prototypes[c].to(device)
            personalized.initialized[c] = True
        # else: local only — keep as-is

    return personalized


# -----------------------------------------------------------------------
# Personalization fine-tuning
# -----------------------------------------------------------------------
def personalize_model(model,
                       personalized_proto_bank: PrototypeBank,
                       train_loader,
                       cfg: Config = Config,
                       epochs: int = None) -> nn.Module:
    """
    Fine-tunes ONLY the classification head (and attention + embed_head)
    using the personalized prototypes as additional prototype loss.
    The backbone is frozen during this step.

    This is cheap (few epochs, small lr) and privacy-preserving (no
    backbone gradient leaves the hospital).

    Args:
        model                  : FedMetaDermClientModel (returned from training).
        personalized_proto_bank: calibrated PrototypeBank from calibrate_prototypes.
        train_loader           : hospital's local training DataLoader.
        cfg                    : Config object.
        epochs                 : number of fine-tuning epochs (default: cfg.PERSONALIZATION_EPOCHS).

    Returns:
        personalized model (in-place modified, also returned for clarity).
    """
    epochs = epochs or cfg.PERSONALIZATION_EPOCHS
    device = cfg.DEVICE

    # Freeze backbone; keep head + CBAM/attention + feature_proj trainable
    if hasattr(model, "backbone") and model.backbone is not None:
        for p in model.backbone.parameters():
            p.requires_grad = False
    head_modules = [model.feature_proj, model.classifier]
    if hasattr(model, "cbam") and isinstance(model.cbam, nn.Module):
        head_modules.append(model.cbam)
    if hasattr(model, "attention") and isinstance(model.attention, nn.Module):
        head_modules.append(model.attention)
    for mod in head_modules:
        for p in mod.parameters():
            p.requires_grad = True

    trainable = [p for p in model.parameters() if p.requires_grad]
    optimizer = AdamW(trainable, lr=cfg.LR_STAGE3, weight_decay=cfg.WEIGHT_DECAY)

    # Use uniform class weights during personalization (avoid bias)
    criterion = nn.CrossEntropyLoss(label_smoothing=cfg.LABEL_SMOOTHING)

    model.train()
    print(f"\n[Personalization] Fine-tuning head for {epochs} epochs "
          f"with calibrated prototypes...")

    for ep in range(1, epochs + 1):
        total_loss, total_correct, n = 0.0, 0, 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()

            logits, embeddings = model(images, return_embedding=True)
            cls_loss   = criterion(logits, labels)
            proto_loss = prototypical_loss(embeddings, labels,
                                           personalized_proto_bank)
            loss = cls_loss + 0.4 * proto_loss
            loss.backward()
            optimizer.step()

            total_loss    += loss.item() * labels.size(0)
            total_correct += (logits.argmax(1) == labels).sum().item()
            n += labels.size(0)

        print(f"  [Personalization] ep {ep}/{epochs}  "
              f"loss={total_loss/max(n,1):.4f}  "
              f"acc={total_correct/max(n,1):.4f}")

    # Re-enable all parameters for future use
    for p in model.parameters():
        p.requires_grad = True

    print("[Personalization] Done.\n")
    return model


# -----------------------------------------------------------------------
# High-level entry point
# -----------------------------------------------------------------------
def run_tail_aware_personalization(model,
                                    local_proto_bank: PrototypeBank,
                                    global_prototypes: dict,
                                    class_counts,
                                    train_loader,
                                    cfg: Config = Config):
    """
    Full Tail-Aware Prototype Personalization pipeline:
      1. Compute per-class tail weights from local class distribution
      2. Calibrate prototypes (blend local + global, tail-weighted)
      3. Fine-tune head with personalized prototypes

    Args:
        model             : trained FedMetaDermClientModel
        local_proto_bank  : local PrototypeBank from hospital training
        global_prototypes : dict {class_idx: tensor} from server aggregation
        class_counts      : pd.Series with per-class image counts (from manifest)
        train_loader      : hospital's DataLoader for fine-tuning
        cfg               : Config

    Returns:
        personalized_model      : fine-tuned model
        personalized_proto_bank : calibrated PrototypeBank
    """
    print("\n" + "="*60)
    print("  TAIL-AWARE PROTOTYPE PERSONALIZATION")
    print("="*60)

    tail_weights = compute_tail_weights(class_counts, cfg.CLASS_NAMES)

    # Print which classes are tail-weighted
    top_tail = sorted(enumerate(tail_weights.tolist()),
                      key=lambda x: -x[1])[:5]
    print("[Personalization] Top-5 tail classes (highest blend toward global):")
    for idx, w in top_tail:
        name = cfg.CLASS_NAMES[idx] if idx < len(cfg.CLASS_NAMES) else str(idx)
        print(f"  {name:40s}  tail_weight={w:.3f}")

    personalized_proto_bank = calibrate_prototypes(
        local_proto_bank, global_prototypes, tail_weights,
        alpha=cfg.PERSONALIZATION_ALPHA
    )

    personalized_model = personalize_model(
        model, personalized_proto_bank, train_loader, cfg
    )

    return personalized_model, personalized_proto_bank
