"""Pre-populate pipeline_state.json from existing hospital checkpoints."""
import json
import os
import sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import Config

cfg = Config
cfg.load_classes_and_hospitals()

state = {"fed_history": []}

for hid in range(cfg.NUM_HOSPITALS):
    hist_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_history.json")
    ckpt_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_model.pt")
    if os.path.exists(hist_path) and os.path.exists(ckpt_path):
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        val_acc = ckpt.get("val_acc", 0.0) if isinstance(ckpt, dict) else 0.0
        hosp_name = cfg.HOSPITAL_NAMES[hid] if hid < len(cfg.HOSPITAL_NAMES) else str(hid)
        state["fed_history"].append({
            "round": 1,
            "hospital": hosp_name,
            "hospital_id": hid,
            "val_acc": val_acc,
        })
        print(f"Hospital {hid} ({hosp_name}): val_acc={val_acc:.4f} -> added to state")
    else:
        print(f"Hospital {hid}: missing checkpoint, will retrain from scratch")

os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
state_path = os.path.join(cfg.OUTPUT_DIR, "pipeline_state.json")
with open(state_path, "w") as f:
    json.dump(state, f, indent=2)
print(f"Saved pipeline_state.json with {len(state['fed_history'])} entries -> {state_path}")
