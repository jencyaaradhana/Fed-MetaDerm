"""
evaluate.py
-----------
Comprehensive evaluation module for Fed-MetaDerm.

Generates, per hospital, per federated round, and globally:
  - Per-class accuracy, precision, recall, F1 (macro + weighted)
  - AUC-ROC (one-vs-rest, macro average)
  - Expected Calibration Error (ECE)
  - Confusion matrix (heatmap)
  - Uncertainty vs accuracy correlation
  - Federated convergence curve (round vs val accuracy)
  - Per-class rarity distribution across hospitals

All outputs saved to output_dir as PNG + JSON for the review report.
"""

import os
import json
import copy
import numpy as np
import torch
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, auc,
    average_precision_score,
)
from sklearn.preprocessing import label_binarize

from config import Config
from uncertainty import mc_dropout_predict


# -----------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------
def _to_numpy(t):
    if isinstance(t, torch.Tensor):
        return t.detach().cpu().numpy()
    return np.array(t)


# -----------------------------------------------------------------------
# Core evaluation loop
# -----------------------------------------------------------------------
@torch.no_grad()
def collect_predictions(model, val_loader, cfg: Config = Config):
    """
    Runs the model over val_loader and collects:
      all_preds       : (N,) int predicted class indices
      all_labels      : (N,) int true class indices
      all_probs       : (N, C) softmax probabilities (mean of MC passes)
      all_entropy     : (N,) predictive entropy (MC-Dropout)
    """
    device = cfg.DEVICE
    model.eval()

    all_preds, all_labels, all_probs, all_entropy = [], [], [], []

    for images, labels in val_loader:
        images = images.to(device)
        mean_probs, entropy, _, _ = mc_dropout_predict(
            model, images, T=min(cfg.MC_DROPOUT_PASSES, 10)
        )
        preds = mean_probs.argmax(dim=-1)
        all_preds.append(_to_numpy(preds))
        all_labels.append(_to_numpy(labels))
        all_probs.append(_to_numpy(mean_probs))
        all_entropy.append(_to_numpy(entropy))

    probs_arr = np.concatenate(all_probs)
    entropy_arr = np.concatenate(all_entropy)
    probs_arr = np.nan_to_num(probs_arr, nan=1.0 / max(len(cfg.CLASS_NAMES), 1), posinf=1.0, neginf=0.0)
    entropy_arr = np.nan_to_num(entropy_arr, nan=0.0, posinf=1.0, neginf=0.0)

    return (
        np.concatenate(all_preds),
        np.concatenate(all_labels),
        probs_arr,
        entropy_arr,
    )


# -----------------------------------------------------------------------
# Classification report (per-class + macro/weighted)
# -----------------------------------------------------------------------
def compute_classification_metrics(labels, preds, class_names):
    """Returns sklearn's classification_report as a dict."""
    report = classification_report(
        labels, preds,
        target_names=class_names,
        labels=list(range(len(class_names))),
        output_dict=True,
        zero_division=0,
    )
    return report


# -----------------------------------------------------------------------
# AUC-ROC (one-vs-rest, macro)
# -----------------------------------------------------------------------
def compute_auc_roc(labels, probs, class_names):
    """
    Computes per-class and macro-average AUC-ROC.
    Classes with fewer than 2 samples in either class are skipped.
    """
    n_classes = len(class_names)
    labels_bin = label_binarize(labels, classes=list(range(n_classes)))

    per_class_auc = {}
    valid_auc = []
    for i, name in enumerate(class_names):
        if labels_bin[:, i].sum() < 2:
            per_class_auc[name] = None
            continue
        try:
            a = roc_auc_score(labels_bin[:, i], probs[:, i])
            per_class_auc[name] = round(float(a), 4)
            valid_auc.append(a)
        except Exception:
            per_class_auc[name] = None

    macro_auc = float(np.mean(valid_auc)) if valid_auc else 0.0
    return macro_auc, per_class_auc


# -----------------------------------------------------------------------
# Expected Calibration Error
# -----------------------------------------------------------------------
def compute_ece(probs, labels, n_bins=10):
    """
    Expected Calibration Error:
    Groups predictions into confidence bins and measures the gap
    between average confidence and average accuracy per bin.
    """
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    accuracies  = (predictions == labels).astype(float)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        mask = (confidences >= lo) & (confidences < hi)
        if mask.sum() == 0:
            continue
        bin_acc  = accuracies[mask].mean()
        bin_conf = confidences[mask].mean()
        ece += (mask.sum() / len(labels)) * abs(bin_acc - bin_conf)
    return float(ece)


# -----------------------------------------------------------------------
# Plot helpers
# -----------------------------------------------------------------------
_DARK_BG = "#1a1a2e"
_PANEL   = "#16213e"
_ACCENT  = "#e94560"


def _dark_fig(figsize=(10, 6)):
    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor(_DARK_BG)
    ax.set_facecolor(_PANEL)
    ax.tick_params(colors="white")
    ax.xaxis.label.set_color("white")
    ax.yaxis.label.set_color("white")
    ax.title.set_color("white")
    for spine in ax.spines.values():
        spine.set_edgecolor("#444")
    return fig, ax


def plot_confusion_matrix(labels, preds, class_names, save_path):
    cm = confusion_matrix(labels, preds, labels=list(range(len(class_names))))
    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-6)

    fig, ax = plt.subplots(figsize=(max(8, len(class_names)), max(7, len(class_names) - 1)))
    fig.patch.set_facecolor(_DARK_BG)
    sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="YlOrRd",
                xticklabels=class_names, yticklabels=class_names,
                ax=ax, linewidths=0.5,
                cbar_kws={"shrink": 0.8})
    ax.set_facecolor(_PANEL)
    ax.set_title("Normalised Confusion Matrix", color="white", fontsize=14, pad=12)
    ax.set_xlabel("Predicted", color="white")
    ax.set_ylabel("True", color="white")
    ax.tick_params(colors="white", labelsize=7)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Confusion matrix -> {save_path}")


def plot_per_class_f1(report, class_names, save_path):
    f1_scores = [report.get(c, {}).get("f1-score", 0) for c in class_names]
    fig, ax = _dark_fig(figsize=(max(10, len(class_names) * 0.6), 5))
    bars = ax.bar(class_names, f1_scores, color=_ACCENT, edgecolor="#333", alpha=0.85)
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("Class", fontsize=11)
    ax.set_ylabel("F1-Score", fontsize=11)
    ax.set_title("Per-Class F1-Score", fontsize=13)
    ax.axhline(np.mean(f1_scores), color="yellow", linestyle="--",
               linewidth=1.5, label=f"Macro avg: {np.mean(f1_scores):.3f}")
    ax.legend(facecolor=_PANEL, labelcolor="white")
    plt.xticks(rotation=45, ha="right", color="white", fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Per-class F1 -> {save_path}")


def plot_roc_curves(labels, probs, class_names, save_path):
    n = len(class_names)
    probs = np.nan_to_num(probs, nan=0.0, posinf=1.0, neginf=0.0)
    labels_bin = label_binarize(labels, classes=list(range(n)))

    fig, ax = _dark_fig(figsize=(8, 7))
    cmap = plt.colormaps.get_cmap("tab10")

    for i, cname in enumerate(class_names):
        if labels_bin[:, i].sum() < 2:
            continue
        fpr, tpr, _ = roc_curve(labels_bin[:, i], probs[:, i])
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, lw=1.5, color=cmap(i % 10),
                label=f"{cname} (AUC={roc_auc:.2f})", alpha=0.85)

    ax.plot([0, 1], [0, 1], "w--", lw=1, alpha=0.4, label="Random")
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    ax.set_title("ROC Curves (One-vs-Rest)", fontsize=13)
    ax.legend(facecolor=_PANEL, labelcolor="white",
              fontsize=7, loc="lower right", ncol=2)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] ROC curves -> {save_path}")


def plot_calibration(probs, labels, save_path, n_bins=10):
    """Reliability diagram (calibration plot)."""
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    accuracies  = (predictions == labels).astype(float)
    bin_edges   = np.linspace(0, 1, n_bins + 1)
    bin_means_conf, bin_means_acc, bin_sizes = [], [], []

    for lo, hi in zip(bin_edges[:-1], bin_edges[1:]):
        mask = (confidences >= lo) & (confidences < hi)
        if mask.sum():
            bin_means_conf.append(confidences[mask].mean())
            bin_means_acc.append(accuracies[mask].mean())
            bin_sizes.append(mask.sum())

    fig, ax = _dark_fig(figsize=(7, 6))
    ax.bar(bin_means_conf, bin_means_acc, width=0.08,
           color=_ACCENT, alpha=0.7, label="Model")
    ax.plot([0, 1], [0, 1], "w--", lw=1.5, label="Perfect calibration")
    ax.set_xlabel("Confidence", fontsize=11)
    ax.set_ylabel("Accuracy", fontsize=11)
    ax.set_title("Calibration (Reliability Diagram)", fontsize=13)
    ece = compute_ece(probs, labels, n_bins)
    ax.text(0.05, 0.9, f"ECE = {ece:.4f}", color="yellow",
            transform=ax.transAxes, fontsize=12)
    ax.legend(facecolor=_PANEL, labelcolor="white")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Calibration plot -> {save_path}")


def plot_uncertainty_vs_accuracy(entropy, labels, preds, save_path, n_bins=10):
    """Shows that higher predictive entropy correlates with lower accuracy."""
    bin_edges = np.linspace(entropy.min(), entropy.max(), n_bins + 1)
    bin_acc, bin_mid = [], []

    for lo, hi in zip(bin_edges[:-1], bin_edges[1:]):
        mask = (entropy >= lo) & (entropy < hi)
        if mask.sum():
            bin_acc.append((preds[mask] == labels[mask]).mean())
            bin_mid.append((lo + hi) / 2)

    fig, ax = _dark_fig(figsize=(8, 5))
    ax.plot(bin_mid, bin_acc, "o-", color=_ACCENT, lw=2, ms=6)
    ax.set_xlabel("Predictive Entropy (MC-Dropout)", fontsize=11)
    ax.set_ylabel("Accuracy in bin", fontsize=11)
    ax.set_title("Uncertainty vs. Accuracy\n(Higher entropy -> lower accuracy)", fontsize=12)
    ax.set_ylim(0, 1.05)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Uncertainty-accuracy -> {save_path}")


def plot_federated_convergence(history_list, save_path):
    """
    Plots validation accuracy per federated round for all hospitals.
    history_list: list of dicts {round: int, hospital: str, val_acc: float}
    """
    from collections import defaultdict
    by_hospital = defaultdict(list)
    by_round    = defaultdict(list)

    for entry in history_list:
        by_hospital[entry["hospital"]].append((entry["round"], entry["val_acc"]))
        by_round[entry["round"]].append(entry["val_acc"])

    fig, ax = _dark_fig(figsize=(10, 5))
    cmap = plt.colormaps.get_cmap("tab10")

    for idx, (hosp, vals) in enumerate(by_hospital.items()):
        vals.sort()
        rounds, accs = zip(*vals)
        ax.plot(rounds, accs, "o-", color=cmap(idx % 10),
                label=hosp, lw=1.8, ms=5)

    # Global mean per round
    rounds_sorted = sorted(by_round.keys())
    global_accs   = [np.mean(by_round[r]) for r in rounds_sorted]
    ax.plot(rounds_sorted, global_accs, "w--", lw=2.5,
            label="Global mean", zorder=10)

    ax.set_xlabel("Federated Round", fontsize=11)
    ax.set_ylabel("Val Accuracy", fontsize=11)
    ax.set_title("Federated Learning Convergence", fontsize=13)
    ax.set_ylim(0, 1.05)
    ax.legend(facecolor=_PANEL, labelcolor="white", fontsize=9)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Convergence curve -> {save_path}")


# -----------------------------------------------------------------------
# High-level entry point
# -----------------------------------------------------------------------
def generate_report(model, val_loader, proto_bank,
                    hospital_name: str, output_dir: str,
                    cfg: Config = Config) -> dict:
    """
    Full evaluation for one hospital's personalized model.
    Saves figures + a JSON report to output_dir.

    Returns a summary dict.
    """
    os.makedirs(output_dir, exist_ok=True)
    class_names = cfg.CLASS_NAMES

    print(f"\n[Eval] Evaluating hospital: {hospital_name}")
    preds, labels, probs, entropy = collect_predictions(model, val_loader, cfg)

    # ---- Metrics --------------------------------------------------------
    cls_report = compute_classification_metrics(labels, preds, class_names)
    macro_auc, per_class_auc = compute_auc_roc(labels, probs, class_names)
    ece = compute_ece(probs, labels)
    overall_acc = float((preds == labels).mean())

    summary = {
        "hospital": hospital_name,
        "overall_accuracy": round(overall_acc, 4),
        "macro_f1": round(cls_report["macro avg"]["f1-score"], 4),
        "weighted_f1": round(cls_report["weighted avg"]["f1-score"], 4),
        "macro_auc_roc": round(macro_auc, 4),
        "ece": round(ece, 4),
        "per_class_f1": {
            c: round(cls_report.get(c, {}).get("f1-score", 0), 4)
            for c in class_names
        },
        "per_class_auc": per_class_auc,
    }

    # ---- Figures --------------------------------------------------------
    plot_confusion_matrix(labels, preds, class_names,
                          os.path.join(output_dir, "confusion_matrix.png"))
    plot_per_class_f1(cls_report, class_names,
                      os.path.join(output_dir, "per_class_f1.png"))
    plot_roc_curves(labels, probs, class_names,
                    os.path.join(output_dir, "roc_curves.png"))
    plot_calibration(probs, labels,
                     os.path.join(output_dir, "calibration.png"))
    plot_uncertainty_vs_accuracy(entropy, labels, preds,
                                 os.path.join(output_dir, "uncertainty_vs_accuracy.png"))

    # ---- Save JSON ------------------------------------------------------
    report_path = os.path.join(output_dir, "evaluation_report.json")
    with open(report_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  [Eval] Report -> {report_path}")
    print(f"  [Eval] Accuracy={overall_acc:.4f}  MacroF1={summary['macro_f1']}  "
          f"AUC={summary['macro_auc_roc']}  ECE={summary['ece']}")

    return summary


# =======================================================================
# N-way K-shot Episodic Testing Suite (Diagram Block 3)
# Protocol: 2W1S, 2W5S, 2W10S, 5W1S, 5W5S
# Datasets: SD-198, Derm7pt, ISIC2018, HAM10000
# Metrics: Accuracy (95% CI), Macro F1, Per-class Recall (Head vs Tail)
# =======================================================================
import random
from sklearn.metrics import f1_score, recall_score


class EpisodicFewShotSampler:
    """Samples N-way K-shot episodes with Q queries from any dataset with .df and .class_to_idx."""
    def __init__(self, dataset, n_way: int = 5, k_shot: int = 5, q_query: int = 5, seed: int = 42):
        self.ds = dataset
        self.n_way = n_way
        self.k = k_shot
        self.q = q_query
        self.rng = random.Random(seed)

        # Build class index lookup
        if hasattr(dataset, "df") and "label" in dataset.df.columns:
            labels = dataset.df["label"].map(dataset.class_to_idx).to_numpy()
        else:
            labels = [dataset[i][1] for i in range(len(dataset))]

        self.by_class = {}
        for idx, lbl in enumerate(labels):
            if lbl is not None and not np.isnan(lbl):
                self.by_class.setdefault(int(lbl), []).append(idx)

        # Classes with >= k + 1 samples (can supply both support and query)
        self.usable_classes = [c for c, idxs in self.by_class.items() if len(idxs) >= self.k + 1]

    def sample_episode(self):
        if len(self.usable_classes) < 2:
            raise ValueError(f"Need at least 2 usable classes with >={self.k+1} samples, but found {len(self.usable_classes)}")

        actual_n = min(self.n_way, len(self.usable_classes))
        chosen_classes = self.rng.sample(self.usable_classes, actual_n)

        support_x, support_y = [], []
        query_x, query_y = [], []

        for episode_lbl, c in enumerate(chosen_classes):
            needed = min(len(self.by_class[c]), self.k + self.q)
            selected_idxs = self.rng.sample(self.by_class[c], needed)
            # Support
            for s_idx in selected_idxs[:self.k]:
                img, _ = self.ds[s_idx]
                support_x.append(img)
                support_y.append(episode_lbl)
            # Query
            for q_idx in selected_idxs[self.k:]:
                img, _ = self.ds[q_idx]
                query_x.append(img)
                query_y.append(episode_lbl)

        return (
            torch.stack(support_x),
            torch.tensor(support_y, dtype=torch.long),
            torch.stack(query_x),
            torch.tensor(query_y, dtype=torch.long),
            chosen_classes,
        )


@torch.no_grad()
def evaluate_single_episode(model, sx, sy, qx, qy, n_way: int, device):
    """Evaluates one episode using prototype distance classification (Eqs. 4-5)."""
    model.eval()
    sx, sy, qx, qy = sx.to(device), sy.to(device), qx.to(device), qy.to(device)

    # Extract L2-normalized embeddings
    zs = F.normalize(model.extract_features(sx), dim=-1)
    zq = F.normalize(model.extract_features(qx), dim=-1)

    # Build support prototypes: c_k = mean support embedding (Eq. 4)
    protos = torch.stack([zs[sy == k].mean(0) for k in range(n_way)])
    protos = F.normalize(protos, dim=-1)

    # Negative squared Euclidean distance (Eq. 5)
    d2 = torch.cdist(zq, protos) ** 2
    logits = -d2
    preds = logits.argmax(dim=1).cpu().numpy()
    targets = qy.cpu().numpy()

    acc = float((preds == targets).mean())
    macro_f1 = float(f1_score(targets, preds, average="macro", zero_division=0))
    recalls = recall_score(targets, preds, average=None, zero_division=0)

    return acc, macro_f1, recalls, targets


def run_nway_kshot_benchmark(model, dataset, device, n_way: int, k_shot: int, q_query: int = 5,
                             num_episodes: int = 50, seed: int = 42):
    """
    Runs num_episodes of an N-way K-shot benchmark setting and calculates:
      - Mean Accuracy with 95% Confidence Interval: acc +/- 1.96 * (std / sqrt(episodes))
      - Mean Macro F1
      - Head vs Tail Recall (based on class frequencies in dataset)
    """
    sampler = EpisodicFewShotSampler(dataset, n_way=n_way, k_shot=k_shot, q_query=q_query, seed=seed)
    if len(sampler.usable_classes) < 2:
        return None

    # Calculate median frequency for head vs tail division
    class_lens = {c: len(idxs) for c, idxs in sampler.by_class.items()}
    median_freq = float(np.median(list(class_lens.values())))

    accs = []
    f1s = []
    head_recalls = []
    tail_recalls = []

    for _ in range(num_episodes):
        sx, sy, qx, qy, chosen_classes = sampler.sample_episode()
        actual_n = len(chosen_classes)
        acc, f1, recalls, targets = evaluate_single_episode(model, sx, sy, qx, qy, actual_n, device)
        accs.append(acc)
        f1s.append(f1)

        # Distinguish head vs tail for sampled classes
        for ep_idx, orig_c in enumerate(chosen_classes):
            r = recalls[ep_idx] if ep_idx < len(recalls) else 0.0
            if class_lens.get(orig_c, 0) > median_freq:
                head_recalls.append(r)
            else:
                tail_recalls.append(r)

    accs = np.array(accs)
    mean_acc = float(accs.mean())
    std_acc = float(accs.std())
    ci95 = float(1.96 * std_acc / np.sqrt(max(len(accs), 1)))

    return {
        "n_way": n_way,
        "k_shot": k_shot,
        "num_episodes": len(accs),
        "mean_accuracy": round(mean_acc, 4),
        "std_accuracy": round(std_acc, 4),
        "ci95": round(ci95, 4),
        "ci95_str": f"{mean_acc*100:.2f}% +/- {ci95*100:.2f}%",
        "macro_f1": round(float(np.mean(f1s)), 4),
        "head_recall": round(float(np.mean(head_recalls)) if head_recalls else 0.0, 4),
        "tail_recall": round(float(np.mean(tail_recalls)) if tail_recalls else 0.0, 4),
    }


def plot_episodic_benchmarks(benchmark_results: dict, save_path: str, dataset_name: str = "SD-198 / ISIC / Derm7pt"):
    """Generates comparison bar chart with 95% CI error bars for all episodic configurations."""
    fig, ax = _dark_fig(figsize=(9, 5))

    names = list(benchmark_results.keys())
    means = [benchmark_results[k]["mean_accuracy"] * 100 for k in names]
    cis = [benchmark_results[k]["ci95"] * 100 for k in names]
    f1s = [benchmark_results[k]["macro_f1"] * 100 for k in names]
    tails = [benchmark_results[k]["tail_recall"] * 100 for k in names]

    x = np.arange(len(names))
    width = 0.25

    ax.bar(x - width, means, width, yerr=cis, capsize=5, label="Accuracy (with 95% CI)",
           color="#1E88E5", edgecolor="#333", alpha=0.9)
    ax.bar(x, f1s, width, label="Macro F1",
           color="#43A047", edgecolor="#333", alpha=0.9)
    ax.bar(x + width, tails, width, label="Tail-Class Recall",
           color="#E53935", edgecolor="#333", alpha=0.9)

    ax.set_ylabel("Score (%)", fontsize=11)
    ax.set_title(f"Fed-MetaDerm: Few-Shot Episodic Evaluation Protocol ({dataset_name})", fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=10, color="white")
    ax.set_ylim(0, 105)
    ax.legend(facecolor=_PANEL, labelcolor="white", fontsize=9)
    ax.grid(axis="y", color="#333", linestyle="--", alpha=0.5)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close()
    print(f"  [Eval] Episodic benchmark plot -> {save_path}")


def run_episodic_evaluation_suite(model, dataset, device, output_dir: str,
                                  benchmarks=None, num_episodes: int = 50,
                                  dataset_name: str = "Combined Test Set") -> dict:
    """
    Evaluates all 5 standard Few-Shot benchmarks from the paper:
      - 2W1S  (2-way 1-shot)
      - 2W5S  (2-way 5-shot)
      - 2W10S (2-way 10-shot)
      - 5W1S  (5-way 1-shot)
      - 5W5S  (5-way 5-shot)
    """
    os.makedirs(output_dir, exist_ok=True)
    benchmarks = benchmarks or [
        ("2W1S", 2, 1),
        ("2W5S", 2, 5),
        ("2W10S", 2, 10),
        ("5W1S", 5, 1),
        ("5W5S", 5, 5),
    ]

    print(f"\n{'='*70}")
    print(f"  EPISODIC FEW-SHOT BENCHMARK SUITE ({dataset_name})")
    print(f"{'='*70}")
    print(f"  {'Setting':<8} | {'Accuracy (95% CI)':<20} | {'Macro F1':<10} | {'Head Recall':<12} | {'Tail Recall':<12}")
    print(f"  {'-'*68}")

    results = {}
    for code, n_way, k_shot in benchmarks:
        res = run_nway_kshot_benchmark(
            model, dataset, device, n_way=n_way, k_shot=k_shot,
            num_episodes=num_episodes
        )
        if res is not None:
            results[code] = res
            print(f"  {code:<8} | {res['ci95_str']:<20} | {res['macro_f1']:<10.4f} | "
                  f"{res['head_recall']:<12.4f} | {res['tail_recall']:<12.4f}")

    print(f"{'='*70}\n")

    # Save JSON and Plot
    json_path = os.path.join(output_dir, "episodic_benchmarks.json")
    with open(json_path, "w") as f:
        json.dump(results, f, indent=2)

    plot_path = os.path.join(output_dir, "episodic_benchmarks.png")
    plot_episodic_benchmarks(results, plot_path, dataset_name=dataset_name)

    return results

