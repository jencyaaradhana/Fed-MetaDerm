# 🧪 Web App Testing Guide — Which Images to Upload for Each Output Type

All test images are in:
`c:\Users\GAYATHREE\Downloads\meta\project\fed_metaderm_data\HAM10000\processed_images\`

---

## 🚨 HIGH RISK Outputs (Malignant / Cancerous)

Enable these sidebar checkboxes for maximum HIGH RISK score:
- ✅ Recent Rapid Growth
- ✅ Spontaneous Bleeding / Itching
- ✅ Multi-colored / Asymmetric Borders
- Set Patient Age > 50

---

### 🔴 1. MELANOMA (mel) — Most Dangerous Skin Cancer
Expected Output: HIGH RISK | Predicted: melanoma | Confidence ~70-90%

| Image File | Use This |
|---|---|
| ISIC_0024586.jpg | ⭐ Best for melanoma |
| ISIC_0024367.jpg | Melanoma |
| ISIC_0024545.jpg | Melanoma |
| ISIC_0024987.jpg | Melanoma (large file = complex) |
| ISIC_0024823.jpg | Melanoma (very large file) |
| ISIC_0024962.jpg | Melanoma (very large file) |
| ISIC_0024940.jpg | Melanoma |

---

### 🔴 2. BASAL CELL CARCINOMA (bcc) — Most Common Skin Cancer
Expected Output: HIGH RISK | Predicted: basal cell carcinoma | Confidence ~65-85%

| Image File | Use This |
|---|---|
| ISIC_0024457.jpg | ⭐ Best for BCC |
| ISIC_0024431.jpg | BCC |
| ISIC_0024673.jpg | BCC |
| ISIC_0024504.jpg | BCC (large file) |
| ISIC_0024795.jpg | BCC (large file) |
| ISIC_0024443.jpg | BCC |
| ISIC_0024799.jpg | BCC |

---

### 🟡 3. BENIGN KERATOSIS — Pre-malignant variant (bkl/akiec)
Expected Output: MEDIUM–HIGH RISK | Predicted: benign keratosis or actinic keratosis

| Image File | Use This |
|---|---|
| ISIC_0024981.jpg | ⭐ Best (very large = detailed) |
| ISIC_0024814.jpg | BKL (large file) |
| ISIC_0024623.jpg | BKL (very large file) |
| ISIC_0025030.jpg | BKL |
| ISIC_0024324.jpg | BKL |

---

## 🟢 LOW RISK Outputs (Benign / Non-Cancerous)

Disable ALL symptom checkboxes. Set Age to 25-30.

---

### 🟢 4. MELANOCYTIC NEVUS / MOLE (nv) — Most Common Benign
Expected Output: LOW RISK | Predicted: melanocytic nevus | Confidence ~85-95%

| Image File | Use This |
|---|---|
| ISIC_0024698.jpg | ⭐ Best for NV (mole) |
| ISIC_0024693.jpg | NV (mole) |
| ISIC_0024415.jpg | NV (mole) |
| ISIC_0024535.jpg | NV (mole) |
| ISIC_0024309.jpg | NV (mole) |
| ISIC_0024308.jpg | NV (mole) |

---

### 🟢 5. DERMATOFIBROMA (df) — Benign Fibrotic
Expected Output: LOW RISK | Predicted: dermatofibroma

| Image File | Use This |
|---|---|
| ISIC_0024973.jpg | ⭐ Best for DF |
| ISIC_0025154.jpg | DF |
| ISIC_0024318.jpg | DF |
| ISIC_0024396.jpg | DF |
| ISIC_0024330.jpg | DF |
| ISIC_0024845.jpg | DF |
| ISIC_0024553.jpg | DF |

---

### 🟢 6. VASCULAR LESION (vasc) — Angioma / Hemangioma
Expected Output: LOW RISK | Predicted: vascular lesion

| Image File | Use This |
|---|---|
| ISIC_0024904.jpg | ⭐ Best for VASC (large) |
| ISIC_0024669.jpg | VASC |
| ISIC_0024747.jpg | VASC |
| ISIC_0024402.jpg | VASC |
| ISIC_0024370.jpg | VASC |
| ISIC_0024867.jpg | VASC |

---

## 🎯 RECOMMENDED TESTING SEQUENCE (8 Steps)

| Step | Image File | Expected Disease | Risk Level |
|---|---|---|---|
| 1 | ISIC_0024586.jpg | Melanoma | 🔴 HIGH |
| 2 | ISIC_0024457.jpg | Basal Cell Carcinoma | 🔴 HIGH |
| 3 | ISIC_0024981.jpg | Benign Keratosis | 🟡 MEDIUM |
| 4 | ISIC_0024698.jpg | Melanocytic Nevus | 🟢 LOW |
| 5 | ISIC_0024318.jpg | Dermatofibroma | 🟢 LOW |
| 6 | ISIC_0024904.jpg | Vascular Lesion | 🟢 LOW |
| 7 | ISIC_0024673.jpg | Basal Cell Carcinoma | 🔴 HIGH |
| 8 | ISIC_0024693.jpg | Melanocytic Nevus | 🟢 LOW |

---

## 📊 Risk Score Formula

Composite Risk = (AI Confidence x 0.7) + (Patient Risk Factors x 30)

Sidebar checkboxes add:
  + 0.25  Recent Rapid Growth
  + 0.35  Spontaneous Bleeding
  + 0.20  Multi-colored Borders
  + 0.10  Age > 50

To force HIGH RISK: Enable ALL checkboxes + set Age > 50
To force LOW RISK:  Disable ALL checkboxes + set Age 25
