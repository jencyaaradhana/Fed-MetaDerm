path = r"E:\final pro\project\project (6)\project (6)\project\federated_pipeline.py"
with open(path, "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "zCDP Privacy Accountant" in line:
        indent = line[:line.find("print")]
        new_lines.append(f"{indent}eps = agg_result.get('epsilon') or 0.0\n")
        new_lines.append(f"{indent}print(f'  zCDP Privacy Accountant: (epsilon={{eps:.4f}}, delta=1e-5)')\n")
    else:
        new_lines.append(line)

with open(path, "w", encoding="utf-8") as f:
    f.writelines(new_lines)

print("Patch applied to federated_pipeline.py!")
