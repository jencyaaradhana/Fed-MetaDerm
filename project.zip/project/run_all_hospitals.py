"""
run_all_hospitals.py
--------------------
Utility script to trigger dataset verification / preprocessing across hospital directories.
"""

import sys
from pathlib import Path
from build_dataset_manifest import build_manifest

def main():
    print("Running Dataset Manifest creation across all hospital clients...")
    build_manifest()

if __name__ == "__main__":
    main()
