"""
rupa.py -- Module 8: Rarity- and Uncertainty-aware Prototype Aggregation (Eqs. 13-15)
   r_i   = sum_c q_ic / pi_c                   (rarity, Eq. 13)
   rho_i = |D_i| / sum_j |D_j|                 (data contribution)
   u_i   = mean MC-dropout entropy             (uncertainty)
   w_i   = r_i * rho_i / (u_i + eps),  w~_i = w_i / sum_j w_j      (Eq. 14)
   c^g_k = sum_{i in I_k} w~_i c_ik / sum_{i in I_k} w~_i          (Eq. 15)
"""
import numpy as np
import torch
import torch.nn.functional as F


def global_class_frequency(local_counts):
    """local_counts: list of {class_name: count}. Returns pi_c = n_c / sum n."""
    tot = {}
    for d in local_counts:
        for c, n in d.items():
            tot[c] = tot.get(c, 0) + int(n)
    s = float(sum(tot.values()))
    return {c: n / s for c, n in tot.items() if n > 0}


def rarity_score(counts, pi):
    """Eq. (13): r_i = sum_c q_ic / pi_c, q_ic = local class share."""
    n = float(sum(counts.values()))
    if n == 0:
        return 0.0
    return float(sum((v / n) / pi[c] for c, v in counts.items() if v > 0 and pi.get(c, 0) > 0))


def data_contribution(sizes):
    s = float(sum(sizes))
    return [x / s for x in sizes]


def uncertainty_from_reliability(reliability):
    """train_client stores reliability = 1/(1+mean_entropy)  ->  u = mean entropy."""
    return max(1.0 / max(reliability, 1e-12) - 1.0, 0.0)


def rupa_weights(r, rho, u, eps=1e-3, rarity_power=1.0):
    """Eq. (14). rarity_power=1.0 is the paper's rule; <1 tempers very large rarity ratios."""
    r, rho, u = (np.asarray(x, np.float64) for x in (r, rho, u))
    w = (r ** rarity_power) * rho / (u + eps)
    return (w / w.sum()).tolist()


def aggregate_prototypes_plain(proto_dicts, weights):
    """Plaintext reference of Eq. (15) (the secure version lives in secure_aggregation.py)."""
    classes = sorted({c for d in proto_dicts for c in d})
    out = {}
    for c in classes:
        num, den = 0.0, 0.0
        for d, w in zip(proto_dicts, weights):
            if c in d:
                num = num + w * d[c].float()
                den += w
        out[c] = F.normalize(num / den, dim=-1)
    return out


def check_properties(r, rho, u):
    """Properties 1-3 of the paper, as runtime assertions (used in the tests)."""
    w = np.asarray(rupa_weights(r, rho, u))
    assert abs(w.sum() - 1) < 1e-9 and (w >= 0).all()                       # P1 convex
    w2 = np.asarray(rupa_weights([r[0] * 2] + list(r[1:]), rho, u))
    assert w2[0] > w[0]                                                       # P2 rarity
    u2 = [u[0] * 2 + 1] + list(u[1:])
    assert rupa_weights(r, rho, u2)[0] < w[0]                                 # P2 uncertainty
    same = rupa_weights([1] * len(r), rho, [0.5] * len(r))                    # P3 FedAvg
    assert np.allclose(same, rho / np.sum(rho))
    return True
