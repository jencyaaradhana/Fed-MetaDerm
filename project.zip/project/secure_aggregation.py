"""
secure_aggregation.py  --  Module 10 (real implementation)
===========================================================
Replaces the stub in fed_metaderm_server.py. Implements, in simulation:

  * Differential privacy : L2 clipping of the client UPDATE (theta_i - theta_global)
                           + Gaussian noise N(0, (sigma*C)^2), and a zCDP accountant
                           that reports (epsilon, delta) after R rounds.
  * SMPC                 : fixed-point additive secret sharing over Z_{2^61}.
                           The client splits its update into m shares (one per party);
                           parties add shares locally; only the weighted SUM is
                           reconstructed.  No single party learns an individual update.
  * Paillier HE          : class prototypes are packed (31 values per 2048-bit plaintext),
                           encrypted, combined by the server homomorphically
                           (E(a)^w * E(b)^v = E(wa+vb)) and only the aggregate is
                           decrypted, by a separate KeyAuthority.
  * Blockchain ledger    : hash chain whose blocks hold the digest of every submitted
                           update, a Merkle root, the aggregate digest and acceptance flags.
  * PBFT consensus       : n = 3f+1 validators, pre-prepare/prepare/commit message
                           simulation; an update is accepted only with >= 2f+1 commits.
                           Byzantine validators can be simulated.

Honest simplifications (state them in the paper):
  - everything runs in one process; parties/validators/server are separate objects;
  - Paillier protects the prototypes; model weights are protected by SMPC (+DP);
  - the Paillier private key is held by a KeyAuthority (threshold decryption not modelled);
  - validators check integrity/format/replay, not the plaintext content of an update.
"""
import hashlib
import json
import math
import secrets
import time
from dataclasses import dataclass, field

import numpy as np
import torch

try:
    from phe import paillier
except ImportError as e:                                      # pragma: no cover
    raise ImportError("pip install phe") from e

# ---------------------------------------------------------------------------
# 1. Differential privacy
# ---------------------------------------------------------------------------
def float_keys(state):
    return [k for k, v in state.items() if torch.is_tensor(v) and v.is_floating_point()]


def flatten(state, keys):
    return torch.cat([state[k].detach().cpu().double().flatten() for k in keys]).numpy()


def unflatten(vec, ref_state, keys):
    out, i = {}, 0
    for k in keys:
        n = ref_state[k].numel()
        out[k] = torch.from_numpy(vec[i:i + n].copy()).reshape(ref_state[k].shape).to(ref_state[k].dtype)
        i += n
    return out


def dp_sanitize(delta_vec: np.ndarray, clip_norm: float, sigma: float, rng=None):
    """Eq. (20), applied to the update:  clip to norm C, add N(0,(sigma*C)^2 I)."""
    rng = rng or np.random.default_rng(secrets.randbits(64))
    norm = float(np.linalg.norm(delta_vec))
    scale = min(1.0, clip_norm / (norm + 1e-12))
    out = delta_vec * scale
    if sigma > 0:
        out = out + rng.normal(0.0, sigma * clip_norm, size=out.shape)
    return out, norm, scale


class GaussianAccountant:
    """zCDP accountant for repeated Gaussian mechanisms with noise multiplier sigma.
    One release: rho = 1/(2 sigma^2).  After R releases: rho_R = R*rho.
    (epsilon, delta): epsilon = rho_R + 2*sqrt(rho_R*ln(1/delta))   [Bun & Steinke 2016]
    Client-level guarantee for one client's update, no subsampling amplification."""
    def __init__(self):
        self.rho = 0.0
        self.rounds = 0

    def step(self, sigma: float):
        if sigma <= 0:
            self.rho = float("inf")
        else:
            self.rho += 1.0 / (2.0 * sigma ** 2)
        self.rounds += 1

    def epsilon(self, delta: float = 1e-5) -> float:
        if math.isinf(self.rho):
            return float("inf")
        return self.rho + 2.0 * math.sqrt(self.rho * math.log(1.0 / delta))


# ---------------------------------------------------------------------------
# 2. SMPC: additive secret sharing with fixed-point encoding
# ---------------------------------------------------------------------------
FP_SCALE = 2 ** 20
MOD = 2 ** 61


def _csprng(n):
    """n uniform integers in [0, MOD) from the OS CSPRNG."""
    raw = np.frombuffer(secrets.token_bytes(8 * n), dtype=np.uint64)
    return (raw % np.uint64(MOD)).astype(np.int64)


def fp_encode(x: np.ndarray) -> np.ndarray:
    return np.mod(np.rint(x * FP_SCALE).astype(np.int64), MOD)


def fp_decode(v: np.ndarray, divisor: float = 1.0) -> np.ndarray:
    v = np.where(v >= MOD // 2, v - MOD, v)
    return v.astype(np.float64) / (FP_SCALE * divisor)


def make_shares(vec: np.ndarray, m: int):
    """Split vec into m additive shares: s_1+...+s_m = enc(vec) (mod MOD)."""
    enc = fp_encode(vec)
    shares, acc = [], np.zeros_like(enc)
    for _ in range(m - 1):
        s = _csprng(enc.size)
        shares.append(s)
        acc = np.mod(acc + s, MOD)
    shares.append(np.mod(enc - acc, MOD))
    return shares


def smpc_weighted_sum(all_shares, int_weights):
    """all_shares[i][p] = share held by party p of client i; int_weights[i] public ints.
    Each party p computes sum_i w_i * share_{i,p} locally; the m party-sums are then
    added to reconstruct sum_i w_i * v_i.  Returns the decoded float vector / sum(w)."""
    m = len(all_shares[0])
    party_sums = []
    for p in range(m):
        acc = np.zeros_like(all_shares[0][p])
        for i, w in enumerate(int_weights):
            acc = np.mod(acc + np.mod(all_shares[i][p] * np.int64(w), MOD), MOD)
        party_sums.append(acc)
    total = np.zeros_like(party_sums[0])
    for s in party_sums:
        total = np.mod(total + s, MOD)
    return fp_decode(total, divisor=float(sum(int_weights)))


# ---------------------------------------------------------------------------
# 3. Paillier with plaintext packing
# ---------------------------------------------------------------------------
SLOT_BITS = 64
VAL_SCALE = 2 ** 20


class KeyAuthority:
    """Holds the Paillier private key. The server only gets the public key."""
    def __init__(self, key_bits=2048):
        self.pk, self._sk = paillier.generate_paillier_keypair(n_length=key_bits)
        self.key_bits = key_bits
        self.slots = (self.pk.n.bit_length() - 1) // SLOT_BITS

    def decrypt_aggregate(self, ciphertext: int) -> int:
        return self._sk.raw_decrypt(ciphertext)


def paillier_encrypt_vector(pk, slots, vec):
    """vec in [-1,1] -> list of ciphertext ints (packed, `slots` values per ciphertext)."""
    u = np.rint((np.clip(vec, -1.0, 1.0) + 1.0) * VAL_SCALE).astype(np.int64)
    cts = []
    for s in range(0, len(u), slots):
        m = 0
        for j, val in enumerate(u[s:s + slots]):
            m |= int(val) << (SLOT_BITS * j)
        cts.append(pk.raw_encrypt(m))
    return cts


def paillier_weighted_sum(pk, list_of_ct_lists, int_weights):
    """Homomorphic sum_i w_i * E(v_i):  prod_i ct_i^{w_i} mod n^2  (done by the server)."""
    n2 = pk.nsquare
    out = []
    for parts in zip(*list_of_ct_lists):
        c = 1
        for ct, w in zip(parts, int_weights):
            c = (c * pow(ct, int(w), n2)) % n2
        out.append(c)
    return out


def paillier_decrypt_vector(authority: KeyAuthority, cts, length, wsum):
    mask = (1 << SLOT_BITS) - 1
    vals = []
    for ct in cts:
        m = authority.decrypt_aggregate(ct)
        for j in range(authority.slots):
            vals.append(((m >> (SLOT_BITS * j)) & mask))
    s = np.array(vals[:length], dtype=np.float64)
    return s / (VAL_SCALE * wsum) - 1.0


# ---------------------------------------------------------------------------
# 4. Ledger + 5. PBFT
# ---------------------------------------------------------------------------
def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def merkle_root(hashes):
    if not hashes:
        return sha(b"")
    level = list(hashes)
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [sha((level[i] + level[i + 1]).encode()) for i in range(0, len(level), 2)]
    return level[0]


class BlockchainLedger:
    """Append-only hash chain. Each block stores the update digests of a round."""
    def __init__(self):
        self.chain = []
        self._append(0, {}, [], "genesis")

    @staticmethod
    def _hash(block):
        body = {k: v for k, v in block.items() if k != "hash"}
        return sha(json.dumps(body, sort_keys=True).encode())

    def _append(self, round_num, update_digests, accepted, aggregate_digest):
        prev = self.chain[-1]["hash"] if self.chain else "0" * 64
        block = {"index": len(self.chain), "timestamp": time.time(), "round": round_num,
                 "update_digests": update_digests, "accepted": sorted(accepted),
                 "merkle_root": merkle_root([update_digests[k] for k in sorted(update_digests)]),
                 "aggregate_digest": aggregate_digest, "prev_hash": prev}
        block["hash"] = self._hash(block)
        self.chain.append(block)
        return block

    def record_round(self, round_num, update_digests, accepted, aggregate_digest):
        return self._append(round_num, update_digests, accepted, aggregate_digest)

    def verify_chain(self):
        for i, b in enumerate(self.chain):
            if b["hash"] != self._hash(b):
                return False
            if i and b["prev_hash"] != self.chain[i - 1]["hash"]:
                return False
        return True

    def to_json(self):
        return json.dumps(self.chain, indent=2)


class PBFTCluster:
    """n = 3f+1 validators. Per update: pre-prepare -> prepare -> commit.
    Honest validators vote accept iff the update passes `verdict`.
    Byzantine validators vote the opposite. Accept iff >= 2f+1 commit-accept."""
    def __init__(self, n_validators=4, byzantine=()):
        assert n_validators >= 4, "PBFT needs n >= 3f+1 with f >= 1"
        self.n = n_validators
        self.f = (n_validators - 1) // 3
        self.byz = set(byzantine)
        self.view = 0
        self.messages = 0

    def decide(self, honest_verdict: bool):
        n, f = self.n, self.f
        self.messages += n - 1                         # pre-prepare from primary
        votes = [(not honest_verdict) if v in self.byz else honest_verdict for v in range(n)]
        self.messages += n * (n - 1)                   # prepare broadcast
        prepared = [sum(votes) >= 2 * f + 1 if votes[v] else (n - sum(votes)) >= 2 * f + 1
                    for v in range(n)]
        self.messages += n * (n - 1)                   # commit broadcast
        accept_commits = sum(1 for v in range(n) if votes[v] and prepared[v])
        return accept_commits >= 2 * f + 1, {"accept_votes": int(sum(votes)),
                                             "commit_accepts": int(accept_commits),
                                             "needed": 2 * f + 1}


# ---------------------------------------------------------------------------
# 6. Client upload + secure aggregation server
# ---------------------------------------------------------------------------
@dataclass
class ClientUpload:
    client_id: int
    round_num: int
    shares: list                       # shares[p] = int64 array for party p
    proto_cts: dict                    # {class_idx: [ciphertext ints]}
    proto_dim: int
    r: float
    rho: float
    u: float
    digest: str = ""
    stats: dict = field(default_factory=dict)

    def compute_digest(self):
        h = hashlib.sha256()
        h.update(f"{self.client_id}|{self.round_num}|{self.proto_dim}|{self.r:.9g}|{self.rho:.9g}|{self.u:.9g}".encode())
        for s in self.shares:
            h.update(s.tobytes())
        for k in sorted(self.proto_cts):
            h.update(str(k).encode())
            for c in self.proto_cts[k]:
                h.update(hex(c).encode())
        return h.hexdigest()


def prepare_client_upload(client_id, round_num, local_state, global_state, prototypes,
                          r, rho, u, num_parties, authority_pk, slots,
                          clip_norm, sigma, rng=None):
    """Client side: delta -> DP clip+noise -> additive shares; prototypes -> Paillier."""
    t0 = time.time()
    # Use only keys present in BOTH state dicts with identical shapes
    global_keys = float_keys(global_state)
    local_keys_set = set(float_keys(local_state))
    keys = [k for k in global_keys
            if k in local_keys_set
            and local_state[k].shape == global_state[k].shape]
    if not keys:
        # Fallback: use local keys only (send local weights as delta from zeros)
        keys = float_keys(local_state)
        delta = flatten(local_state, keys)
    else:
        delta = flatten(local_state, keys) - flatten(global_state, keys)
    clean, norm, scale = dp_sanitize(delta, clip_norm, sigma, rng)
    shares = make_shares(clean, num_parties)
    t_smpc = time.time() - t0

    t1 = time.time()
    proto_cts, dim = {}, 0
    for c, vec in prototypes.items():
        v = vec.detach().cpu().double().numpy() if torch.is_tensor(vec) else np.asarray(vec, np.float64)
        dim = len(v)
        proto_cts[int(c)] = paillier_encrypt_vector(authority_pk, slots, v)
    t_he = time.time() - t1

    up = ClientUpload(client_id, round_num, shares, proto_cts, dim, float(r), float(rho), float(u))
    up.digest = up.compute_digest()
    n_ct = sum(len(v) for v in proto_cts.values())
    up.stats = {"update_norm_before_clip": norm, "clip_scale": scale,
                "t_smpc_s": t_smpc, "t_paillier_s": t_he,
                "uplink_smpc_MB": sum(s.nbytes for s in shares) / 1e6,
                "uplink_paillier_MB": n_ct * (2 * authority_pk.n.bit_length()) / 8 / 1e6}
    return up


class SecureAggregationServer:
    def __init__(self, num_parties=3, paillier_bits=2048, clip_norm=1.0, sigma=0.01,
                 delta=1e-5, pbft_validators=4, byzantine_validators=(),
                 weight_resolution=2 ** 10):
        self.m, self.clip, self.sigma, self.delta = num_parties, clip_norm, sigma, delta
        self.authority = KeyAuthority(paillier_bits)
        self.ledger = BlockchainLedger()
        self.pbft = PBFTCluster(pbft_validators, byzantine_validators)
        self.accountant = GaussianAccountant()
        self.wres = weight_resolution

    # -- public parameters for clients
    @property
    def pk(self):
        return self.authority.pk

    @property
    def slots(self):
        return self.authority.slots

    def _verdict(self, up: ClientUpload, round_num, expected_len, committed_digest):
        """Integrity checks the validators can do without seeing plaintext."""
        if up.round_num != round_num:                                  return False   # replay
        if up.compute_digest() != committed_digest:                    return False   # tampering
        if len(up.shares) != self.m:                                   return False
        if any(s.shape[0] != expected_len for s in up.shares):         return False
        if not all(math.isfinite(x) for x in (up.r, up.rho, up.u)):    return False
        if not (up.r > 0 and 0 < up.rho <= 1 and up.u >= 0):           return False
        return True

    def aggregate(self, round_num, global_state, uploads, weight_fn, committed_digests=None):
        """uploads: list[ClientUpload]; weight_fn(r_list, rho_list, u_list) -> list[float]
        (the RUPA rule, applied to the public per-client scalars of ACCEPTED clients).
        committed_digests: {client_id: digest} as first recorded by the client/ledger."""
        t0 = time.time()
        keys = float_keys(global_state)
        expected_len = sum(global_state[k].numel() for k in keys)
        committed = committed_digests or {u.client_id: u.digest for u in uploads}

        # PBFT + ledger
        accepted, pbft_log = [], {}
        for up in uploads:
            ok_local = self._verdict(up, round_num, expected_len, committed[up.client_id])
            ok, info = self.pbft.decide(ok_local)
            pbft_log[up.client_id] = {"honest_verdict": ok_local, **info, "accepted": ok}
            if ok:
                accepted.append(up)
        if not accepted:
            self.ledger.record_round(round_num, {u.client_id: committed[u.client_id] for u in uploads}, [], "none")
            return {"accepted": [], "pbft": pbft_log, "global_state": None, "global_prototypes": {}}

        # RUPA weights -> public integer weights
        w = weight_fn([u.r for u in accepted], [u.rho for u in accepted], [u.u for u in accepted])
        w = np.asarray(w, np.float64)
        w = w / w.sum()
        int_w = [max(1, int(round(x * self.wres))) for x in w]

        # SMPC weighted sum of the clipped+noised deltas
        t1 = time.time()
        agg_delta = smpc_weighted_sum([u.shares for u in accepted], int_w)
        new_state = {k: v.clone() for k, v in global_state.items()}
        gvec = flatten(global_state, keys)
        upd = unflatten(gvec + agg_delta, global_state, keys)
        new_state.update(upd)
        t_smpc = time.time() - t1

        # Paillier: class-wise weighted prototype aggregation (Eq. 15) on ciphertexts
        t2 = time.time()
        classes = sorted({c for u in accepted for c in u.proto_cts})
        dim = accepted[0].proto_dim
        gprotos = {}
        for c in classes:
            holders = [(u, wi) for u, wi in zip(accepted, int_w) if c in u.proto_cts]
            cts = paillier_weighted_sum(self.pk, [u.proto_cts[c] for u, _ in holders],
                                        [wi for _, wi in holders])
            v = paillier_decrypt_vector(self.authority, cts, dim, sum(wi for _, wi in holders))
            nv = np.linalg.norm(v)
            gprotos[c] = torch.from_numpy((v / max(nv, 1e-12)).astype(np.float32))
        t_he = time.time() - t2

        self.accountant.step(self.sigma)
        agg_digest = sha(agg_delta.tobytes())
        self.ledger.record_round(round_num, {u.client_id: committed[u.client_id] for u in uploads},
                                 [u.client_id for u in accepted], agg_digest)
        return {"accepted": [u.client_id for u in accepted],
                "weights": {u.client_id: float(x) for u, x in zip(accepted, w)},
                "pbft": pbft_log, "global_state": new_state, "global_prototypes": gprotos,
                "epsilon": self.accountant.epsilon(self.delta), "delta": self.delta,
                "timing": {"server_total_s": time.time() - t0, "smpc_s": t_smpc,
                           "paillier_s": t_he},
                "pbft_messages_total": self.pbft.messages}
