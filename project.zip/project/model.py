"""
model.py  --  Fed-MetaDerm client model with real CBAM (Module 4)
-------------------------------------------------------------------
backbone feature map -> CBAM (channel Eq.7, then spatial Eq.8) -> global avg pool
-> feature_proj -> ReLU -> Dropout (needed for MC-dropout, Module 7) -> classifier

Public API is unchanged (FedMetaDermClientModel, set_stage, return_embedding,
return_ssl, get_evidential_output) so the other files keep working.
NOTE: old checkpoints are NOT compatible (new layers) -> retrain.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import timm
except ImportError:
    timm = None


class ChannelAttention(nn.Module):
    """Mc(F) = sigmoid(MLP(AvgPool(F)) + MLP(MaxPool(F)))   (Eq. 7)"""
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        mid = max(channels // reduction, 8)
        self.mlp = nn.Sequential(nn.Linear(channels, mid), nn.ReLU(inplace=True),
                                 nn.Linear(mid, channels))

    def forward(self, x):
        avg = self.mlp(x.mean(dim=(2, 3)))
        mx = self.mlp(x.amax(dim=(2, 3)))
        return torch.sigmoid(avg + mx).unsqueeze(-1).unsqueeze(-1)


class SpatialAttention(nn.Module):
    """Ms(F') = sigmoid(conv7x7([AvgPool_c(F'); MaxPool_c(F')]))   (Eq. 8)"""
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)

    def forward(self, x):
        pooled = torch.cat([x.mean(dim=1, keepdim=True),
                            x.amax(dim=1, keepdim=True)], dim=1)
        return torch.sigmoid(self.conv(pooled))


class CBAM(nn.Module):
    def __init__(self, channels: int, reduction: int = 16, kernel_size: int = 7):
        super().__init__()
        self.channel = ChannelAttention(channels, reduction)
        self.spatial = SpatialAttention(kernel_size)

    def forward(self, x):
        x = x * self.channel(x)          # F'  = Mc(F)  (x) F
        x = x * self.spatial(x)          # F'' = Ms(F') (x) F'
        return x


class _FallbackBackbone(nn.Module):
    """Small conv net used only if timm / pretrained weights are unavailable."""
    def __init__(self):
        super().__init__()
        self.num_features = 128
        self.net = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(inplace=True))

    def forward_features(self, x):
        return self.net(x)

    def forward(self, x):
        return self.forward_features(x)


class FedMetaDermClientModel(nn.Module):
    def __init__(self, num_classes: int = 216, backbone_name: str = "efficientnet_b0",
                 pretrained: bool = True, feature_dim: int = 512,
                 dropout_p: float = 0.3, use_cbam: bool = True):
        super().__init__()
        self.num_classes, self.feature_dim = num_classes, feature_dim
        self.backbone = None
        if timm is not None:
            try:
                self.backbone = timm.create_model(backbone_name, pretrained=pretrained,
                                                  num_classes=0, global_pool="")
            except Exception as e:                       # offline / unknown name
                print(f"[model] timm backbone '{backbone_name}' failed ({e}); "
                      f"using fallback CNN")
        if self.backbone is None:
            self.backbone = _FallbackBackbone()
        in_ch = self.backbone.num_features

        self.cbam = CBAM(in_ch) if use_cbam else nn.Identity()
        self.feature_proj = nn.Linear(in_ch, feature_dim)
        self.dropout = nn.Dropout(dropout_p)
        self.classifier = nn.Linear(feature_dim, num_classes)
        self.projection_head = nn.Sequential(
            nn.Linear(feature_dim, feature_dim), nn.ReLU(inplace=True),
            nn.Linear(feature_dim, 128))
        self.uncertainty_head = nn.Linear(feature_dim, num_classes)
        self.attention = None  # Backward-compatibility placeholder

    def load_state_dict(self, state_dict, strict: bool = False):
        """Flexible loader that ignores missing/unexpected keys from legacy checkpoints."""
        own_state = self.state_dict()
        filtered = {}
        for k, v in state_dict.items():
            if k in own_state:
                if own_state[k].shape == v.shape:
                    filtered[k] = v
                else:
                    print(f"[model] Skipped key {k} due to shape mismatch: {own_state[k].shape} vs {v.shape}")
        return super().load_state_dict(filtered, strict=False)

    # ---- feature maps ----------------------------------------------------
    def feature_map(self, x):
        fm = self.backbone.forward_features(x) if hasattr(self.backbone, "forward_features") \
            else self.backbone(x)
        return fm

    def extract_features(self, x):
        fm = self.cbam(self.feature_map(x))
        pooled = fm.mean(dim=(2, 3))
        return F.relu(self.feature_proj(pooled))

    def forward(self, x, return_features=False, return_embedding=False, return_ssl=False):
        feat = self.extract_features(x)
        logits = self.classifier(self.dropout(feat))
        if return_features or return_embedding:
            if return_ssl:
                return logits, feat, F.normalize(self.projection_head(feat), dim=-1)
            return logits, feat
        if return_ssl:
            return logits, F.normalize(self.projection_head(feat), dim=-1)
        return logits

    def get_evidential_output(self, x):
        feat = self.extract_features(x)
        logits = self.classifier(self.dropout(feat))
        alpha = F.softplus(self.uncertainty_head(feat)) + 1.0
        return logits, alpha


def set_stage(model: FedMetaDermClientModel, stage: int):
    """Stage 1: backbone frozen; Stage 2: last third unfrozen; Stage 3: all.
    CBAM, projection and classifier are trainable in every stage."""
    if not hasattr(model, "backbone") or model.backbone is None:
        return
    params = list(model.backbone.parameters())
    for p in model.parameters():
        p.requires_grad = True
    if stage == 1:
        for p in params:
            p.requires_grad = False
    elif stage == 2:
        for p in params:
            p.requires_grad = False
        for p in params[-max(1, len(params) // 3):]:
            p.requires_grad = True
