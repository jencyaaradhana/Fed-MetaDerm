"""
run_federated_training.py
-------------------------
Federated Training entry point for individual hospital dataset partitions.
"""

import argparse
import json
from pathlib import Path
import pandas as pd
import torch
from torch.utils.data import DataLoader

from fed_metaderm_server import (
    HospitalDataset, build_class_index, SimpleCNN,
    federated_nas_search, federated_meta_learning, local_client_update,
    compute_rupa_weights, secure_aggregate_round, BlockchainLedger,
)


def load_client_rarity_scores(dataset_root, hospital_csvs, rarity_csv_path):
    if Path(rarity_csv_path).exists():
        rarity_df = pd.read_csv(rarity_csv_path)
        rarity_lookup = dict(zip(rarity_df.get("class", rarity_df.columns[0]), rarity_df.get("rarity_score", [1.0]*len(rarity_df))))
    else:
        rarity_lookup = {}

    client_rarity = []
    for csv_path in hospital_csvs:
        df = pd.read_csv(csv_path)
        dx_col = "dx" if "dx" in df.columns else df.columns[1]
        classes_here = df[dx_col].unique().tolist()
        scores = [rarity_lookup.get(c, 0.5) for c in classes_here]
        client_rarity.append(sum(scores) / len(scores) if scores else 0.5)
    return client_rarity


def main():
    parser = argparse.ArgumentParser(description="Fed-MetaDerm federated training")
    parser.add_argument("--dataset_root", default="fed_metaderm_data/HAM10000",
                        help="Path to dataset directory")
    parser.add_argument("--output_dir", default="./federated_output")
    parser.add_argument("--image_size", type=int, default=224)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--num_rounds", type=int, default=3)
    parser.add_argument("--local_epochs", type=int, default=1)
    parser.add_argument("--meta_rounds", type=int, default=2)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    dataset_root = Path(args.dataset_root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    partitions_dir = dataset_root / "hospital_partitions"
    images_dir = dataset_root / "processed_images"
    rarity_csv = dataset_root / "disease_rarity_scores.csv"

    if partitions_dir.exists():
        hospital_csvs = sorted(partitions_dir.glob("*.csv"))
    else:
        hospital_csvs = sorted(dataset_root.glob("*.csv"))

    if not hospital_csvs:
        print(f"No CSV partitions found in {dataset_root}")
        return

    print(f"Found {len(hospital_csvs)} hospital partition CSVs: {[p.name for p in hospital_csvs]}")

    class_to_idx = build_class_index(hospital_csvs)
    num_classes = len(class_to_idx)
    print(f"Class set ({num_classes} classes): {class_to_idx}")

    datasets = [HospitalDataset(c, images_dir if images_dir.exists() else dataset_root, class_to_idx, image_size=args.image_size)
                for c in hospital_csvs]
    loaders = [DataLoader(ds, batch_size=args.batch_size, shuffle=True) for ds in datasets if len(ds) > 0]

    if not loaders:
        print("No samples loaded.")
        return

    client_rarity_scores = load_client_rarity_scores(dataset_root, hospital_csvs, rarity_csv)

    best_cfg = federated_nas_search(loaders, loaders, num_classes, device)
    global_model = federated_meta_learning(loaders, num_classes, device, meta_rounds=args.meta_rounds)
    ledger = BlockchainLedger()

    print(f"\n===== STARTING {args.num_rounds} FEDERATED ROUNDS =====")
    for r in range(1, args.num_rounds + 1):
        local_weights = []
        losses = []
        accuracies = []
        sample_counts = []

        for cid, loader in enumerate(loaders):
            w_dict, loss, acc, count = local_client_update(cid, global_model, loader, device, epochs=args.local_epochs)
            local_weights.append(w_dict)
            losses.append(loss)
            accuracies.append(acc)
            sample_counts.append(count)

        rupa_w = compute_rupa_weights(losses, client_rarity_scores[:len(losses)], sample_counts)
        agg_w = secure_aggregate_round(local_weights, rupa_w)
        global_model.load_state_dict(agg_w)

        avg_loss = sum(losses) / len(losses)
        avg_acc = sum(accuracies) / len(accuracies)
        ledger.record_round(r, avg_loss, avg_acc)
        print(f"Round {r:02d}/{args.num_rounds:02d} | Avg Loss: {avg_loss:.4f} | Avg Acc: {avg_acc*100:.2f}%")

    print("\nFederated Training Complete!")


if __name__ == "__main__":
    main()
