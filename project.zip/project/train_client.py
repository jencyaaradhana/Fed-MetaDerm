"""
train_client.py
----------------
End-to-end LOCAL HOSPITAL training pipeline.

Stages:
  Stage 0 (SSL)  : SimCLR self-supervised pre-training [optional, Hospital 3/N]
  Stage 1 (DTL)  : frozen backbone, train head only
  Stage 2 (DTLS) : unfreeze last 1/3 of backbone
  Stage 3        : full fine-tune at low LR

After training:
  - Saves best checkpoint + prototype bank + history JSON
  - Runs MC-Dropout uncertainty estimation on val set
  - Generates ScoreCAM + LIME explainability panels
  - Returns full dict for federated aggregation / personalization
"""

import os
import json
import time
import copy
import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from config import Config
from dataset import make_dataloaders, apply_random_mix
from model import FedMetaDermClientModel, set_stage
from adversarial import generate_adversarial
from prototypes import PrototypeBank, prototypical_loss
from uncertainty import mc_dropout_predict
from explainability import run_explainability_batch
from self_supervised import SimCLRTrainer, make_ssl_loader


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def mixed_criterion(criterion, logits, labels_a, labels_b, lam):
    return lam * criterion(logits, labels_a) + (1 - lam) * criterion(logits, labels_b)


def compute_class_weights(class_counts, device):
    """Rarity-aware loss weighting: rarer classes get higher weight."""
    counts = torch.tensor(
        [max(class_counts.get(c, 1) if hasattr(class_counts, 'get')
             else class_counts.iloc[i] if hasattr(class_counts, 'iloc')
             else 1, 1)
         for i, c in enumerate(Config.CLASS_NAMES)],
        dtype=torch.float32, device=device
    )
    counts = torch.clamp(counts, min=1.0)
    weights = counts.sum() / (len(counts) * counts)
    return weights


def run_epoch(model, loader, optimizer, criterion, proto_bank, cfg, train=True):
    model.train() if train else model.eval()
    total_loss, total_correct, total_count = 0.0, 0, 0

    for images, labels in loader:
        images, labels = images.to(cfg.DEVICE), labels.to(cfg.DEVICE)

        if train:
            optimizer.zero_grad()

            # MixUp / CutMix / ResizeMix
            mixed_images, labels_a, labels_b, lam = apply_random_mix(
                images, labels, cfg)

            # Adversarial training
            if cfg.USE_ADVERSARIAL:
                adv_images = generate_adversarial(
                    model, images, labels, cfg, criterion)

            logits, embeddings = model(mixed_images, return_embedding=True)
            clean_loss = mixed_criterion(criterion, logits, labels_a, labels_b, lam)

            proto_loss = (
                prototypical_loss(embeddings, labels, proto_bank)
                if lam == 1.0 else torch.tensor(0.0, device=cfg.DEVICE)
            )

            loss = clean_loss + 0.3 * proto_loss

            if cfg.USE_ADVERSARIAL:
                adv_logits = model(adv_images)
                adv_loss   = criterion(adv_logits, labels)
                loss = loss + cfg.ADV_LOSS_WEIGHT * adv_loss

            loss.backward()
            optimizer.step()

            # Update prototypes from clean embeddings only
            with torch.no_grad():
                _, clean_emb = model(images, return_embedding=True)
                proto_bank.update(clean_emb, labels)

            preds = logits.argmax(dim=-1)
            total_correct += (
                (preds == labels_a).sum().item() if lam == 1.0 else 0
            )
            total_count  += labels.size(0)
            total_loss   += loss.item() * labels.size(0)

        else:
            with torch.no_grad():
                logits, embeddings = model(images, return_embedding=True)
                loss  = criterion(logits, labels)
                preds = logits.argmax(dim=-1)
                total_correct += (preds == labels).sum().item()
                total_count   += labels.size(0)
                total_loss    += loss.item() * labels.size(0)

    avg_loss = total_loss / max(total_count, 1)
    acc      = total_correct / max(total_count, 1)
    return avg_loss, acc


def train_one_hospital(hospital_id=None, cfg=Config,
                        global_model=None, global_prototypes=None,
                        load_only=False):
    """
    Full local training pipeline for one hospital.

    Args:
        hospital_id       : 0-indexed hospital ID (defaults to cfg.HOSPITAL_ID)
        cfg               : Config class
        global_model      : optional pre-trained global model to warm-start from
        global_prototypes : optional dict of global prototypes from server

    Returns:
        dict with model, proto_bank, history, best_val_acc, paths, class_counts
    """
    set_seed(cfg.SEED)
    cfg.make_dirs()
    if cfg.NUM_CLASSES == 0:
        cfg.load_classes_and_hospitals()
    hospital_id = cfg.HOSPITAL_ID if hospital_id is None else hospital_id

    hosp_name = (cfg.HOSPITAL_NAMES[hospital_id]
                 if hospital_id < len(cfg.HOSPITAL_NAMES) else str(hospital_id))
    print(f"\n{'='*65}")
    print(f"  Training Hospital {hospital_id}  ({hosp_name})")
    print(f"{'='*65}")

    train_loader, val_loader, class_counts = make_dataloaders(hospital_id)
    print("Local class distribution (real long-tail data):")
    non_zero = {k: v for k, v in class_counts.items() if v > 0}
    for cls, cnt in sorted(non_zero.items(), key=lambda x: x[1]):
        bar = "#" * min(int(cnt / max(non_zero.values()) * 30), 30)
        print(f"  {cls:35s} {cnt:5d}  {bar}")

    # ---- LOAD-ONLY fast-path (resume after server restart) --------------
    if load_only:
        best_path  = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_model.pt")
        proto_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_prototypes.pt")
        hist_path  = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_history.json")
        model = FedMetaDermClientModel(num_classes=cfg.NUM_CLASSES).to(cfg.DEVICE)
        best_val_acc = 0.0
        if os.path.exists(best_path):
            ckpt = torch.load(best_path, map_location=cfg.DEVICE, weights_only=False)
            sd = ckpt["model_state_dict"] if isinstance(ckpt, dict) and "model_state_dict" in ckpt else ckpt
            model.load_state_dict(sd)
            best_val_acc = ckpt.get("val_acc", 0.0) if isinstance(ckpt, dict) else 0.0
        model.eval()
        proto_bank = PrototypeBank(num_classes=cfg.NUM_CLASSES, device=cfg.DEVICE)
        if os.path.exists(proto_path):
            proto_bank.load(proto_path)
        history = json.load(open(hist_path)) if os.path.exists(hist_path) else []
        unc_path = os.path.join(cfg.OUTPUT_DIR, f"hospital_{hospital_id}_uncertainty.json")
        mean_entropy = 0.2
        if os.path.exists(unc_path):
            try:
                unc_data = json.load(open(unc_path))
                if unc_data:
                    mean_entropy = float(np.mean([r["predictive_entropy"] for r in unc_data]))
            except Exception:
                pass
        import pandas as pd
        from rupa import rarity_score as calc_rarity_score
        local_counts_dict = {c: int(class_counts.get(c, 0)) for c in cfg.CLASS_NAMES if class_counts.get(c, 0) > 0}
        rarity_val = 1.0
        try:
            if os.path.exists(cfg.MANIFEST_CSV):
                m_df = pd.read_csv(cfg.MANIFEST_CSV)
                global_counts = m_df["label"].value_counts().to_dict()
                total_g = float(sum(global_counts.values())) or 1.0
                pi = {c: cnt / total_g for c, cnt in global_counts.items()}
                rarity_val = calc_rarity_score(local_counts_dict, pi)
        except Exception:
            pass
        print(f"  [RESUME LOADED] Hospital {hospital_id} ({hosp_name}): val_acc={best_val_acc:.4f}")
        return {
            "hospital_id":       hospital_id,
            "hospital_name":     hosp_name,
            "model":             model,
            "proto_bank":        proto_bank,
            "history":           history,
            "best_val_acc":      best_val_acc,
            "checkpoint_path":   best_path,
            "prototype_path":    proto_path,
            "class_counts":      class_counts,
            "rarity_score":      rarity_val,
            "uncertainty":       mean_entropy,
            "reliability_score": 1.0 / (1.0 + mean_entropy),
            "num_samples":       len(train_loader.dataset),
            "val_loader":        val_loader,
            "train_loader":      train_loader,
        }

    # ---- Build model (warm-start from global if provided) ---------------
    model = FedMetaDermClientModel(num_classes=cfg.NUM_CLASSES).to(cfg.DEVICE)
    if global_model is not None:
        try:
            model.load_state_dict(global_model.state_dict())
            print("[train] Warm-started from global model.")
        except Exception as e:
            print(f"[train] Could not load global model state: {e}. "
                  f"Training from scratch.")

    proto_bank = PrototypeBank(num_classes=cfg.NUM_CLASSES, device=cfg.DEVICE)

    class_weights = compute_class_weights(class_counts, cfg.DEVICE)
    criterion = nn.CrossEntropyLoss(
        weight=class_weights, label_smoothing=cfg.LABEL_SMOOTHING)

    history    = []
    best_val_acc = 0.0
    best_path  = os.path.join(
        cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_model.pt")

    # ---- Stage 0: Self-Supervised Pre-training (optional) ---------------
    if cfg.USE_SELF_SUPERVISED:
        print(f"\n--- Stage 0: SimCLR Self-Supervised Pre-training ---")
        ssl_loader = make_ssl_loader(
            train_loader.dataset, cfg.BATCH_SIZE, cfg.NUM_WORKERS)
        ssl_trainer = SimCLRTrainer(model, device=cfg.DEVICE)
        model = ssl_trainer.pretrain(ssl_loader, epochs=cfg.SSL_EPOCHS)

    # ---- Stages 1-3: DTL / DTLS supervised training ---------------------
    stages = [
        (1, cfg.STAGE1_EPOCHS, cfg.LR_HEAD,   "frozen backbone"),
        (2, cfg.STAGE2_EPOCHS, cfg.LR_STAGE2, "partial unfreeze"),
        (3, cfg.STAGE3_EPOCHS, cfg.LR_STAGE3, "full fine-tune"),
    ]

    global_epoch = 0
    checkpoint_interval = getattr(cfg, 'CHECKPOINT_INTERVAL', 15)
    periodic_ckpt_dir = os.path.join(cfg.CHECKPOINT_DIR, 'periodic')
    os.makedirs(periodic_ckpt_dir, exist_ok=True)

    for stage_id, n_epochs, lr, stage_desc in stages:
        if n_epochs == 0:
            continue
        print(f"\n--- Stage {stage_id} ({stage_desc}), "
              f"{n_epochs} epochs, lr={lr} ---")
        set_stage(model, stage_id)
        trainable = [p for p in model.parameters() if p.requires_grad]
        optimizer = AdamW(trainable, lr=lr, weight_decay=cfg.WEIGHT_DECAY)
        scheduler = CosineAnnealingLR(optimizer, T_max=max(n_epochs, 1))

        for epoch in range(n_epochs):
            t0 = time.time()
            tr_loss, tr_acc = run_epoch(
                model, train_loader, optimizer, criterion,
                proto_bank, cfg, train=True)
            vl_loss, vl_acc = run_epoch(
                model, val_loader, optimizer, criterion,
                proto_bank, cfg, train=False)
            scheduler.step()
            global_epoch += 1
            dt = time.time() - t0

            print(f"  [s{stage_id}|ep{epoch+1:02d}/{n_epochs}|g{global_epoch:03d}] "
                  f"tr_loss={tr_loss:.4f} tr_acc={tr_acc:.4f} "
                  f"vl_loss={vl_loss:.4f} vl_acc={vl_acc:.4f} "
                  f"({dt:.1f}s)")

            history.append({
                "stage": stage_id, "epoch": epoch + 1,
                "global_epoch": global_epoch,
                "train_loss": tr_loss, "train_acc": tr_acc,
                "val_loss": vl_loss, "val_acc": vl_acc,
            })

            if vl_acc > best_val_acc:
                best_val_acc = vl_acc
                torch.save({
                    "model_state_dict": model.state_dict(),
                    "val_acc": vl_acc,
                    "stage": stage_id, "epoch": epoch + 1,
                }, best_path)
                print(f"    [OK] new best saved (val_acc={vl_acc:.4f})")

            # ── Periodic checkpoint every checkpoint_interval global epochs ──
            if global_epoch % checkpoint_interval == 0:
                periodic_path = os.path.join(
                    periodic_ckpt_dir,
                    f"hospital_{hospital_id}_epoch_{global_epoch:03d}.pt"
                )
                torch.save({
                    "model_state_dict": model.state_dict(),
                    "val_acc":    vl_acc,
                    "train_acc":  tr_acc,
                    "train_loss": tr_loss,
                    "val_loss":   vl_loss,
                    "stage":      stage_id,
                    "epoch":      epoch + 1,
                    "global_epoch": global_epoch,
                    "hospital_id":  hospital_id,
                }, periodic_path)
                print(f"    [CKPT] Epoch {global_epoch:03d} saved -> {periodic_path}")

    # ---- Save prototypes + history ---------------------------------------
    proto_path = os.path.join(
        cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_prototypes.pt")
    proto_bank.save(proto_path)

    hist_path = os.path.join(
        cfg.CHECKPOINT_DIR, f"hospital_{hospital_id}_history.json")
    with open(hist_path, "w") as f:
        json.dump(history, f, indent=2)

    print(f"\n  Best val_acc = {best_val_acc:.4f}")
    print(f"  Checkpoint  -> {best_path}")
    print(f"  Prototypes  -> {proto_path}")

    # ---- Reload best model ----------------------------------------------
    ckpt = torch.load(best_path, map_location=cfg.DEVICE)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    # ---- MC-Dropout uncertainty on val set ------------------------------
    print("\n  Running MC-Dropout uncertainty estimation on val set...")
    unc_records = []
    for images, labels in val_loader:
        images = images.to(cfg.DEVICE)
        mean_probs, entropy, mi, _ = mc_dropout_predict(
            model, images, T=cfg.MC_DROPOUT_PASSES)
        preds = mean_probs.argmax(dim=-1)
        for i in range(images.size(0)):
            unc_records.append({
                "true_class":      cfg.CLASS_NAMES[labels[i].item()],
                "predicted_class": cfg.CLASS_NAMES[preds[i].item()],
                "confidence":      mean_probs[i, preds[i]].item(),
                "predictive_entropy": entropy[i].item(),
                "epistemic_bald":  mi[i].item(),
            })

    unc_path = os.path.join(
        cfg.OUTPUT_DIR, f"hospital_{hospital_id}_uncertainty.json")
    with open(unc_path, "w") as f:
        json.dump(unc_records, f, indent=2)
    print(f"  Uncertainty -> {unc_path}")

    # ---- ScoreCAM + LIME explainability panels --------------------------
    print("\n  Generating ScoreCAM + LIME explainability panels...")
    expl_dir = os.path.join(
        cfg.OUTPUT_DIR, f"hospital_{hospital_id}_explainability")
    reports = run_explainability_batch(
        model, proto_bank, val_loader, expl_dir,
        num_samples=cfg.NUM_EXPLAIN_SAMPLES,
        use_lime=cfg.USE_LIME,
    )
    with open(os.path.join(expl_dir, "reports.json"), "w") as f:
        json.dump(reports, f, indent=2)
    print(f"  Explainability -> {expl_dir}")

    # ---- Mean reliability score & Disease Rarity Score (Eq. 13) ---------
    mean_entropy = float(np.mean([r["predictive_entropy"] for r in unc_records])) if unc_records else 0.2
    reliability_score = 1.0 / (1.0 + mean_entropy)
    uncertainty_score = mean_entropy

    # Compute exact Local Disease Rarity Score r_i = sum_c (q_ic / pi_c)
    import pandas as pd
    from rupa import rarity_score as calc_rarity_score
    local_counts_dict = {c: int(class_counts.get(c, 0)) for c in cfg.CLASS_NAMES if class_counts.get(c, 0) > 0}
    rarity_val = 1.0
    try:
        if os.path.exists(cfg.MANIFEST_CSV):
            m_df = pd.read_csv(cfg.MANIFEST_CSV)
            global_counts = m_df["label"].value_counts().to_dict()
            total_g = float(sum(global_counts.values())) or 1.0
            pi = {c: cnt / total_g for c, cnt in global_counts.items()}
            rarity_val = calc_rarity_score(local_counts_dict, pi)
    except Exception as e:
        print(f"[train] Fallback rarity score used: {e}")

    print(f"  [Client {hospital_id}] Disease Rarity Score r_i = {rarity_val:.4f} | Predictive Uncertainty u_i = {uncertainty_score:.4f}")

    return {
        "hospital_id":       hospital_id,
        "hospital_name":     hosp_name,
        "model":             model,
        "proto_bank":        proto_bank,
        "history":           history,
        "best_val_acc":      best_val_acc,
        "checkpoint_path":   best_path,
        "prototype_path":    proto_path,
        "class_counts":      class_counts,
        "rarity_score":      rarity_val,
        "uncertainty":       uncertainty_score,
        "reliability_score": reliability_score,
        "num_samples":       len(train_loader.dataset),
        "val_loader":        val_loader,
        "train_loader":      train_loader,
    }


if __name__ == "__main__":
    result = train_one_hospital()
    print(f"\nBest val_acc: {result['best_val_acc']:.4f}")
