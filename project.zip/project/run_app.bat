@echo off
title Meta-XPFL (Fed-MetaDerm) Diagnostic Web Dashboard
echo ======================================================================
echo   Launching Fed-MetaDerm Streamlit AI Diagnostic Dashboard...
echo ======================================================================
echo.

cd /d "%~dp0"

echo Closing any previous stuck server instances on port 8501...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr /r ":8501.*LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
)

set PYTHONPATH=C:\Users\Admin\AppData\Local\Programs\Python\Python311\Lib\site-packages
set MPLCONFIGDIR=%TEMP%\matplotlib
set STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
set TQDM_DISABLE=1

set "PY_EXE="
if exist "C:\Users\Admin\AppData\Local\Programs\Orange\python.exe" (
    set "PY_EXE=C:\Users\Admin\AppData\Local\Programs\Orange\python.exe"
) else if exist "C:\Users\Admin\AppData\Local\Programs\Orange\pythonw.exe" (
    set "PY_EXE=C:\Users\Admin\AppData\Local\Programs\Orange\pythonw.exe"
) else (
    set "PY_EXE=python"
)

echo Using Python runtime: %PY_EXE%
echo Opening dashboard in your browser at http://localhost:8501 ...
echo.
"%PY_EXE%" -m streamlit run app.py --server.port 8501 --server.address 127.0.0.1 --server.headless false --browser.gatherUsageStats false

pause
