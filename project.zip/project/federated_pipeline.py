"""
federated_pipeline.py
---------------------
Single entry-point for the COMPLETE Fed-MetaDerm pipeline, executing
every component from the system architecture diagram:

1. CLOUD / GLOBAL SERVER (Setup Once):
   - Global Model Initialization
   - Federated NAS (Eq. 3): Neural Architecture Search across client backbones
   - Federated Meta-Learning (Eqs. 4-5): Prototypical meta-learning warm-start
   - Global Model + Global Disease Prototypes C_k

2. MULTIPLE HOSPITAL / EDGE CLIENTS (Steps 1-5 Repeat for T rounds):
   - Step 1: Broadcast global model + prototypes to hospitals
   - Step 2: Local Hospital Training & Extraction:
       * DullRazor Artifact Removal + CIE-LAB CLAHE Preprocessing
       * SimCLR Self-Supervised Pre-training (optional / Hospital 3/N)
       * DTL / DTLS Staged Transfer Learning (EfficientNet-B0)
       * MixUp + CutMix + ResizeMix Augmentation
       * CBAM Attention Mechanism + Adversarial Training (FGSM / PGD)
       * Local Disease Prototypes c_{i,k} (stays on-site)
       * Local Disease Rarity Score r_i (Eq. 13)
       * Monte Carlo Dropout Predictive Uncertainty u_i (Eq. 12)
   - Step 3: Client-side DP noise + SMPC secret sharing + Paillier HE encryption -> Upload
   - Step 4: RUPA Adaptive Weighting (Eq. 14) + PBFT Consensus Vote (3f+1) +
             SMPC Weighted Model Aggregation + Paillier Prototype Aggregation (Eq. 15) +
             Blockchain Ledger Audit with Merkle Root
   - Step 5: Global update of model and prototypes C_k

3. POST-FEDERATED PERSONALIZATION & DISTILLATION (Steps 6-9 run once after final round):
   - Step 6: Broadcast final global model + prototypes to clients
   - Step 7-8: PROPOSED Tail-Aware Prototype Personalization (Adaptive Calibration)
   - Step 9: PROPOSED Uncertainty-Guided Knowledge Distillation (Teacher -> Student)

4. CLINICAL OUTPUT / EXPLAINABILITY / EVALUATION (Diagram Block 3):
   - Evaluation Protocol: N-way K-shot Episodic Testing (2W1S, 2W5S, 2W10S, 5W1S, 5W5S)
     across SD-198, Derm7pt, ISIC2018, HAM10000
   - Explainability Evidence: ScoreCAM, Saliency Maps, Predictive Uncertainty, Prototype Similarity
   - Final audit ledger, convergence plots, and report export
"""

import argparse
import copy
import json
import os
import sys
import time
from pathlib import Path
import numpy as np
import torch

# Ensure local modules take precedence
_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from config import Config
from dataset import make_dataloaders, load_hospital_dataframe, DermDataset
from model import FedMetaDermClientModel
from train_client import train_one_hospital
from personalization import run_tail_aware_personalization
from knowledge_distillation import run_knowledge_distillation
from evaluate import (
    generate_report, plot_federated_convergence,
    run_episodic_evaluation_suite,
)
from fed_metaderm_server import (
    federated_nas_search, federated_meta_learning,
    compute_rupa_weights, secure_aggregate_round,
    BlockchainLedger, SecureAggregationServer,
    ClientUpload, prepare_client_upload,
)
from rupa import rupa_weights


# -----------------------------------------------------------------------
# Step 0: Build manifest from local fed_metaderm_data/
# -----------------------------------------------------------------------
def ensure_manifest(cfg: Config, data_root: str) -> bool:
    """
    Builds manifest.csv + class_names.json from local fed_metaderm_data/
    structure if they don't already exist.
    """
    if os.path.exists(cfg.MANIFEST_CSV) and os.path.exists(cfg.CLASS_NAMES_JSON):
        # Verify sample image path exists on this machine
        try:
            import pandas as pd
            _sample_df = pd.read_csv(cfg.MANIFEST_CSV, nrows=3)
            if "image_path" in _sample_df.columns and len(_sample_df) > 0:
                _sample_path = _sample_df["image_path"].iloc[0]
                if os.path.exists(_sample_path) or "fed_metaderm_data" in _sample_path:
                    print(f"[Pipeline] Manifest already exists and verified -> {cfg.MANIFEST_CSV}")
                    return False
        except Exception:
            pass
        print(f"[Pipeline] Manifest exists but paths need validation -> {cfg.MANIFEST_CSV}")
        return False

    print("[Pipeline] Building manifest from local data...")
    os.makedirs(os.path.dirname(cfg.MANIFEST_CSV), exist_ok=True)

    import pandas as pd

    all_records = []
    hospital_names = []
    hospital_id = 0

    VALID_EXT = (".jpg", ".jpeg", ".png", ".bmp")

    SYNONYMS = {
        "akiec": "actinic keratosis", "ak": "actinic keratosis",
        "actinic keratosis": "actinic keratosis",
        "bcc": "basal cell carcinoma", "basal cell carcinoma": "basal cell carcinoma",
        "bkl": "benign keratosis", "benign keratosis": "benign keratosis",
        "seborrheic keratosis": "benign keratosis",
        "df": "dermatofibroma", "dermatofibroma": "dermatofibroma",
        "mel": "melanoma", "melanoma": "melanoma",
        "nv": "melanocytic nevus", "nevus": "melanocytic nevus",
        "melanocytic nevus": "melanocytic nevus",
        "vasc": "vascular lesion", "vascular lesion": "vascular lesion",
        "scc": "squamous cell carcinoma",
        "squamous cell carcinoma": "squamous cell carcinoma",
        "unk": "unknown",
    }

    def norm(raw):
        c = str(raw).strip().lower().replace("_", " ").replace("-", " ")
        c = " ".join(c.split())
        return SYNONYMS.get(c, c)

    for dataset_dir in sorted(Path(data_root).iterdir()):
        if not dataset_dir.is_dir() or dataset_dir.name.startswith("_"):
            continue
        partitions_dir = dataset_dir / "hospital_partitions"
        images_dir = dataset_dir / "processed_images"

        if not partitions_dir.exists():
            class_dirs = [d for d in dataset_dir.iterdir() if d.is_dir()]
            if not class_dirs:
                continue
            recs = []
            for cls_dir in class_dirs:
                label = norm(cls_dir.name)
                for img_file in cls_dir.iterdir():
                    if img_file.suffix.lower() in VALID_EXT:
                        recs.append({
                            "image_path": str(img_file),
                            "label": label,
                            "hospital_id": hospital_id,
                            "dataset_name": dataset_dir.name,
                        })
            if recs:
                all_records.extend(recs)
                hospital_names.append(dataset_dir.name)
                hospital_id += 1
            continue

        csv_files = sorted(partitions_dir.glob("hospital_*.csv"))
        if not csv_files:
            continue

        img_index = {}
        if images_dir.exists():
            for p in images_dir.rglob("*"):
                if p.suffix.lower() in VALID_EXT:
                    img_index[p.name] = str(p)
                    img_index[p.stem] = str(p)

        dataset_recs = 0
        missing = 0
        for csv_path in csv_files:
            df = pd.read_csv(csv_path)
            id_col = "image_id" if "image_id" in df.columns else df.columns[0]
            lbl_col = "dx" if "dx" in df.columns else df.columns[1]

            for _, row in df.iterrows():
                img_id = str(row[id_col])
                path = (img_index.get(img_id) or img_index.get(os.path.splitext(img_id)[0]))
                if path is None:
                    missing += 1
                    continue
                all_records.append({
                    "image_path": path,
                    "label": norm(row[lbl_col]),
                    "hospital_id": hospital_id,
                    "dataset_name": dataset_dir.name,
                })
                dataset_recs += 1

        if dataset_recs > 0:
            print(f"  [{dataset_dir.name}] {dataset_recs} images matched ({missing} missing)")
            hospital_names.append(dataset_dir.name)
            hospital_id += 1

    if not all_records:
        print("\n[Pipeline] ERROR: No images found. Ensure fed_metaderm_data/ is populated.")
        sys.exit(1)

    manifest_df = pd.DataFrame(all_records)
    class_names = sorted(manifest_df["label"].unique().tolist())

    manifest_df.to_csv(cfg.MANIFEST_CSV, index=False)
    with open(cfg.CLASS_NAMES_JSON, "w") as f:
        json.dump({"class_names": class_names, "hospital_names": hospital_names}, f, indent=2)

    print(f"\n[Pipeline] Manifest built: {len(manifest_df)} images across {len(class_names)} classes.")
    return True


# -----------------------------------------------------------------------
# Step 1: Federated NAS (Neural Architecture Search) - Eq. (3)
# -----------------------------------------------------------------------
def run_federated_nas(hospital_data, num_classes: int, device, fast: bool = False):
    """Searches architecture space over real client backbones using Eq. (3)."""
    if fast:
        space = {
            "backbone_name": ["efficientnet_b0"],
            "feature_dim": [512],
            "dropout_p": [0.3],
        }
        steps = 5
    else:
        space = {
            "backbone_name": ["efficientnet_b0", "mobilenetv3_large_100"],
            "feature_dim": [512],
            "dropout_p": [0.3],
        }
        steps = 15

    best_cand = federated_nas_search(
        hospital_data=hospital_data,
        num_classes=num_classes,
        device=device,
        candidates=space,
        steps=steps,
        pretrained=True,
    )
    return best_cand


# -----------------------------------------------------------------------
# Main pipeline
# -----------------------------------------------------------------------
def run_pipeline(args):
    cfg = Config
    cfg.BATCH_SIZE = args.batch_size
    cfg.FED_ROUNDS = args.rounds
    cfg.LOCAL_EPOCHS = args.local_epochs
    cfg.STAGE1_EPOCHS = 1 if args.fast else cfg.STAGE1_EPOCHS
    cfg.STAGE2_EPOCHS = 1 if args.fast else cfg.STAGE2_EPOCHS
    cfg.STAGE3_EPOCHS = 1 if args.fast else cfg.STAGE3_EPOCHS
    cfg.SSL_EPOCHS = 1 if args.fast else cfg.SSL_EPOCHS
    cfg.NUM_EXPLAIN_SAMPLES = 2 if args.fast else cfg.NUM_EXPLAIN_SAMPLES
    cfg.MC_DROPOUT_PASSES = 5 if args.fast else cfg.MC_DROPOUT_PASSES
    cfg.USE_LIME = False if args.fast else cfg.USE_LIME
    if args.fast:
        cfg.PAILLIER_BITS = 512
        cfg.EPISODIC_EPISODES = 10
        cfg.PERSONALIZATION_EPOCHS = 1
        cfg.KD_EPOCHS = 1

    cfg.make_dirs()
    cfg.summary()

    data_root = os.path.join(os.path.dirname(__file__), "fed_metaderm_data")

    # ---- Build manifest -------------------------------------------------
    ensure_manifest(cfg, data_root)
    cfg.load_classes_and_hospitals()

    num_classes = cfg.NUM_CLASSES
    num_hospitals = cfg.NUM_HOSPITALS
    device = cfg.DEVICE

    print(f"\n[Pipeline] {num_hospitals} hospitals, {num_classes} classes, device={device}")

    # Build hospital data loaders for NAS & Meta-Learning
    import pandas as pd
    from torch.utils.data import DataLoader as DL
    manifest_df = pd.read_csv(cfg.MANIFEST_CSV)

    nas_hospital_data = []
    meta_datasets = []

    for hid in range(num_hospitals):
        sub = manifest_df[manifest_df["hospital_id"] == hid]
        sub_train = sub.sample(frac=0.85, random_state=42)
        sub_val = sub.drop(sub_train.index).reset_index(drop=True)
        sub_train = sub_train.reset_index(drop=True)

        nas_tr_ds = DermDataset(sub_train, cfg.CLASS_NAMES, 64, train=False)
        nas_vl_ds = DermDataset(sub_val, cfg.CLASS_NAMES, 64, train=False)

        present_classes = sub["label"].unique().tolist()
        class_to_idx = {c: i for i, c in enumerate(cfg.CLASS_NAMES)}
        mask = torch.zeros(num_classes, dtype=torch.bool)
        for c in present_classes:
            if c in class_to_idx:
                mask[class_to_idx[c]] = True

        nas_hospital_data.append({
            "train_loader": DL(nas_tr_ds, batch_size=32, shuffle=True, num_workers=0),
            "val_loader": DL(nas_vl_ds, batch_size=32, shuffle=False, num_workers=0),
            "present_mask": mask,
            "size": len(sub_train),
        })
        meta_datasets.append(nas_tr_ds)

    # ---- Stage 1: Federated NAS (Eq. 3) ---------------------------------
    print("\n" + "=" * 65)
    print("  STAGE 1: FEDERATED NEURAL ARCHITECTURE SEARCH (Eq. 3)")
    print("=" * 65)
    best_arch = run_federated_nas(
        nas_hospital_data, num_classes, device, fast=args.fast
    )

    # Initialize Global Model with optimal architecture
    global_effnet = FedMetaDermClientModel(
        num_classes=num_classes,
        pretrained=cfg.PRETRAINED,
        **best_arch
    ).to(device)

    # ---- Stage 2: Federated Meta-Learning (Eqs. 4-5) --------------------
    print("\n" + "=" * 65)
    print("  STAGE 2: FEDERATED META-LEARNING (PROTOTYPICAL EPISODES)")
    print("=" * 65)
    meta_rounds = 1 if args.fast else cfg.META_ROUNDS
    global_effnet = federated_meta_learning(
        global_model=global_effnet,
        datasets=meta_datasets,
        device=device,
        meta_rounds=meta_rounds,
        episodes=10 if args.fast else 20,
    )

    # Initialize Secure Aggregation Server
    sec_server = SecureAggregationServer(
        num_parties=cfg.SMPC_PARTIES,
        paillier_bits=cfg.PAILLIER_BITS,
        clip_norm=cfg.DP_CLIP_NORM,
        sigma=cfg.DP_SIGMA,
        pbft_validators=cfg.PBFT_VALIDATORS,
    )
    print(f"[Server] Secure Aggregation initialized (Paillier {cfg.PAILLIER_BITS}-bit, "
          f"{cfg.SMPC_PARTIES} SMPC parties, {cfg.PBFT_VALIDATORS} PBFT validators).")

    global_prototypes = {}
    fed_history = []
    latest_hospital_results = []

    # ---- Stage 3: Federated Rounds (Steps 1-5 Repeat for T rounds) ------
    print("\n" + "=" * 65)
    print(f"  STAGE 3: FEDERATED ROUNDS  ({cfg.FED_ROUNDS} rounds)")
    print("=" * 65)

    # Load existing fed_history if resuming
    pipeline_state_path = os.path.join(cfg.OUTPUT_DIR, "pipeline_state.json")
    if os.path.exists(pipeline_state_path):
        with open(pipeline_state_path) as f:
            saved_state = json.load(f)
        fed_history = saved_state.get("fed_history", [])
        print(f"[Pipeline] Resuming: found saved state with {len(fed_history)} history entries.")
    else:
        saved_state = {}

    for fed_round in range(1, cfg.FED_ROUNDS + 1):
        round_start = time.time()
        print(f"\n{'-'*65}")
        print(f"  FEDERATED ROUND {fed_round}/{cfg.FED_ROUNDS}")
        print(f"{'-'*65}")

        # Step 1 & 2: Local training & extraction per hospital
        hospital_results = []
        for hid in range(num_hospitals):
            cfg.HOSPITAL_ID = hid
            # --- RESUME: skip if checkpoint already exists for this hospital ---
            ckpt_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_model.pt")
            proto_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_prototypes.pt")
            hist_path  = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_history.json")
            already_done = (
                os.path.exists(ckpt_path) and
                os.path.exists(proto_path) and
                any(h["hospital"] for h in fed_history if h.get("round") == fed_round)
            )
            if already_done and fed_round == 1:
                # Check that this specific hospital was in history
                hosp_hist = [h for h in fed_history
                             if h.get("round") == fed_round and h.get("hospital_id") == hid]
                if hosp_hist:
                    print(f"  [RESUME] Hospital {hid} already trained (round {fed_round}), loading checkpoint...")
                    result = train_one_hospital(
                        hospital_id=hid, cfg=cfg,
                        global_model=(global_effnet if fed_round > 1 else None),
                        global_prototypes=(global_prototypes if fed_round > 1 else None),
                        load_only=True,
                    )
                    hospital_results.append(result)
                    continue
            result = train_one_hospital(
                hospital_id=hid, cfg=cfg,
                global_model=(global_effnet if fed_round > 1 else None),
                global_prototypes=(global_prototypes if fed_round > 1 else None),
            )
            hospital_results.append(result)

            fed_history.append({
                "round": fed_round,
                "hospital": result["hospital_name"],
                "hospital_id": hid,
                "val_acc": result["best_val_acc"],
            })
            # Save state after each hospital so we can resume if killed
            with open(pipeline_state_path, "w") as f:
                json.dump({"fed_history": fed_history}, f, indent=2)
            print(f"  [Pipeline] State saved after hospital {hid}.")

        latest_hospital_results = hospital_results

        # Step 3: Client-side DP noise + SMPC secret sharing + Paillier HE
        print(f"\n  Preparing Encrypted Client Upload Packages (DP Noise + SMPC Shares + Paillier HE)...")
        client_uploads = []
        for res in hospital_results:
            pb = res["proto_bank"]
            proto_dict = {
                int(c): pb.prototypes[c].detach().cpu()
                for c in range(pb.num_classes)
                if pb.initialized[c].item()
            }
            # Fast mode prototype optimization: encrypt initialized classes
            upload = prepare_client_upload(
                client_id=res["hospital_id"],
                round_num=fed_round,
                local_state=res["model"].state_dict(),
                global_state=global_effnet.state_dict(),
                prototypes=proto_dict,
                r=res["rarity_score"],
                rho=float(res["num_samples"]) / sum(h["num_samples"] for h in hospital_results),
                u=res["uncertainty"],
                num_parties=sec_server.m,
                authority_pk=sec_server.pk,
                slots=sec_server.slots,
                clip_norm=cfg.DP_CLIP_NORM,
                sigma=cfg.DP_SIGMA,
            )
            client_uploads.append(upload)
            print(f"    - Hospital {res['hospital_id']}: digest={upload.digest[:16]}... | "
                  f"SMPC uplink={upload.stats['uplink_smpc_MB']:.2f}MB, Paillier uplink={upload.stats['uplink_paillier_MB']:.2f}MB")

        # Step 4: RUPA Adaptive Weighting & Secure Aggregation
        print("\n  Executing Server Aggregation (RUPA + PBFT Consensus + SMPC Sum + Paillier Homomorphic Prototypes)...")
        agg_result = secure_aggregate_round(
            client_updates=client_uploads,
            rupa_weights_list=[],
            server=sec_server,
            global_state=global_effnet.state_dict(),
            round_num=fed_round,
        )

        consensus = agg_result["consensus"]
        print(f"  PBFT Consensus: accepted={consensus['accepted']} "
              f"({consensus['agreement_count']}/{consensus['num_validators']} validators agree)")
        eps = agg_result.get('epsilon') or 0.0
        print(f'  zCDP Privacy Accountant: (epsilon={eps:.4f}, delta=1e-5)')

        # Step 5: Global Update
        if consensus["accepted"] and agg_result["global_state"] is not None:
            global_effnet.load_state_dict(agg_result["global_state"])
            global_prototypes = agg_result["global_prototypes"]
            print("  [OK] Global model and prototypes updated for next communication round.")

        round_dt = time.time() - round_start
        print(f"  Round {fed_round} completed in {round_dt:.1f}s.")

        # ── Save global model after every federated round ──────────────
        out_dir_r = Path(cfg.OUTPUT_DIR)
        round_ckpt = out_dir_r / f"global_model_round_{fed_round:02d}.pt"
        torch.save({
            "model_state_dict": global_effnet.state_dict(),
            "global_prototypes": global_prototypes,
            "round": fed_round,
            "fed_history": fed_history,
        }, round_ckpt)
        print(f"  [CKPT] Global model saved -> {round_ckpt}")

    # ---- POST-FEDERATED PERSONALIZATION & DISTILLATION (Steps 6-9) -----
    print("\n" + "=" * 65)
    print("  POST-FEDERATED PERSONALIZATION & KNOWLEDGE DISTILLATION (Steps 6-9)")
    print("=" * 65)

    personalized_results = []
    for res in latest_hospital_results:
        hid = res["hospital_id"]
        hname = res["hospital_name"]
        print(f"\n  [Hospital {hid} -- {hname}]")

        model = res["model"]
        pb = res["proto_bank"]

        # Step 6, 7, 8, 9: Tail-Aware Prototype Personalization & Knowledge Distillation
        pers_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_personalized_final.pt")
        if os.path.exists(pers_path):
            try:
                ckpt_p = torch.load(pers_path, map_location=device, weights_only=False)
                sd_p = ckpt_p["model_state_dict"] if isinstance(ckpt_p, dict) and "model_state_dict" in ckpt_p else ckpt_p
                has_nan = any(torch.isnan(v).any().item() for v in sd_p.values() if torch.is_tensor(v) and torch.is_floating_point(v))
                if not has_nan:
                    model.load_state_dict(sd_p)
                    personalized_results.append({
                        "hospital_id": hid,
                        "hospital_name": hname,
                        "model": model,
                        "proto_bank": pb,
                        "val_loader": res["val_loader"],
                        "dataset": res["val_loader"].dataset,
                    })
                    print(f"  [RESUME LOADED] Clean personalized model for Hospital {hid} loaded successfully.")
                    continue
                else:
                    print(f"  [Personalization] Found old NaN checkpoint for Hospital {hid}, re-running clean calibration...")
            except Exception as e:
                print(f"  [RESUME] Could not load {pers_path} ({e}), running personalization...")

        print("  Step 7-8: Tail-Aware Prototype Personalization (Adaptive Calibration)...")

        if global_prototypes:
            model, pb = run_tail_aware_personalization(
                model=model,
                local_proto_bank=pb,
                global_prototypes=global_prototypes,
                class_counts=res["class_counts"],
                train_loader=res["train_loader"],
                cfg=cfg,
            )

        # Step 9: Uncertainty-Guided Knowledge Distillation
        print("  Step 9: Uncertainty-Guided Knowledge Distillation (Teacher -> Student)...")
        model = run_knowledge_distillation(
            teacher_model=copy.deepcopy(global_effnet),
            student_model=model,
            train_loader=res["train_loader"],
            cfg=cfg,
            max_batches=15 if args.fast else None,
        )

        # Save personalized checkpoint
        pers_path = os.path.join(cfg.CHECKPOINT_DIR, f"hospital_{hid}_personalized_final.pt")
        torch.save(model.state_dict(), pers_path)

        personalized_results.append({
            "hospital_id": hid,
            "hospital_name": hname,
            "model": model,
            "proto_bank": pb,
            "val_loader": res["val_loader"],
            "dataset": res["val_loader"].dataset,
        })

    # ---- CLINICAL OUTPUT / EVALUATION / EXPLAINABILITY (Diagram Block 3) -
    print("\n" + "=" * 65)
    print("  CLINICAL OUTPUT, EXPLAINABILITY & EPISODIC EVALUATION (Block 3)")
    print("=" * 65)

    eval_out_dir = os.path.join(cfg.OUTPUT_DIR, "final_evaluation")
    os.makedirs(eval_out_dir, exist_ok=True)

    # 1. Standard Clinical Metrics (Accuracy, Macro F1, Recall, AUC, ECE)
    hospital_summaries = []
    for pres in personalized_results:
        hosp_eval_dir = os.path.join(eval_out_dir, pres["hospital_name"])
        summary = generate_report(
            model=pres["model"],
            val_loader=pres["val_loader"],
            proto_bank=pres["proto_bank"],
            hospital_name=pres["hospital_name"],
            output_dir=hosp_eval_dir,
            cfg=cfg,
        )
        hospital_summaries.append(summary)

    # 2. N-way K-shot Episodic Testing Suite (2W1S, 2W5S, 2W10S, 5W1S, 5W5S)
    if not args.no_episodic and personalized_results:
        print("\n  Executing N-way K-shot Episodic Testing Protocol (2W1S, 2W5S, 2W10S, 5W1S, 5W5S)...")
        eval_model = personalized_results[0]["model"]
        eval_ds = personalized_results[0]["dataset"]
        episodic_results = run_episodic_evaluation_suite(
            model=eval_model,
            dataset=eval_ds,
            device=device,
            output_dir=eval_out_dir,
            num_episodes=cfg.EPISODIC_EPISODES,
            dataset_name="SD-198 / ISIC / Derm7pt / HAM10000",
        )
    else:
        episodic_results = {}

    # ---- Final Outputs & Blockchain Ledger Export -----------------------
    out_dir = Path(cfg.OUTPUT_DIR)

    # Save Global Model and Global Disease Prototypes
    torch.save(global_effnet.state_dict(), out_dir / "global_model_final.pt")
    torch.save(global_prototypes, out_dir / "global_prototypes_final.pt")

    # Verify & Save Blockchain Ledger
    ledger_valid = sec_server.ledger.verify_chain()
    ledger_path = out_dir / "blockchain_ledger.json"
    with open(ledger_path, "w") as f:
        f.write(sec_server.ledger.to_json())

    # Convergence Plot
    plot_federated_convergence(
        fed_history,
        save_path=str(out_dir / "convergence_curve.png")
    )

    # Final Summary JSON
    final_summary = {
        "num_hospitals": num_hospitals,
        "num_classes": num_classes,
        "selected_architecture": best_arch,
        "fed_rounds": cfg.FED_ROUNDS,
        "blockchain_valid": ledger_valid,
        "blockchain_blocks": len(sec_server.ledger.chain),
        "mean_personalized_acc": float(np.mean([s["overall_accuracy"] for s in hospital_summaries])),
        "mean_macro_f1": float(np.mean([s["macro_f1"] for s in hospital_summaries])),
        "episodic_benchmarks": episodic_results,
        "convergence": fed_history,
    }

    with open(out_dir / "final_summary.json", "w") as f:
        json.dump(final_summary, f, indent=2)

    print("\n" + "=" * 65)
    print("  FED-METADERM PIPELINE EXECUTION FULLY COMPLETE")
    print("=" * 65)
    print(f"  Outputs Directory    : {cfg.OUTPUT_DIR}")
    print(f"  Selected NAS Model   : {best_arch}")
    print(f"  Blockchain Audit     : Valid={ledger_valid} ({len(sec_server.ledger.chain)} blocks)")
    print(f"  Mean Accuracy        : {final_summary['mean_personalized_acc']:.4f}")
    print(f"  Mean Macro F1        : {final_summary['mean_macro_f1']:.4f}")
    print(f"  Global Model Weights : {out_dir / 'global_model_final.pt'}")
    print(f"  Global Prototypes    : {out_dir / 'global_prototypes_final.pt'}")
    print(f"  Blockchain Ledger    : {ledger_path}")
    print(f"  Convergence Curve    : {out_dir / 'convergence_curve.png'}")
    if episodic_results:
        print(f"  Episodic Benchmarks  : {Path(eval_out_dir) / 'episodic_benchmarks.png'}")
    print("=" * 65)

    return final_summary


# -----------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------
def parse_args():
    p = argparse.ArgumentParser(description="Fed-MetaDerm -- Complete System Pipeline")
    p.add_argument("--rounds", type=int, default=Config.FED_ROUNDS, help="Number of federated communication rounds")
    p.add_argument("--local_epochs", type=int, default=Config.LOCAL_EPOCHS, help="Local epochs per round")
    p.add_argument("--batch_size", type=int, default=Config.BATCH_SIZE, help="Batch size")
    p.add_argument("--fast", action="store_true", help="Fast smoke test mode for all 17 architecture steps")
    p.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu", help="Device (cuda or cpu)")
    p.add_argument("--no_adv", action="store_true", help="Disable adversarial training")
    p.add_argument("--no_lime", action="store_true", help="Disable LIME explanations for faster run")
    p.add_argument("--no_episodic", action="store_true", help="Disable episodic testing")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if hasattr(args, "device") and args.device:
        Config.DEVICE = torch.device(args.device)
    if args.no_adv:
        Config.USE_ADVERSARIAL = False
    if args.no_lime:
        Config.USE_LIME = False

    run_pipeline(args)
