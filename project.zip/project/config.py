"""
config.py
---------
Central configuration for the Fed-MetaDerm pipeline.
Supports both LOCAL training (using fed_metaderm_data/ folder) and
Kaggle training (auto-detected). No synthetic data anywhere.

Edit LOCAL_DATA_ROOT or KAGGLE_DATA_ROOT to match your setup.
Everything else can run as-is for local training on HAM10000 + ISIC2018.
"""

import os
import torch


def _is_kaggle():
    return os.path.exists("/kaggle/working")


def _is_colab():
    return os.path.exists("/content") or "COLAB_GPU" in os.environ


class Config:
    # ------------------------------------------------------------------
    # ENVIRONMENT DETECTION -- auto-selects paths
    # ------------------------------------------------------------------
    IS_KAGGLE = _is_kaggle()
    IS_COLAB  = _is_colab()

    # LOCAL / COLAB paths (used when not on Kaggle)
    _base_dir = os.path.dirname(os.path.abspath(__file__))
    _colab_data = "/content/fed_metaderm_data"
    _local_data = os.path.join(_base_dir, "fed_metaderm_data")
    LOCAL_DATA_ROOT    = _colab_data if (IS_COLAB and os.path.exists(_colab_data)) else _local_data
    LOCAL_OUTPUT_DIR   = os.path.join(_base_dir, "outputs")
    LOCAL_CKPT_DIR     = os.path.join(_base_dir, "checkpoints")
    LOCAL_MANIFEST_DIR = os.path.join(_base_dir, "manifest")

    # KAGGLE paths (used when running on Kaggle)
    KAGGLE_MANIFEST_DIR = "/kaggle/working/fedmetaderm_manifest"
    KAGGLE_OUTPUT_DIR   = "/kaggle/working/fedmetaderm_outputs"
    KAGGLE_CKPT_DIR     = "/kaggle/working/fedmetaderm_checkpoints"

    # ------------------------------------------------------------------
    # RESOLVED PATHS  (don't edit these -- set LOCAL_* or KAGGLE_* above)
    # ------------------------------------------------------------------
    MANIFEST_CSV      = (f"{KAGGLE_MANIFEST_DIR}/manifest.csv" if IS_KAGGLE
                         else os.path.join(LOCAL_MANIFEST_DIR, "manifest.csv"))
    CLASS_NAMES_JSON  = (f"{KAGGLE_MANIFEST_DIR}/class_names.json" if IS_KAGGLE
                         else os.path.join(LOCAL_MANIFEST_DIR, "class_names.json"))
    OUTPUT_DIR        = KAGGLE_OUTPUT_DIR   if IS_KAGGLE else LOCAL_OUTPUT_DIR
    CHECKPOINT_DIR    = KAGGLE_CKPT_DIR     if IS_KAGGLE else LOCAL_CKPT_DIR

    # ------------------------------------------------------------------
    # CLASSES / HOSPITALS  (populated at runtime by load_classes_and_hospitals)
    # ------------------------------------------------------------------
    CLASS_NAMES   = []
    NUM_CLASSES   = 0
    HOSPITAL_NAMES = []
    NUM_HOSPITALS  = 0

    VAL_FRACTION = 0.15
    SPLIT_SEED   = 42
    HOSPITAL_ID  = 0          # which hospital to train (0-indexed)

    # ------------------------------------------------------------------
    # MODEL
    # ------------------------------------------------------------------
    BACKBONE    = "efficientnet_b0"   # any timm model
    PRETRAINED  = True
    EMBED_DIM   = 256
    DROPOUT_P   = 0.3
    IMG_SIZE    = 224

    # ------------------------------------------------------------------
    # TRAINING  (DTL / DTLS staged transfer learning)
    # ------------------------------------------------------------------
    STAGE1_EPOCHS = 3     # frozen backbone → head only
    STAGE2_EPOCHS = 4     # unfreeze last 1/3 of backbone
    STAGE3_EPOCHS = 5     # full fine-tune at low LR
    BATCH_SIZE    = 32    # vectorized CPU batching
    NUM_WORKERS   = 2

    LR_HEAD      = 1e-3
    LR_STAGE2    = 1e-4
    LR_STAGE3    = 1e-5
    WEIGHT_DECAY = 1e-4
    LABEL_SMOOTHING = 0.1

    # ------------------------------------------------------------------
    # AUGMENTATION  (MixUp / CutMix / ResizeMix)
    # ------------------------------------------------------------------
    USE_MIXUP      = True
    USE_CUTMIX     = True
    USE_RESIZEMIX  = True
    AUG_PROB       = 0.5
    MIXUP_ALPHA    = 0.2
    CUTMIX_ALPHA   = 1.0
    RESIZEMIX_SCALE = (0.1, 0.8)

    # ------------------------------------------------------------------
    # ADVERSARIAL TRAINING
    # ------------------------------------------------------------------
    USE_ADVERSARIAL  = False     # Disabled for fast CPU training
    ADV_METHOD       = "fgsm"
    ADV_EPS          = 4 / 255
    ADV_ALPHA        = 1 / 255
    ADV_STEPS        = 3
    ADV_LOSS_WEIGHT  = 0.5

    # ------------------------------------------------------------------
    # SELF-SUPERVISED LEARNING  (Hospital 3/N — SimCLR pre-training)
    # ------------------------------------------------------------------
    USE_SELF_SUPERVISED  = False          # set True for Hospital 3/N
    SSL_EPOCHS           = 5
    SSL_LR               = 1e-3
    SSL_TEMPERATURE      = 0.07
    SSL_PROJECTION_DIM   = 128

    # ------------------------------------------------------------------
    # PROTOTYPES
    # ------------------------------------------------------------------
    PROTOTYPE_MOMENTUM = 0.9

    # ------------------------------------------------------------------
    # MONTE CARLO DROPOUT / UNCERTAINTY
    # ------------------------------------------------------------------
    MC_DROPOUT_PASSES = 20

    # ------------------------------------------------------------------
    # PERSONALIZATION  (Tail-Aware Prototype Personalization)
    # ------------------------------------------------------------------
    PERSONALIZATION_ALPHA = 0.4   # blend weight: 0 = fully global, 1 = fully local
    PERSONALIZATION_EPOCHS = 3    # fine-tune head after prototype calibration

    # ------------------------------------------------------------------
    # KNOWLEDGE DISTILLATION  (Uncertainty-Guided KD)
    # ------------------------------------------------------------------
    KD_TEMPERATURE   = 4.0       # softening temperature for teacher logits
    KD_ALPHA         = 0.7       # weight of soft KL loss vs hard CE loss
    KD_EPOCHS        = 3
    CHECKPOINT_INTERVAL = 15   # save a periodic .pt every N global epochs
    KD_LR            = 5e-5
    KD_UNCERTAINTY_GATE = 0.8    # teacher predictions with entropy above this
                                  # percentile are down-weighted in distillation

    # ------------------------------------------------------------------
    # EXPLAINABILITY
    # ------------------------------------------------------------------
    SCORECAM_MAX_BATCH  = 32     # how many masks to score per forward pass
    NUM_EXPLAIN_SAMPLES = 8      # val images to visualize per run
    USE_LIME            = True   # also generate LIME explanations

    # ------------------------------------------------------------------
    # PREPROCESSING (DullRazor Hair Removal + CIE-LAB CLAHE)
    # ------------------------------------------------------------------
    USE_PREPROCESSING   = True
    PREPROCESS_HAIR     = True
    PREPROCESS_CLAHE    = True
    PREPROCESS_WORK_SIZE = 320

    # ------------------------------------------------------------------
    # FEDERATED TRAINING (server-side)
    # ------------------------------------------------------------------
    FED_ROUNDS      = 3
    LOCAL_EPOCHS    = 1
    META_ROUNDS     = 2
    DP_EPSILON      = 1.0
    DP_CLIP_NORM    = 1.0
    DP_SIGMA        = 0.01
    SMPC_PARTIES    = 3
    PBFT_VALIDATORS = 4
    PAILLIER_BITS   = 1024

    # ------------------------------------------------------------------
    # EPISODIC FEW-SHOT BENCHMARKS (Diagram Block 3)
    # ------------------------------------------------------------------
    EPISODIC_BENCHMARKS = [
        ("2W1S", 2, 1),
        ("2W5S", 2, 5),
        ("2W10S", 2, 10),
        ("5W1S", 5, 1),
        ("5W5S", 5, 5),
    ]
    EPISODIC_EPISODES = 50

    # ------------------------------------------------------------------
    # MISC
    # ------------------------------------------------------------------
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    SEED   = 42

    @classmethod
    def make_dirs(cls):
        for d in [cls.OUTPUT_DIR, cls.CHECKPOINT_DIR, os.path.dirname(cls.MANIFEST_CSV)]:
            if d:
                os.makedirs(d, exist_ok=True)

    @classmethod
    def load_classes_and_hospitals(cls):
        """
        Must be called once (after build_dataset_manifest.py) before building
        models / dataloaders. Populates CLASS_NAMES, NUM_CLASSES, etc.
        """
        import json
        if not os.path.exists(cls.CLASS_NAMES_JSON):
            raise FileNotFoundError(
                f"{cls.CLASS_NAMES_JSON} not found.\n"
                f"Run:  python build_dataset_manifest.py\n"
                f"(or federated_pipeline.py will do it automatically)"
            )
        with open(cls.CLASS_NAMES_JSON) as f:
            info = json.load(f)
        cls.CLASS_NAMES    = info["class_names"]
        cls.NUM_CLASSES    = len(cls.CLASS_NAMES)
        cls.HOSPITAL_NAMES = info["hospital_names"]
        cls.NUM_HOSPITALS  = len(cls.HOSPITAL_NAMES)
        print(f"[Config] {cls.NUM_CLASSES} classes, {cls.NUM_HOSPITALS} hospitals: "
              f"{cls.HOSPITAL_NAMES}")
        return cls.CLASS_NAMES, cls.HOSPITAL_NAMES

    @classmethod
    def summary(cls):
        """Print a summary of the active configuration."""
        print(f"\n{'='*60}")
        print(f"  Fed-MetaDerm Configuration")
        print(f"{'='*60}")
        print(f"  Environment  : {'Kaggle' if cls.IS_KAGGLE else 'Local'}")
        print(f"  Device       : {cls.DEVICE}")
        print(f"  Backbone     : {cls.BACKBONE}")
        print(f"  Batch size   : {cls.BATCH_SIZE}")
        print(f"  Stages       : {cls.STAGE1_EPOCHS}+{cls.STAGE2_EPOCHS}+{cls.STAGE3_EPOCHS} epochs")
        print(f"  Adversarial  : {cls.USE_ADVERSARIAL} ({cls.ADV_METHOD})")
        print(f"  SSL          : {cls.USE_SELF_SUPERVISED}")
        print(f"  Fed rounds   : {cls.FED_ROUNDS}")
        print(f"  Output dir   : {cls.OUTPUT_DIR}")
        print(f"{'='*60}\n")
