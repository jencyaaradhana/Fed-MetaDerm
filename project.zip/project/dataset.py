"""
dataset.py
----------
Loads REAL local data from fed_metaderm_data/ without any synthetic splits.

Supports two layouts automatically:
  Layout A (HAM10000 / ISIC2018 style):
      fed_metaderm_data/<DatasetName>/hospital_partitions/hospital_N.csv
      fed_metaderm_data/<DatasetName>/processed_images/<image_id>.jpg
      CSV columns: image_id, dx

  Layout B (manifest style, built by build_dataset_manifest.py):
      manifest/manifest.csv
      columns: image_path (absolute), label, hospital_id, dataset_name

Augmentation: MixUp, CutMix, ResizeMix (applied per-batch on GPU).
"""

import os
import numpy as np
import pandas as pd
import torch
from pathlib import Path
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import torchvision.transforms as T

from config import Config
from preprocessing import DermPreprocess


# -----------------------------------------------------------------------
# Canonical label normalization (same table as build_dataset_manifest.py)
# -----------------------------------------------------------------------
_SYNONYMS = {
    "akiec": "actinic keratosis", "ak": "actinic keratosis",
    "actinic keratosis": "actinic keratosis",
    "bcc": "basal cell carcinoma", "basal cell carcinoma": "basal cell carcinoma",
    "bkl": "benign keratosis", "benign keratosis": "benign keratosis",
    "seborrheic keratosis": "benign keratosis",
    "df": "dermatofibroma", "dermatofibroma": "dermatofibroma",
    "mel": "melanoma", "melanoma": "melanoma",
    "nv": "melanocytic nevus", "nevus": "melanocytic nevus",
    "melanocytic nevus": "melanocytic nevus",
    "vasc": "vascular lesion", "vascular lesion": "vascular lesion",
    "scc": "squamous cell carcinoma",
    "squamous cell carcinoma": "squamous cell carcinoma",
    "unk": "unknown",
}


def normalize_label(raw: str) -> str:
    c = str(raw).strip().lower().replace("_", " ").replace("-", " ")
    c = " ".join(c.split())
    return _SYNONYMS.get(c, c)


# -----------------------------------------------------------------------
# Load one hospital's dataframe
# Tries manifest first, then falls back to hospital_partitions/ layout.
# -----------------------------------------------------------------------
def load_hospital_dataframe(hospital_id: int,
                              val_frac: float = None,
                              seed: int = None):
    """
    Returns (train_df, val_df) each with columns:
        image_path  – absolute path to the image file
        label       – normalised string label
    """
    val_frac = Config.VAL_FRACTION if val_frac is None else val_frac
    seed     = Config.SPLIT_SEED   if seed     is None else seed

    # ---- Option 1: use pre-built manifest.csv ---------------------------
    if os.path.exists(Config.MANIFEST_CSV):
        full_df  = pd.read_csv(Config.MANIFEST_CSV)
        hosp_df  = full_df[full_df["hospital_id"] == hospital_id].reset_index(drop=True)
        if len(hosp_df) == 0:
            raise ValueError(
                f"No images for hospital_id={hospital_id} in manifest.")

        # Ensure columns are named correctly
        if "image_path" not in hosp_df.columns:
            raise ValueError("manifest.csv must have 'image_path' column.")
        if "label" not in hosp_df.columns and "dx" in hosp_df.columns:
            hosp_df["label"] = hosp_df["dx"].apply(normalize_label)

        rng     = np.random.default_rng(seed + hospital_id)
        n_val   = max(1, int(len(hosp_df) * val_frac))
        perm    = rng.permutation(len(hosp_df))
        train_df = hosp_df.iloc[perm[n_val:]].reset_index(drop=True)
        val_df   = hosp_df.iloc[perm[:n_val]].reset_index(drop=True)
        return train_df, val_df

    # ---- Option 2: hospital_partitions/ layout (fallback) ---------------
    data_root = Config.LOCAL_DATA_ROOT
    hosp_names = Config.HOSPITAL_NAMES
    if hospital_id >= len(hosp_names):
        raise ValueError(f"hospital_id={hospital_id} out of range.")

    dataset_name = hosp_names[hospital_id]
    parts_dir    = Path(data_root) / dataset_name / "hospital_partitions"
    images_dir   = Path(data_root) / dataset_name / "processed_images"

    if not parts_dir.exists():
        raise FileNotFoundError(
            f"No hospital_partitions/ found at {parts_dir}. "
            f"Run federated_pipeline.py or build_dataset_manifest.py first.")

    csv_files = sorted(parts_dir.glob("hospital_*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No hospital_*.csv files in {parts_dir}.")

    # Build image index once
    VALID_EXT = (".jpg", ".jpeg", ".png", ".bmp")
    img_index = {}
    if images_dir.exists():
        for p in images_dir.rglob("*"):
            if p.suffix.lower() in VALID_EXT:
                img_index[p.name] = str(p)
                img_index[p.stem] = str(p)

    records = []
    for csv_path in csv_files:
        df = pd.read_csv(csv_path)
        id_col  = "image_id" if "image_id" in df.columns else df.columns[0]
        lbl_col = "dx"       if "dx"       in df.columns else df.columns[1]
        for _, row in df.iterrows():
            img_id = str(row[id_col])
            path   = img_index.get(img_id) or img_index.get(os.path.splitext(img_id)[0])
            if path is None:
                continue
            records.append({
                "image_path": path,
                "label":      normalize_label(row[lbl_col]),
            })

    if not records:
        raise RuntimeError(
            f"0 images matched for hospital {hospital_id} ({dataset_name}).\n"
            f"Ensure processed_images/ folder contains the actual image files.\n"
            f"Download HAM10000 from Kaggle and place .jpg files there.")

    hosp_df  = pd.DataFrame(records)
    rng      = np.random.default_rng(seed + hospital_id)
    n_val    = max(1, int(len(hosp_df) * val_frac))
    perm     = rng.permutation(len(hosp_df))
    train_df = hosp_df.iloc[perm[n_val:]].reset_index(drop=True)
    val_df   = hosp_df.iloc[perm[:n_val]].reset_index(drop=True)
    return train_df, val_df


# -----------------------------------------------------------------------
# Dataset class
# -----------------------------------------------------------------------
class DermDataset(Dataset):
    def __init__(self, df: pd.DataFrame, class_names: list,
                 img_size: int, train: bool,
                 use_preprocessing: bool = False,
                 cache_dir: str = None):
        self.df           = df.reset_index(drop=True)
        self.class_to_idx = {c: i for i, c in enumerate(class_names)}
        self.train        = train
        self.img_size     = img_size
        self.preprocessor = (
            DermPreprocess(hair=getattr(Config, "PREPROCESS_HAIR", True),
                           clahe=getattr(Config, "PREPROCESS_CLAHE", True),
                           work_size=getattr(Config, "PREPROCESS_WORK_SIZE", 320),
                           cache_dir=cache_dir)
            if use_preprocessing else None
        )

        mean = [0.485, 0.456, 0.406]
        std  = [0.229, 0.224, 0.225]

        if train:
            self.transform = T.Compose([
                T.Resize((img_size + 32, img_size + 32)),
                T.RandomCrop(img_size),
                T.RandomHorizontalFlip(),
                T.RandomVerticalFlip(),
                T.RandomRotation(20),
                T.ColorJitter(brightness=0.3, contrast=0.3,
                               saturation=0.3, hue=0.05),
                T.RandomGrayscale(p=0.05),
                T.ToTensor(),
                T.Normalize(mean, std),
            ])
        else:
            self.transform = T.Compose([
                T.Resize((img_size, img_size)),
                T.ToTensor(),
                T.Normalize(mean, std),
            ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row   = self.df.iloc[idx]
        path  = row["image_path"]
        if not os.path.exists(path):
            sep_idx = path.lower().find("fed_metaderm_data")
            if sep_idx != -1:
                rel = path[sep_idx + len("fed_metaderm_data"):].lstrip("/\\")
                cand = os.path.join(Config.LOCAL_DATA_ROOT, rel)
                if os.path.exists(cand):
                    path = cand
                else:
                    cand2 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fed_metaderm_data", rel)
                    if os.path.exists(cand2):
                        path = cand2
        try:
            image = Image.open(path).convert("RGB")
            if self.preprocessor is not None:
                image = self.preprocessor(image, key=path)
        except Exception as e:
            # Return a black image if the file is corrupted / missing
            image = Image.new("RGB", (self.img_size, self.img_size), color=0)
        image = self.transform(image)

        raw_label = row["label"]
        label_idx = self.class_to_idx.get(raw_label, 0)
        return image, label_idx


# -----------------------------------------------------------------------
# DataLoader factory
# -----------------------------------------------------------------------
def make_dataloaders(hospital_id=None, use_preprocessing=None):
    if Config.NUM_CLASSES == 0:
        Config.load_classes_and_hospitals()

    hospital_id = Config.HOSPITAL_ID if hospital_id is None else hospital_id
    use_prep = getattr(Config, "USE_PREPROCESSING", False) if use_preprocessing is None else use_preprocessing
    cache_dir = os.path.join(Config.OUTPUT_DIR, "preprocessed_cache")

    train_df, val_df = load_hospital_dataframe(hospital_id)

    train_ds = DermDataset(train_df, Config.CLASS_NAMES,
                            Config.IMG_SIZE, train=True,
                            use_preprocessing=use_prep, cache_dir=cache_dir)
    val_ds   = DermDataset(val_df,   Config.CLASS_NAMES,
                            Config.IMG_SIZE, train=False,
                            use_preprocessing=use_prep, cache_dir=cache_dir)

    train_loader = DataLoader(
        train_ds, batch_size=Config.BATCH_SIZE, shuffle=True,
        num_workers=Config.NUM_WORKERS, pin_memory=True, drop_last=True)
    val_loader = DataLoader(
        val_ds, batch_size=Config.BATCH_SIZE, shuffle=False,
        num_workers=Config.NUM_WORKERS, pin_memory=True)

    # Per-class counts using the label column
    label_col = "label" if "label" in train_df.columns else "dx"
    class_counts = (train_df[label_col]
                    .value_counts()
                    .reindex(Config.CLASS_NAMES, fill_value=0))
    return train_loader, val_loader, class_counts


# -----------------------------------------------------------------------
# MixUp / CutMix / ResizeMix (batch-level, on GPU)
# -----------------------------------------------------------------------
def _rand_bbox(size, lam):
    W, H   = size[3], size[2]
    cut_w  = int(W * np.sqrt(1.0 - lam))
    cut_h  = int(H * np.sqrt(1.0 - lam))
    cx, cy = np.random.randint(W), np.random.randint(H)
    x1 = np.clip(cx - cut_w // 2, 0, W)
    y1 = np.clip(cy - cut_h // 2, 0, H)
    x2 = np.clip(cx + cut_w // 2, 0, W)
    y2 = np.clip(cy + cut_h // 2, 0, H)
    return x1, y1, x2, y2


def mixup(images, labels, alpha):
    lam  = np.random.beta(alpha, alpha) if alpha > 0 else 1.0
    perm = torch.randperm(images.size(0), device=images.device)
    mixed = lam * images + (1 - lam) * images[perm]
    return mixed, labels, labels[perm], lam


def cutmix(images, labels, alpha):
    lam  = np.random.beta(alpha, alpha) if alpha > 0 else 1.0
    perm = torch.randperm(images.size(0), device=images.device)
    x1, y1, x2, y2 = _rand_bbox(images.size(), lam)
    mixed = images.clone()
    mixed[:, :, y1:y2, x1:x2] = images[perm][:, :, y1:y2, x1:x2]
    lam_adj = 1 - ((x2 - x1) * (y2 - y1) /
                    (images.size(-1) * images.size(-2)))
    return mixed, labels, labels[perm], lam_adj


def resizemix(images, labels, scale_range):
    perm = torch.randperm(images.size(0), device=images.device)
    B, C, H, W = images.shape
    tau = np.random.uniform(*scale_range)
    rw, rh = max(1, int(W * np.sqrt(tau))), max(1, int(H * np.sqrt(tau)))
    src = torch.nn.functional.interpolate(
        images[perm], size=(rh, rw), mode="bilinear", align_corners=False)
    x1 = np.random.randint(0, max(1, W - rw))
    y1 = np.random.randint(0, max(1, H - rh))
    mixed = images.clone()
    mixed[:, :, y1:y1 + rh, x1:x1 + rw] = src
    lam = 1 - (rw * rh) / (W * H)
    return mixed, labels, labels[perm], lam


def apply_random_mix(images, labels, cfg=Config):
    choices = []
    if cfg.USE_MIXUP:     choices.append("mixup")
    if cfg.USE_CUTMIX:    choices.append("cutmix")
    if cfg.USE_RESIZEMIX: choices.append("resizemix")

    if not choices or np.random.rand() > cfg.AUG_PROB:
        return images, labels, labels, 1.0

    choice = np.random.choice(choices)
    if choice == "mixup":
        return mixup(images, labels, cfg.MIXUP_ALPHA)
    elif choice == "cutmix":
        return cutmix(images, labels, cfg.CUTMIX_ALPHA)
    else:
        return resizemix(images, labels, cfg.RESIZEMIX_SCALE)
