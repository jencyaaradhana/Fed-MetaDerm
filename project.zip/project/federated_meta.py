"""
federated_meta.py -- Module 2: federated prototypical meta-learning (Eqs. 4-5).

Every client samples N_w-way, K-shot episodes from its local data, builds prototypes
c_k = mean support embedding (Eq. 4), classifies queries with a softmax over negative squared
Euclidean distance (Eq. 5) and minimises the negative log-probability of the true class.
The server then aggregates the client weights with the supplied weights (RUPA / size).
Embeddings are L2-normalised so the squared distance lies in [0,4] (implementation detail).
"""
import copy
import random

import numpy as np
import torch
import torch.nn.functional as F

from secure_aggregation import float_keys


class EpisodeSampler:
    def __init__(self, dataset, n_way=5, k_shot=5, q_query=5, seed=0):
        """dataset needs `.df['label']`, `.class_to_idx` and __getitem__ -> (img, idx)."""
        self.ds, self.n_way, self.k, self.q = dataset, n_way, k_shot, q_query
        self.rng = random.Random(seed)
        labels = dataset.df["label"].map(dataset.class_to_idx).to_numpy()
        self.by_class = {}
        for i, c in enumerate(labels):
            self.by_class.setdefault(int(c), []).append(i)
        # a class needs at least k+1 samples to form support + >=1 query
        self.usable = [c for c, idx in self.by_class.items() if len(idx) >= self.k + 1]
        if len(self.usable) < 2:
            raise ValueError("need >= 2 classes with >= k_shot+1 samples for episodes")

    def sample(self):
        n = min(self.n_way, len(self.usable))
        classes = self.rng.sample(self.usable, n)
        sx, sy, qx, qy = [], [], [], []
        for lab, c in enumerate(classes):
            idx = self.rng.sample(self.by_class[c], min(len(self.by_class[c]), self.k + self.q))
            for j in idx[:self.k]:
                sx.append(self.ds[j][0]); sy.append(lab)
            for j in idx[self.k:]:
                qx.append(self.ds[j][0]); qy.append(lab)
        return (torch.stack(sx), torch.tensor(sy), torch.stack(qx), torch.tensor(qy), classes)


def episode_loss(model, sx, sy, qx, qy, n_way):
    zs = F.normalize(model.extract_features(sx), dim=-1)
    zq = F.normalize(model.extract_features(qx), dim=-1)
    protos = torch.stack([zs[sy == k].mean(0) for k in range(n_way)])          # Eq. (4)
    d2 = torch.cdist(zq, protos) ** 2
    logits = -d2                                                              # Eq. (5)
    loss = F.cross_entropy(logits, qy)
    acc = (logits.argmax(1) == qy).float().mean().item()
    return loss, acc


def client_meta_update(model, sampler, device, episodes=20, lr=1e-4):
    model.train()
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=lr)
    losses, accs = [], []
    for _ in range(episodes):
        sx, sy, qx, qy, classes = sampler.sample()
        n_way = len(classes)
        sx, sy, qx, qy = sx.to(device), sy.to(device), qx.to(device), qy.to(device)
        opt.zero_grad()
        loss, acc = episode_loss(model, sx, sy, qx, qy, n_way)
        loss.backward()
        opt.step()
        losses.append(loss.item()); accs.append(acc)
    return float(np.mean(losses)), float(np.mean(accs))


def federated_meta_learning(global_model, datasets, weights, device, rounds=2, episodes=20,
                            n_way=5, k_shot=5, q_query=5, lr=1e-4, seed=0, verbose=True):
    """datasets: list of per-hospital train datasets; weights: aggregation weights (sum to 1)."""
    samplers = [EpisodeSampler(d, n_way, k_shot, q_query, seed + i) for i, d in enumerate(datasets)]
    global_model = global_model.to(device)
    history = []
    for r in range(1, rounds + 1):
        states, stats = [], []
        for i, sm in enumerate(samplers):
            local = copy.deepcopy(global_model)
            stats.append(client_meta_update(local, sm, device, episodes, lr))
            states.append({k: v.detach().cpu() for k, v in local.state_dict().items()})
        g = {k: v.detach().cpu().clone() for k, v in global_model.state_dict().items()}
        for k in float_keys(g):
            g[k] = sum(w * s[k] for w, s in zip(weights, states))
        global_model.load_state_dict(g)
        history.append({"round": r, "episode_loss": [s[0] for s in stats],
                        "episode_acc": [s[1] for s in stats]})
        if verbose:
            print(f"[Meta] round {r}: loss/acc per client = "
                  f"{[(round(a,3), round(b,3)) for a,b in stats]}")
    return global_model, history
