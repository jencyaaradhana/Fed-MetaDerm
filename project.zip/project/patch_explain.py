with open(r'E:\final pro\project\project (6)\project (6)\project\explainability.py', 'r', encoding='utf-8') as f:
    code = f.read()

target_block = """def _auto_find_conv_layer(model):
    \"\"\"Return the last Conv2d inside model.\"\"\"
    last_conv = None
    target_obj = getattr(model, \"backbone\", None)
    if target_obj is not None:
        for m in target_obj.modules():
            if isinstance(m, torch.nn.Conv2d):
                last_conv = m
    if last_conv is None:
        for m in model.modules():
            if isinstance(m, torch.nn.Conv2d):
                last_conv = m
    if last_conv is None:
        raise RuntimeError(\"No Conv2d found in model for ScoreCAM.\")
    return last_conv"""

replacement_block = """def _auto_find_conv_layer(model):
    \"\"\"Return the last Conv2d inside model that actually executes during forward.\"\"\"
    ran = []
    handles = []
    for m in model.modules():
        if isinstance(m, torch.nn.Conv2d):
            h = m.register_forward_hook(lambda mod, i, o, c=m: ran.append(c))
            handles.append(h)
    with torch.no_grad():
        try:
            device = next(model.parameters()).device
            dummy = torch.zeros(1, 3, 224, 224, device=device)
            model(dummy)
        except Exception:
            pass
        finally:
            for h in handles:
                h.remove()
    if ran:
        for c in reversed(ran):
            if c.out_channels > 1:
                return c
        return ran[-1]
    for m in model.modules():
        if isinstance(m, torch.nn.Conv2d):
            return m
    return None"""

code = code.replace(target_block.replace('\r\n', '\n'), replacement_block)
code = code.replace(target_block, replacement_block)

old_act = "acts = self._activations[0]        # (C, h, w)"
new_act = """if self._activations is not None:
            acts = self._activations[0]
        elif hasattr(self.model, 'feature_map'):
            acts = self.model.feature_map(img)[0].detach().cpu()
        else:
            acts = torch.ones((1, 7, 7))"""

code = code.replace(old_act, new_act)

with open(r'E:\final pro\project\project (6)\project (6)\project\explainability.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("Patch applied successfully!")
