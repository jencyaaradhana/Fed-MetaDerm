"""
build_dataset_manifest.py
--------------------------
Scans REAL dataset folders and produces a unified manifest:

    manifest.csv       columns: image_path, label, hospital_id, dataset_name
    class_names.json   sorted list of every unique class across all datasets

Each dataset = one hospital -> REAL non-IID long-tailed federated data.

AUTO-DETECTS environment:
  LOCAL  : scans fed_metaderm_data/ sub-folders automatically
  KAGGLE : uses /kaggle/input/ paths
"""

import os
import json
import glob
import pandas as pd
from pathlib import Path

_IS_KAGGLE = os.path.exists("/kaggle/working")

if _IS_KAGGLE:
    DATASET_ROOTS = {
        "ham10000": "/kaggle/input/skin-cancer-mnist-ham10000",
        "isic":     "/kaggle/input/isic-2019",
        "derm7pt":  "/kaggle/input/derm7pt",
        "dermnet":  "/kaggle/input/dermnet",
        "sd198":    "/kaggle/input/sd-198",
    }
    MANIFEST_OUT    = "/kaggle/working/fedmetaderm_manifest/manifest.csv"
    CLASS_NAMES_OUT = "/kaggle/working/fedmetaderm_manifest/class_names.json"
else:
    _HERE = Path(__file__).parent
    _DATA = _HERE / "fed_metaderm_data"
    DATASET_ROOTS = {}
    if _DATA.exists():
        for d in sorted(_DATA.iterdir()):
            if d.is_dir() and not d.name.startswith("_"):
                name_lower = d.name.lower()
                if "ham" in name_lower:
                    DATASET_ROOTS["ham10000"] = str(d)
                elif "isic" in name_lower:
                    DATASET_ROOTS["isic"] = str(d)
                elif "7pt" in name_lower or "derm7" in name_lower:
                    DATASET_ROOTS["derm7pt"] = str(d)
                elif "derm" in name_lower:
                    DATASET_ROOTS["dermnet"] = str(d)
                elif "sd" in name_lower or "198" in name_lower:
                    DATASET_ROOTS["sd198"] = str(d)
                else:
                    DATASET_ROOTS[name_lower] = str(d)
    MANIFEST_OUT    = str(_HERE / "manifest" / "manifest.csv")
    CLASS_NAMES_OUT = str(_HERE / "manifest" / "class_names.json")

print(f"[manifest] Environment : {'Kaggle' if _IS_KAGGLE else 'Local'}")
for k, v in DATASET_ROOTS.items():
    exists = os.path.isdir(v)
    status = "OK" if exists else "NOT FOUND"
    print(f"  {k:12s}: {v}  [{status}]")

VALID_EXT = (".jpg", ".jpeg", ".png", ".bmp")

CANONICAL_SYNONYMS = {
    "akiec": "actinic keratosis",
    "ak": "actinic keratosis",
    "actinic keratosis": "actinic keratosis",
    "bcc": "basal cell carcinoma",
    "basal cell carcinoma": "basal cell carcinoma",
    "bkl": "benign keratosis",
    "benign keratosis": "benign keratosis",
    "seborrheic keratosis": "benign keratosis",
    "df": "dermatofibroma",
    "dermatofibroma": "dermatofibroma",
    "mel": "melanoma",
    "melanoma": "melanoma",
    "nv": "melanocytic nevus",
    "nevus": "melanocytic nevus",
    "melanocytic nevus": "melanocytic nevus",
    "vasc": "vascular lesion",
    "vascular lesion": "vascular lesion",
    "scc": "squamous cell carcinoma",
    "squamous cell carcinoma": "squamous cell carcinoma",
    "unk": "unknown",
}


def normalize_label(raw: str) -> str:
    clean = str(raw).strip().lower().replace("_", " ").replace("-", " ")
    clean = " ".join(clean.split())
    return CANONICAL_SYNONYMS.get(clean, clean)


def build_image_index(root):
    index = {}
    root_path = Path(root)
    for ext in VALID_EXT:
        for path in glob.glob(os.path.join(root, "**", f"*{ext}"), recursive=True):
            p = Path(path)
            fname = p.name.lower()
            stem = p.stem.lower()
            rel = str(p.relative_to(root_path)).replace("\\", "/").lower()
            
            index[rel] = str(p)
            index[fname] = str(p)
            index[stem] = str(p)
    return index


def load_csv_dataset(root, dataset_name):
    csv_candidates = glob.glob(os.path.join(root, "**", "*clean_labels*.csv"), recursive=True)
    if not csv_candidates:
        csv_candidates = glob.glob(os.path.join(root, "**", "*metadata*.csv"), recursive=True)
    if not csv_candidates:
        csv_candidates = glob.glob(os.path.join(root, "**", "*.csv"), recursive=True)
    if not csv_candidates:
        print(f"[{dataset_name}] No CSV found under {root} -- skipping.")
        return []

    df = pd.read_csv(csv_candidates[0])
    
    id_col = None
    for cand in ["image_id", "image", "image_name", "isic_id", df.columns[0]]:
        if cand in df.columns:
            id_col = cand
            break

    label_col = None
    for cand in ["dx", "diagnosis", "label", "class"]:
        if cand in df.columns:
            label_col = cand
            break

    one_hot_cols = [c for c in df.columns if c.upper() in
                    ["MEL", "NV", "BCC", "AK", "BKL", "DF", "VASC", "SCC", "UNK"]]

    image_index = build_image_index(root)
    records = []
    missing = 0

    for _, row in df.iterrows():
        raw_id = str(row[id_col]).replace("\\", "/").strip().lower()
        fname = os.path.basename(raw_id)
        stem = os.path.splitext(fname)[0]

        path = image_index.get(raw_id) or image_index.get(fname) or image_index.get(stem)
        if path is None:
            missing += 1
            continue

        if label_col is not None and pd.notna(row[label_col]):
            label = row[label_col]
        elif one_hot_cols:
            label = one_hot_cols[int(row[one_hot_cols].values.argmax())]
        else:
            missing += 1
            continue

        records.append({
            "image_path": path,
            "label": normalize_label(label),
            "dataset_name": dataset_name,
        })

    if not records:
        print(f"[{dataset_name}] CSV yielded 0 matches, trying ImageFolder loader fallback...")
        return load_imagefolder_style(root, dataset_name)

    print(f"[{dataset_name}] {len(records)} images matched, {missing} rows missing.")
    return records


def load_ham10000(root):
    return load_csv_dataset(root, "ham10000")

def load_isic(root):
    return load_csv_dataset(root, "isic")

def load_derm7pt(root):
    return load_csv_dataset(root, "derm7pt")

def load_sd198(root):
    return load_csv_dataset(root, "sd198")


def load_imagefolder_style(root, dataset_name):
    records = []
    class_dirs = []
    for dirpath, dirnames, filenames in os.walk(root):
        if any(f.lower().endswith(VALID_EXT) for f in filenames):
            class_dirs.append(dirpath)

    if not class_dirs:
        print(f"[{dataset_name}] No class folders with images found under {root} -- skipping.")
        return []

    for class_dir in class_dirs:
        class_name = os.path.basename(class_dir)
        if class_name.lower() in ("train", "test", "val", "images", "image", "processed_images"):
            continue
        label = normalize_label(class_name)
        for fname in os.listdir(class_dir):
            if fname.lower().endswith(VALID_EXT):
                records.append({
                    "image_path": os.path.join(class_dir, fname),
                    "label": label,
                    "dataset_name": dataset_name,
                })

    print(f"[{dataset_name}] {len(records)} images found across "
          f"{len(set(r['label'] for r in records))} classes.")
    return records


def build_manifest():
    all_records = []
    hospital_names = []

    loaders = {
        "ham10000": lambda: load_ham10000(DATASET_ROOTS["ham10000"]),
        "isic": lambda: load_isic(DATASET_ROOTS["isic"]),
        "derm7pt": lambda: load_derm7pt(DATASET_ROOTS["derm7pt"]),
        "dermnet": lambda: load_imagefolder_style(DATASET_ROOTS.get("dermnet", ""), "dermnet") if "dermnet" in DATASET_ROOTS else [],
        "sd198": lambda: load_sd198(DATASET_ROOTS["sd198"]),
    }

    hospital_id = 0
    for name, loader_fn in loaders.items():
        if name not in DATASET_ROOTS or not os.path.isdir(DATASET_ROOTS[name]):
            print(f"[{name}] Path not found or not set -- skipping this hospital.")
            continue
        recs = loader_fn()
        if not recs:
            continue
        for r in recs:
            r["hospital_id"] = hospital_id
        all_records.extend(recs)
        hospital_names.append(name)
        hospital_id += 1

    if not all_records:
        raise RuntimeError(
            "No images were loaded from ANY dataset. Check DATASET_ROOTS paths "
            "and paste your folder structure so the loaders can be corrected."
        )

    manifest_df = pd.DataFrame(all_records)
    class_names = sorted(manifest_df["label"].unique().tolist())

    os.makedirs(os.path.dirname(MANIFEST_OUT), exist_ok=True)
    manifest_df.to_csv(MANIFEST_OUT, index=False)
    with open(CLASS_NAMES_OUT, "w") as f:
        json.dump({"class_names": class_names, "hospital_names": hospital_names}, f, indent=2)

    print(f"\n===== MANIFEST BUILT =====")
    print(f"Total images: {len(manifest_df)}")
    print(f"Total unified classes: {len(class_names)}")
    print(f"Hospitals: {hospital_names}")
    print(f"Saved manifest to:    {MANIFEST_OUT}")
    print(f"Saved class names to: {CLASS_NAMES_OUT}")
    return manifest_df, class_names, hospital_names


if __name__ == "__main__":
    build_manifest()
