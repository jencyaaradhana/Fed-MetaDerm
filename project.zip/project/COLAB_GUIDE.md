# 🚀 How to Run Fed-MetaDerm Training on Google Colab (GPU)

This guide is for running full, high-accuracy training on Google Colab using a **free T4 GPU**.

---

## ⚡ Fast Step-by-Step Instructions

### Step 1: Zip the Project
On your local machine, zip this entire `project` directory into a file called `project.zip`.
Make sure it includes:
* Python code (`federated_pipeline.py`, `app.py`, `model.py`, etc.)
* `fed_metaderm_data/` folder
* `FedMetaDerm_Colab_Training.ipynb`

### Step 2: Open Google Colab
1. Go to [Google Colab](https://colab.research.google.com/).
2. Click **Upload** and upload `FedMetaDerm_Colab_Training.ipynb` (located directly inside this folder).

### Step 3: Enable Free GPU
1. In Colab top menu: click **Runtime** ➔ **Change runtime type**.
2. Under **Hardware accelerator**, select **T4 GPU**.
3. Click **Save**.

### Step 4: Upload `project.zip`
* On the left sidebar in Colab, click the **Folder icon (Files)**.
* Click the **Upload** icon and upload your `project.zip` to `/content/`.
  *(Or mount your Google Drive if `project.zip` is in Drive)*.

### Step 5: Run the Notebook Cells
Simply run the cells from top to bottom:
1. `!nvidia-smi` (verifies GPU is active)
2. Unzips `project.zip` into `/content/project`
3. Installs dependencies: `!pip install -r requirements.txt`
4. Runs full 3-round training:
   ```bash
   python federated_pipeline.py --rounds 3 --batch_size 32 --device cuda
   ```
   * *Runtime on T4 GPU:* **~25 to 35 minutes** (compared to 12+ hours on CPU).
5. Automatically creates and downloads `fedmetaderm_full_trained_results.zip` containing:
   * `outputs/global_model_final.pt` (the high-accuracy trained model)
   * `outputs/final_summary.json`
   * `outputs/final_evaluation/` (confusion matrices, ROC curves, F1 plots)
   * `checkpoints/` (all 4 hospital personalized models)

---

## 💻 Running the GUI with the New Model

Once your friend finishes the Colab training and downloads `fedmetaderm_full_trained_results.zip`:
1. Extract `outputs/` and `checkpoints/` back into your local project directory.
2. Launch the Streamlit GUI:
   ```powershell
   streamlit run app.py
   ```
3. Open `http://localhost:8501` to use the fully-trained, high-accuracy model!
