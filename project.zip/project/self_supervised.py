"""
self_supervised.py
------------------
Implements SimCLR-style Self-Supervised Learning for the
"Self-Supervised Learning" block (Hospital 3/N in the diagram).

Used when a hospital has unlabelled or very limited labelled data.
The backbone is pre-trained via contrastive learning before the
supervised fine-tuning stages (DTL/DTLS) begin.

Architecture:
  Backbone → Projection Head (2-layer MLP) → NT-Xent contrastive loss

Two random augmentation views of the same image are treated as a
positive pair; all other images in the batch are negatives.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.utils.data import DataLoader
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR
import torchvision.transforms as T

from config import Config


# -----------------------------------------------------------------------
# Two-view augmentation pipeline (required for contrastive learning)
# -----------------------------------------------------------------------
class TwoViewTransform:
    """Applies two independent random augmentations to the same image,
    returning a (view1, view2) pair — the positive pair for NT-Xent."""

    def __init__(self, img_size=Config.IMG_SIZE):
        color_jitter = T.ColorJitter(brightness=0.4, contrast=0.4,
                                     saturation=0.4, hue=0.1)
        self.transform = T.Compose([
            T.RandomResizedCrop(img_size, scale=(0.2, 1.0)),
            T.RandomHorizontalFlip(),
            T.RandomApply([color_jitter], p=0.8),
            T.RandomGrayscale(p=0.2),
            T.GaussianBlur(kernel_size=int(0.1 * img_size) | 1),
            T.ToTensor(),
            T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

    def __call__(self, x):
        return self.transform(x), self.transform(x)


class TwoViewDataset(torch.utils.data.Dataset):
    """Wraps an existing dataset so that __getitem__ returns (view1, view2)
    instead of (image, label). Labels are ignored during SSL pre-training."""

    def __init__(self, base_dataset, img_size=Config.IMG_SIZE):
        self.base = base_dataset
        self.two_view = TwoViewTransform(img_size)

    def __len__(self):
        return len(self.base)

    def __getitem__(self, idx):
        # base dataset may return (image_tensor, label) or just image_tensor
        item = self.base[idx]
        img = item[0] if isinstance(item, (tuple, list)) else item
        # convert back to PIL for two-view augmentation
        from PIL import Image
        img_np = (img.permute(1, 2, 0).numpy() *
                  np.array([0.229, 0.224, 0.225]) +
                  np.array([0.485, 0.456, 0.406]))
        img_np = np.clip(img_np * 255, 0, 255).astype(np.uint8)
        pil_img = Image.fromarray(img_np)
        v1, v2 = self.two_view(pil_img)
        return v1, v2


# -----------------------------------------------------------------------
# SimCLR Projection Head
# -----------------------------------------------------------------------
class SimCLRProjectionHead(nn.Module):
    """2-layer MLP projection head (g in the SimCLR paper).
    Maps backbone embeddings to the space where NT-Xent is computed.
    Discarded after pre-training; only the backbone is kept."""

    def __init__(self, embed_dim=Config.EMBED_DIM,
                 proj_dim=Config.SSL_PROJECTION_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.BatchNorm1d(embed_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dim, proj_dim),
        )

    def forward(self, x):
        return self.net(x)


# -----------------------------------------------------------------------
# NT-Xent Loss  (Normalized Temperature-scaled Cross Entropy)
# -----------------------------------------------------------------------
class NTXentLoss(nn.Module):
    """Contrastive loss from SimCLR (Chen et al., 2020).

    For a batch of N images → 2N views total.
    Positive pairs: (view_i, view_j) from the same image.
    Negative pairs: all other 2(N-1) views in the batch.
    """

    def __init__(self, temperature: float = Config.SSL_TEMPERATURE):
        super().__init__()
        self.temperature = temperature

    def forward(self, z1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
        """
        z1, z2: (N, proj_dim) normalized projection vectors.
        Returns a scalar loss.
        """
        N = z1.size(0)
        z = torch.cat([z1, z2], dim=0)                     # (2N, D)
        z = F.normalize(z, dim=1)
        sim = (z @ z.T) / self.temperature                  # (2N, 2N)

        # mask out self-similarity (diagonal)
        mask = torch.eye(2 * N, dtype=torch.bool, device=z.device)
        sim.masked_fill_(mask, float("-inf"))

        # positive pairs: (i, i+N) and (i+N, i)
        labels = torch.cat([
            torch.arange(N, 2 * N, device=z.device),
            torch.arange(0, N,     device=z.device),
        ])                                                   # (2N,)

        loss = F.cross_entropy(sim, labels)
        return loss


# -----------------------------------------------------------------------
# SSL pre-training wrapper
# -----------------------------------------------------------------------
class SimCLRTrainer:
    """Wraps the backbone + projection head for self-supervised pre-training.

    Usage:
        trainer = SimCLRTrainer(model, device)
        trainer.pretrain(ssl_loader, epochs=5)
        # then proceed with supervised DTL/DTLS using model.backbone
    """

    def __init__(self, model, device=Config.DEVICE,
                 proj_dim=Config.SSL_PROJECTION_DIM,
                 temperature=Config.SSL_TEMPERATURE,
                 lr=Config.SSL_LR):
        self.model = model
        self.device = device
        self.proj_head = SimCLRProjectionHead(
            embed_dim=Config.EMBED_DIM, proj_dim=proj_dim
        ).to(device)
        self.criterion = NTXentLoss(temperature=temperature)
        self.lr = lr

    def pretrain(self, train_loader: DataLoader, epochs: int = Config.SSL_EPOCHS,
                 verbose: bool = True):
        """
        Pre-trains the backbone via SimCLR on the two-view DataLoader.

        Args:
            train_loader : DataLoader returning (view1, view2) batches.
                           Wrap your DermDataset with TwoViewDataset first.
            epochs       : Number of SSL pre-training epochs.
            verbose      : Print loss per epoch.
        """
        self.model.train()
        self.proj_head.train()

        params = (list(self.model.parameters()) +
                  list(self.proj_head.parameters()))
        optimizer = Adam(params, lr=self.lr, weight_decay=1e-4)
        scheduler = CosineAnnealingLR(optimizer, T_max=max(epochs, 1))

        print(f"\n[SSL] Starting SimCLR pre-training for {epochs} epochs ...")
        for epoch in range(1, epochs + 1):
            total_loss = 0.0
            n_batches = 0
            for v1, v2 in train_loader:
                v1, v2 = v1.to(self.device), v2.to(self.device)
                optimizer.zero_grad()

                # forward through backbone → projection head
                _, e1 = self.model(v1, return_embedding=True)
                _, e2 = self.model(v2, return_embedding=True)
                z1 = self.proj_head(e1)
                z2 = self.proj_head(e2)

                loss = self.criterion(z1, z2)
                loss.backward()
                optimizer.step()

                total_loss += loss.item()
                n_batches += 1

            scheduler.step()
            avg_loss = total_loss / max(n_batches, 1)
            if verbose:
                print(f"  [SSL] epoch {epoch}/{epochs}  loss={avg_loss:.4f}")

        print("[SSL] Pre-training complete. Projection head discarded; "
              "backbone weights updated.\n")
        return self.model


def make_ssl_loader(train_dataset, batch_size=Config.BATCH_SIZE,
                    num_workers=Config.NUM_WORKERS):
    """Convenience: wraps a DermDataset in TwoViewDataset and returns a DataLoader."""
    ssl_ds = TwoViewDataset(train_dataset)
    return DataLoader(ssl_ds, batch_size=batch_size, shuffle=True,
                      num_workers=num_workers, pin_memory=True, drop_last=True)
