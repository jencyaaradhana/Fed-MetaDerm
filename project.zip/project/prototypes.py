"""
prototypes.py
-------------
Tail-Aware Prototype Learning for Fed-MetaDerm:
- PrototypeBank: Maintains per-class exponential moving average feature prototypes.
- prototypical_loss: Computes distance-based prototype cross-entropy loss.
- compute_local_prototypes & prototype_alignment_loss utilities.
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict


class PrototypeBank:
    """
    Maintains per-class prototype embeddings (running average of feature vectors).
    """
    def __init__(self, num_classes: int = 216, feat_dim: int = 512, device: str = "cpu", momentum: float = 0.9):
        self.num_classes = num_classes
        self.feat_dim = feat_dim
        self.device = torch.device(device)
        self.momentum = momentum

        self.prototypes = torch.zeros(num_classes, feat_dim, device=self.device)
        self.initialized = torch.zeros(num_classes, dtype=torch.bool, device=self.device)

    def to(self, device):
        self.device = torch.device(device)
        self.prototypes = self.prototypes.to(self.device)
        self.initialized = self.initialized.to(self.device)
        return self

    def save(self, path):
        import os
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            "prototypes": self.prototypes,
            "initialized": self.initialized,
            "num_classes": self.num_classes,
            "feat_dim": self.feat_dim,
        }, path)

    def load(self, path):
        data = torch.load(path, map_location=self.device)
        self.prototypes = data["prototypes"].to(self.device)
        self.initialized = data["initialized"].to(self.device)
        self.num_classes = data.get("num_classes", self.num_classes)
        self.feat_dim = data.get("feat_dim", self.feat_dim)
        return self

    def update(self, feats: torch.Tensor, labels: torch.Tensor):
        feats = F.normalize(feats.to(self.device), dim=-1)
        labels = labels.to(self.device)

        for c in range(self.num_classes):
            mask = (labels == c)
            if mask.sum() > 0:
                c_feats = feats[mask].mean(dim=0)
                if not self.initialized[c]:
                    self.prototypes[c] = c_feats
                    self.initialized[c] = True
                else:
                    self.prototypes[c] = (
                        self.momentum * self.prototypes[c] + (1.0 - self.momentum) * c_feats
                    )
                self.prototypes[c] = F.normalize(self.prototypes[c], dim=-1)

    def get_prototypes(self):
        return self.prototypes

    def classify_by_prototype(self, embedding: torch.Tensor):
        feats = F.normalize(embedding.to(self.device), dim=-1)
        protos = self.prototypes.to(self.device)
        sims = torch.matmul(feats, protos.T)
        init_mask = self.initialized.to(self.device)
        sims = sims.masked_fill(~init_mask.unsqueeze(0), -1e9)
        preds = sims.argmax(dim=-1)
        return preds, sims


def prototypical_loss(feats: torch.Tensor, labels: torch.Tensor,
                      proto_bank: PrototypeBank, temperature: float = 0.1) -> torch.Tensor:
    """
    Computes negative log likelihood based on Euclidean / cosine distance to class prototypes.
    """
    if not proto_bank.initialized.any():
        return torch.tensor(0.0, device=feats.device)

    feats = F.normalize(feats, dim=-1)
    protos = proto_bank.prototypes.to(feats.device)

    # Cosine similarities
    sims = torch.matmul(feats, protos.T) / temperature
    
    # Mask uninitialized prototypes
    init_mask = proto_bank.initialized.to(feats.device)
    sims = sims.masked_fill(~init_mask.unsqueeze(0), -1e9)

    return F.cross_entropy(sims, labels.to(feats.device))


def compute_local_prototypes(model: nn.Module, dataloader, device: torch.device) -> Dict[int, torch.Tensor]:
    model.eval()
    class_features = {}
    class_counts = {}

    with torch.no_grad():
        for images, labels in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            if hasattr(model, "extract_features"):
                feats = model.extract_features(images)
            else:
                feats = model(images)

            for feat, lbl in zip(feats, labels):
                c = int(lbl.item())
                if c not in class_features:
                    class_features[c] = feat.clone()
                    class_counts[c] = 1
                else:
                    class_features[c] += feat
                    class_counts[c] += 1

    prototypes = {}
    for c in class_features:
        prototypes[c] = class_features[c] / class_counts[c]
        prototypes[c] = F.normalize(prototypes[c], dim=-1)

    return prototypes


def prototype_alignment_loss(features: torch.Tensor, labels: torch.Tensor,
                             prototypes: Dict[int, torch.Tensor],
                             temperature: float = 0.1) -> torch.Tensor:
    if not prototypes:
        return torch.tensor(0.0, device=features.device)

    loss = 0.0
    count = 0
    norm_feats = F.normalize(features, dim=-1)

    for feat, lbl in zip(norm_feats, labels):
        c = int(lbl.item())
        if c in prototypes:
            proto = prototypes[c].to(features.device)
            sim = torch.dot(feat, proto) / temperature
            loss += (1.0 - sim)
            count += 1

    if count == 0:
        return torch.tensor(0.0, device=features.device)
    return loss / count
