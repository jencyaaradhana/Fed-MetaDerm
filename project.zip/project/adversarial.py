"""
adversarial.py
--------------
Adversarial Training & Robustness for Fed-MetaDerm:
Implements PGD (Projected Gradient Descent) attack, generate_adversarial,
and adversarial loss computation.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def pgd_attack(model: nn.Module, images: torch.Tensor, labels: torch.Tensor,
               criterion: nn.Module = None, epsilon: float = 8 / 255.0,
               alpha: float = 2 / 255.0, iters: int = 5, device=None) -> torch.Tensor:
    if criterion is None or not isinstance(criterion, nn.Module):
        criterion = nn.CrossEntropyLoss()

    if device is None or not isinstance(device, (torch.device, str)):
        device = next(model.parameters()).device

    device = torch.device(device)
    model.eval()
    orig_images = images.clone().detach().to(device)
    adv_images = orig_images.clone().detach().requires_grad_(True)
    labels = labels.to(device)

    for _ in range(iters):
        outputs = model(adv_images)
        loss = criterion(outputs, labels)

        model.zero_grad()
        loss.backward()

        with torch.no_grad():
            if adv_images.grad is not None:
                adv_images = adv_images + alpha * adv_images.grad.sign()
                eta = torch.clamp(adv_images - orig_images, min=-epsilon, max=epsilon)
                adv_images = torch.clamp(orig_images + eta, min=0.0, max=1.0).detach().requires_grad_(True)

    return adv_images.detach()


def generate_adversarial(model: nn.Module, images: torch.Tensor, labels: torch.Tensor,
                         *args, epsilon: float = 8 / 255.0, device=None, criterion=None, **kwargs) -> torch.Tensor:
    if device is None or not isinstance(device, (torch.device, str)):
        device = next(model.parameters()).device
    if not isinstance(epsilon, (float, int)):
        epsilon = 8 / 255.0

    # check if criterion was passed positionally in args
    for a in args:
        if isinstance(a, nn.Module):
            criterion = a

    return pgd_attack(model, images, labels, criterion=criterion, epsilon=epsilon, device=device)


def adversarial_loss(model: nn.Module, images: torch.Tensor, labels: torch.Tensor,
                     criterion: nn.Module = None, epsilon: float = 8 / 255.0,
                     alpha: float = 2 / 255.0, iters: int = 5, device=None) -> torch.Tensor:
    if criterion is None or not isinstance(criterion, nn.Module):
        criterion = nn.CrossEntropyLoss()

    adv_images = pgd_attack(model, images, labels, criterion, epsilon, alpha, iters, device)
    model.train()
    adv_outputs = model(adv_images)
    return criterion(adv_outputs, labels.to(adv_images.device))
