# 🚀 How to Run Fed-MetaDerm Training on Kaggle (GPU)

This guide walks you through running full Fed-MetaDerm federated training on **Kaggle** using a **free T4 GPU**.

---

## ⚡ Quick Overview

| Step | Action | Time |
|------|--------|------|
| 1 | Zip the project folder | 2 min |
| 2 | Upload zip as a Kaggle Dataset | 5–10 min |
| 3 | Create a new Kaggle Notebook | 1 min |
| 4 | Upload & run the training notebook | 1 min |
| 5 | Training runs automatically | ~25–35 min |
| 6 | Download trained model from Output tab | 2 min |

---

## 📋 Detailed Step-by-Step Instructions

### Step 1: Zip the Project Folder

On your local machine, zip the entire `project` folder into `project.zip`.

**What to include:**
- ✅ All Python code files (`federated_pipeline.py`, `app.py`, `model.py`, etc.)
- ✅ `fed_metaderm_data/` folder (contains ISIC images and hospital partitions)
- ✅ `requirements.txt`
- ✅ `config.py`
- ✅ `manifest/` folder
- ✅ `outputs/` folder (can be empty)
- ✅ `checkpoints/` folder (can be empty)

**How to zip (Windows):**
1. Navigate to `E:\final pro\project\project (6)\project (6)\project\`
2. Select ALL files and folders inside
3. Right-click → **Send to** → **Compressed (zipped) folder**
4. Rename the zip to `project.zip`

**Or use PowerShell:**
```powershell
cd "E:\final pro\project\project (6)\project (6)\project"
Compress-Archive -Path * -DestinationPath "E:\final pro\project.zip" -Force
```

> ⚠️ **Size Check:** The zip should be around 500 MB–1.5 GB depending on images. Kaggle allows datasets up to **100 GB**.

---

### Step 2: Upload as a Kaggle Dataset

Kaggle notebooks can't directly upload large files — you need to create a **Dataset** first.

1. Go to [kaggle.com/datasets](https://www.kaggle.com/datasets)
2. Click **"+ New Dataset"** (top-right)
3. Give it a name: `fedmetaderm-project`
4. Click **"Select Files to Upload"** and choose your `project.zip`
5. Wait for upload to complete (progress bar)
6. Set visibility to **Private**
7. Click **"Create"**

> 💡 **Tip:** If your internet is slow, you can also use the [Kaggle API](https://github.com/Kaggle/kaggle-api):
> ```bash
> kaggle datasets create -p /path/to/folder/containing/zip
> ```

---

### Step 3: Create a New Kaggle Notebook

1. Go to [kaggle.com](https://www.kaggle.com/)
2. Click **"+ Create"** → **"New Notebook"**
3. A blank notebook opens

---

### Step 4: Configure the Notebook

#### 4a. Enable GPU
1. On the **right sidebar**, find **Settings** (gear icon)
2. Under **Accelerator**, select **GPU T4 x2** (or **P100**)
3. Turn **ON** the **Internet** toggle (needed for pip install)

#### 4b. Attach Your Dataset
1. On the **right sidebar**, click **"+ Add Input"**
2. Search for your dataset: `fedmetaderm-project`
3. Click **"Add"** — it will appear under `/kaggle/input/fedmetaderm-project/`

#### 4c. Upload the Training Notebook
1. Click **File** → **Import Notebook**
2. Upload the file: `FedMetaDerm_Kaggle_Training.ipynb` (located in your project folder)
3. The notebook cells will load automatically

> **Alternative:** Instead of importing, you can manually copy-paste the cells from the notebook.

---

### Step 5: Run the Notebook

Click **"Run All"** (▶▶ button at the top) or run cells one by one:

| Cell | What it does | Time |
|------|-------------|------|
| Cell 1 | Checks GPU is active | 5 sec |
| Cell 2 | Finds your uploaded dataset | 5 sec |
| Cell 3 | Extracts project.zip to working directory | 1–2 min |
| Cell 4 | Installs extra packages (phe, timm, lime) | 1 min |
| Cell 5 | **Runs full 3-round federated training** | **~25–35 min** |
| Cell 6 | Shows training summary | 5 sec |
| Cell 7 | Displays evaluation plots | 10 sec |
| Cell 8 | Packages results into downloadable zip | 30 sec |

---

### Step 6: Download the Trained Model

**⚠️ Important — Kaggle download is different from Colab!**

On Kaggle, you **cannot** use `files.download()`. Instead:

1. After all cells finish, click **"Save Version"** (top-right blue button)
2. Select **"Save & Run All (Commit)"**
3. Wait for the commit to finish (same ~35 min)
4. Go to your notebook's page
5. Click the **"Output"** tab
6. You'll see `fedmetaderm_full_trained_results.zip`
7. Click the **download icon** ⬇️ next to it

**Quick alternative (skip re-run):**
- You can also download directly from the running session:
  - On the right sidebar, expand **Output** section
  - Click the file to download

---

### Step 7: Use the Trained Model Locally

1. Extract `fedmetaderm_full_trained_results.zip`
2. Copy `outputs/` and `checkpoints/` back into your local project directory:
   ```
   E:\final pro\project\project (6)\project (6)\project\
   ```
3. Launch the Streamlit GUI:
   ```powershell
   cd "E:\final pro\project\project (6)\project (6)\project"
   streamlit run app.py
   ```
4. Open `http://localhost:8501` in your browser

---

## 🔧 Troubleshooting

### "No GPU detected"
- Make sure you selected **GPU T4 x2** in Settings → Accelerator
- Kaggle gives 30 hours/week of free GPU. Check your quota at [kaggle.com/me/account](https://www.kaggle.com/me/account)

### "Module not found" errors
- Make sure Internet is enabled in Settings
- The notebook installs `phe`, `timm`, `lime`, `reportlab` automatically
- If `torch` is missing (unlikely), Kaggle pre-installs it

### "FileNotFoundError: fed_metaderm_data"
- Your dataset was not attached properly
- Go to right sidebar → **Add Input** → search for your dataset → **Add**
- Run Cell 2 again to check the path

### "Out of Memory (OOM)"
- Reduce batch size: change `--batch_size 32` to `--batch_size 16` in Cell 5
- Or use `--batch_size 8` for very large datasets

### Upload is too slow
- Consider uploading to Google Drive first, then using the Kaggle API
- Or split your dataset into smaller zips

---

## 📊 Kaggle vs Colab Comparison

| Feature | Kaggle | Google Colab |
|---------|--------|-------------|
| Free GPU | T4 x2 (30 hrs/week) | T4 (limited) |
| Max session | 12 hours | 12 hours |
| Disk space | 73 GB | 107 GB |
| Internet | Toggle in settings | Always on |
| Download method | Output tab | `files.download()` |
| Dataset upload | Kaggle Datasets | Direct upload / Drive |
| Pre-installed libs | More (sklearn, xgb) | Fewer |

---

## 📁 Expected Output Files

After training completes, you'll get:

```
fedmetaderm_full_trained_results.zip/
├── outputs/
│   ├── global_model_final.pt          # Final trained global model
│   ├── final_summary.json             # Training metrics summary
│   ├── pipeline_state.json            # Pipeline checkpoint state
│   └── final_evaluation/
│       ├── confusion_matrix.png       # 8×8 confusion matrix
│       ├── roc_curves.png             # ROC curves per class
│       ├── f1_per_class.png           # F1-score bar chart
│       └── training_curves.png        # Loss/accuracy curves
└── checkpoints/
    ├── hospital_0_personalized.pt     # Hospital A model
    ├── hospital_1_personalized.pt     # Hospital B model
    ├── hospital_2_personalized.pt     # Hospital C model
    └── hospital_3_personalized.pt     # Hospital D model
```
