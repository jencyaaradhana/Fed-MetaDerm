# Fed-MetaDerm — Complete Local Pipeline

**Rarity-Aware Prototype-Guided Federated Learning for Skin Disease Diagnosis**

Trains entirely on your local machine using real datasets
(HAM10000, ISIC2018, Derm7pt, SD198). No synthetic data. No Kaggle required.

---

## Architecture Overview

```
Private Long-Tail Dataset (per hospital)
  │
  ├─► [Stage 0] SimCLR Self-Supervised Pre-training  (Hospital 3/N)
  │
  ├─► [Stage 1-3] DTL/DTLS Staged Transfer Learning (EfficientNet-B0 + CBAM)
  │       MixUp + CutMix + ResizeMix augmentation
  │       Adversarial Training (FGSM / PGD)
  │       Prototypical Network → Local Disease Prototypes
  │       Monte Carlo Dropout → Predictive Uncertainty σ
  │
  ├─► [Explainability]
  │       ScoreCAM (gradient-free heatmap)
  │       LIME (superpixel, model-agnostic)
  │       Saliency Maps
  │       Prototype Similarity
  │
  └─► Encrypted Model + Prototype Updates → CLOUD SERVER
          │
          ├─► Federated NAS (architecture search)
          ├─► Federated Meta-Learning (Reptile)
          ├─► RUPA: Rarity- & Uncertainty-Aware Prototype Aggregation
          │       Client Data Contribution
          │       Disease Rarity Score
          │       Predictive Uncertainty / Reliability Score
          │       ─► Adaptive Client Weight
          ├─► Secure Aggregation
          │       SMPC (additive secret sharing)
          │       Paillier Homomorphic Encryption (prototypes)
          │       Differential Privacy (Gaussian noise)
          │       Blockchain Ledger (hash chain)
          │       PBFT Consensus Vote
          │
          └─► Global Model + Global Disease Prototypes
                  │
                  ├─► TAIL-AWARE PROTOTYPE PERSONALIZATION  [NOVEL]
                  │       θ_local + θ_global → Adaptive Calibration
                  │       → Personalized Disease Prototypes
                  │
                  └─► UNCERTAINTY-GUIDED KNOWLEDGE DISTILLATION  [NOVEL]
                          Global Model (Teacher)
                          → Personalized Hospital Model (Student)
                          Uncertainty gate: down-weight noisy teacher predictions
```

---

## File Map

| File | Diagram Block |
|---|---|
| `config.py` | All hyperparameters — auto-detects local vs Kaggle |
| `dataset.py` | Image preprocessing, hospital splits, MixUp/CutMix/ResizeMix |
| `model.py` | EfficientNet-B0 + CBAM attention + DTL/DTLS staged unfreezing |
| `adversarial.py` | FGSM / PGD adversarial training |
| `prototypes.py` | Prototypical Network, Local Disease Prototypes |
| `uncertainty.py` | Monte Carlo Dropout, predictive entropy, BALD |
| `self_supervised.py` | **[NEW]** SimCLR self-supervised pre-training (Hospital 3/N) |
| `personalization.py` | **[NEW]** Tail-Aware Prototype Personalization |
| `knowledge_distillation.py` | **[NEW]** Uncertainty-Guided Knowledge Distillation |
| `explainability.py` | **[ENHANCED]** ScoreCAM + LIME + Saliency + Prototype Similarity |
| `evaluate.py` | **[NEW]** Per-class metrics, AUC-ROC, ECE, confusion matrix, calibration |
| `train_client.py` | Full local hospital training pipeline (all stages) |
| `fed_metaderm_server.py` | NAS, Reptile, RUPA, SMPC, Paillier HE, DP, Blockchain, PBFT |
| `federated_pipeline.py` | **[NEW]** Single entry point — runs the complete pipeline locally |
| `build_dataset_manifest.py` | Scans datasets, builds manifest.csv (auto local/Kaggle) |
| `run_all_hospitals.py` | Trains each hospital independently (no server aggregation) |

---

## Quick Start

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Add your images

The `fed_metaderm_data/` folder already contains:
- `HAM10000/hospital_partitions/hospital_0..4.csv` — image IDs + labels
- `HAM10000/disease_rarity_scores.csv` — per-class rarity weights
- `ISIC2018/` — same structure

**You must place the actual image files** into the `processed_images/` folder:

```
fed_metaderm_data/
  HAM10000/
    processed_images/        ← place HAM10000 .jpg files here
    hospital_partitions/     ✓ already present
    disease_rarity_scores.csv ✓ already present
  ISIC2018/
    processed_images/        ← place ISIC2018 .jpg files here
    hospital_partitions/     ✓ already present
```

**Download HAM10000 images:**
→ https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000
Extract `HAM10000_images_part1/` and `HAM10000_images_part2/` into
`fed_metaderm_data/HAM10000/processed_images/`

**Download ISIC 2018 images:**
→ https://challenge.isic-archive.com/data/#2018
Extract `ISIC2018_Task3_Training_Input/` into
`fed_metaderm_data/ISIC2018/processed_images/`

### Step 3 — Run the complete pipeline
```bash
# Full pipeline (all rounds, all hospitals)
python federated_pipeline.py

# Fast smoke-test (1 epoch per stage, 2 explainability images)
python federated_pipeline.py --fast

# Disable LIME for faster explainability
python federated_pipeline.py --no_lime

# Custom: 3 rounds, batch size 8
python federated_pipeline.py --rounds 3 --batch_size 8
```

### Step 4 — Train a single hospital only
```bash
python train_client.py
```

---

## Outputs

All outputs land in `outputs/` and `checkpoints/`:

```
checkpoints/
  hospital_0_model.pt              best-val-acc EfficientNet weights
  hospital_0_prototypes.pt         local disease prototypes
  hospital_0_personalized_r1.pt    personalized after round 1
  hospital_0_history.json          train/val loss+acc per epoch+stage

outputs/
  hospital_0_uncertainty.json      MC-Dropout entropy + BALD per val image
  hospital_0_explainability/
    explain_000.png                ScoreCAM + LIME + Saliency + Prototype panel
    reports.json
  round_01_evaluation/
    HAM10000/
      confusion_matrix.png
      per_class_f1.png
      roc_curves.png
      calibration.png
      uncertainty_vs_accuracy.png
      evaluation_report.json       accuracy, macro F1, AUC-ROC, ECE
  global_model_final.pt
  global_prototypes_final.pt
  convergence_curve.png            val_acc per hospital per federated round
  blockchain_ledger.json
  final_summary.json
```

---

## Why ScoreCAM instead of Grad-CAM?

| | Grad-CAM | ScoreCAM |
|---|---|---|
| Gradients required | Yes | **No** |
| EfficientNet depthwise conv stability | Poor | **Good** |
| Faithfulness (insertion/deletion AUC) | Lower | **Higher** |
| Speed | Fast | Moderate |
| Medical imaging | Standard baseline | **Recommended** |

ScoreCAM scores each feature map channel by how much the model's confidence
changes when only that channel's activation pattern is shown. This produces
sharper, more faithful heatmaps especially for EfficientNet's depthwise-
separable layers where gradient flow can be noisy.

LIME provides a complementary model-agnostic view using superpixel masking.

---

## Hyperparameter Reference

Edit `config.py` to change any of:

| Parameter | Default | Description |
|---|---|---|
| `BACKBONE` | `efficientnet_b0` | Any timm model |
| `STAGE1/2/3_EPOCHS` | 5/8/10 | DTL/DTLS staged epochs |
| `BATCH_SIZE` | 16 | Reduce to 8 if GPU < 6 GB |
| `FED_ROUNDS` | 5 | Federated aggregation rounds |
| `PERSONALIZATION_ALPHA` | 0.4 | Global blend strength (0=local, 1=global) |
| `KD_TEMPERATURE` | 4.0 | KD softening temperature |
| `KD_ALPHA` | 0.7 | KD soft-label weight vs hard CE |
| `USE_SELF_SUPERVISED` | False | Enable SimCLR for Hospital 3/N |
| `DP_EPSILON` | 1.0 | Differential privacy budget |
| `USE_ADVERSARIAL` | True | PGD adversarial training |
| `USE_LIME` | True | LIME explainability (slower) |
