"""
federated_nas.py -- Module 1: federated neural architecture search on the REAL client model.

Eq. (3):  A* = argmin_A  sum_i p_i * l_i( w_i(A), D_i ),   p_i = |D_i| / sum_j |D_j|
Each hospital trains every candidate briefly on a small local subset and returns ONLY its
validation loss (no images, no weights leave the hospital). The search space covers the
backbone, the embedding width (feature_dim) and the dropout rate.
"""
import itertools
import time

import torch
import torch.nn.functional as F

from model import FedMetaDermClientModel


DEFAULT_SPACE = {
    "backbone_name": ["efficientnet_b0", "mobilenetv3_large_100"],
    "feature_dim":   [256, 512],
    "dropout_p":     [0.3],
}


def candidates_from_space(space=None):
    space = space or DEFAULT_SPACE
    keys = list(space)
    return [dict(zip(keys, vals)) for vals in itertools.product(*[space[k] for k in keys])]


def _present_class_ce(logits, labels, present_mask):
    """CE restricted to the classes this hospital actually has (shared 197-way head)."""
    return F.cross_entropy(logits.masked_fill(~present_mask, -1e4), labels)


def local_candidate_eval(cand, train_loader, val_loader, num_classes, present_mask,
                         device, steps=20, lr=1e-3, pretrained=True, max_val_batches=5):
    """Runs on a hospital. Returns the validation loss of candidate `cand`."""
    model = FedMetaDermClientModel(num_classes=num_classes, pretrained=pretrained, **cand).to(device)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=lr)
    model.train()
    it = iter(train_loader)
    for _ in range(steps):
        try:
            x, y = next(it)
        except StopIteration:
            it = iter(train_loader)
            x, y = next(it)
        x, y = x.to(device), y.to(device)
        opt.zero_grad()
        _present_class_ce(model(x), y, present_mask).backward()
        opt.step()
    model.eval()
    tot, n = 0.0, 0
    with torch.no_grad():
        for b, (x, y) in enumerate(val_loader):
            if b >= max_val_batches:
                break
            x, y = x.to(device), y.to(device)
            tot += _present_class_ce(model(x), y, present_mask).item() * len(y)
            n += len(y)
    return tot / max(n, 1)


def federated_nas(hospital_data, num_classes, device, space=None, steps=20, pretrained=True,
                  verbose=True):
    """hospital_data: list of dicts {train_loader, val_loader, present_mask(bool tensor [C]), size}.
    Returns (best_candidate, table) where table rows hold per-hospital losses and the weighted score."""
    cands = candidates_from_space(space)
    sizes = [h["size"] for h in hospital_data]
    p = [s / sum(sizes) for s in sizes]
    table = []
    for cand in cands:
        t0 = time.time()
        losses = [local_candidate_eval(cand, h["train_loader"], h["val_loader"], num_classes,
                                       h["present_mask"].to(device), device, steps=steps,
                                       pretrained=pretrained)
                  for h in hospital_data]
        score = sum(pi * l for pi, l in zip(p, losses))
        table.append({"candidate": cand, "hospital_losses": losses, "weighted_loss": score,
                      "seconds": time.time() - t0})
        if verbose:
            print(f"[FedNAS] {cand}  weighted val loss = {score:.4f}  ({time.time()-t0:.0f}s)")
    best = min(table, key=lambda r: r["weighted_loss"])
    if verbose:
        print(f"[FedNAS] selected A* = {best['candidate']}")
    return best["candidate"], table
