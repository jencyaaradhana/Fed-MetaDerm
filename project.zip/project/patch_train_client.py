"""
Patch train_client.py to add:
1. Periodic checkpoint saving every N global epochs (default 15)
2. Federated-round-level checkpoint saving in federated_pipeline.py
"""
import os, re

# ─────────────────────────────────────────────────
# 1.  Patch train_client.py
# ─────────────────────────────────────────────────
tc_path = os.path.join(os.path.dirname(__file__), "train_client.py")
with open(tc_path, "rb") as f:
    raw = f.read()
src = raw.decode("utf-8")

OLD_BLOCK = (
    "    global_epoch = 0\r\n"
    "    for stage_id, n_epochs, lr, stage_desc in stages:\r\n"
)

NEW_BLOCK = (
    "    global_epoch = 0\r\n"
    "    checkpoint_interval = getattr(cfg, 'CHECKPOINT_INTERVAL', 15)\r\n"
    "    periodic_ckpt_dir = os.path.join(cfg.CHECKPOINT_DIR, 'periodic')\r\n"
    "    os.makedirs(periodic_ckpt_dir, exist_ok=True)\r\n"
    "\r\n"
    "    for stage_id, n_epochs, lr, stage_desc in stages:\r\n"
)

assert OLD_BLOCK in src, "Could not find OLD_BLOCK in train_client.py"
src = src.replace(OLD_BLOCK, NEW_BLOCK, 1)

OLD_SAVE = (
    "            if vl_acc > best_val_acc:\r\n"
    "                best_val_acc = vl_acc\r\n"
    "                torch.save({\r\n"
    "                    \"model_state_dict\": model.state_dict(),\r\n"
    "                    \"val_acc\": vl_acc,\r\n"
    "                    \"stage\": stage_id, \"epoch\": epoch + 1,\r\n"
    "                }, best_path)\r\n"
    "                print(f\"    [OK] new best saved (val_acc={vl_acc:.4f})\")\r\n"
    "\r\n"
)

NEW_SAVE = (
    "            if vl_acc > best_val_acc:\r\n"
    "                best_val_acc = vl_acc\r\n"
    "                torch.save({\r\n"
    "                    \"model_state_dict\": model.state_dict(),\r\n"
    "                    \"val_acc\": vl_acc,\r\n"
    "                    \"stage\": stage_id, \"epoch\": epoch + 1,\r\n"
    "                }, best_path)\r\n"
    "                print(f\"    [OK] new best saved (val_acc={vl_acc:.4f})\")\r\n"
    "\r\n"
    "            # ── Periodic checkpoint every checkpoint_interval global epochs ──\r\n"
    "            if global_epoch % checkpoint_interval == 0:\r\n"
    "                periodic_path = os.path.join(\r\n"
    "                    periodic_ckpt_dir,\r\n"
    "                    f\"hospital_{hospital_id}_epoch_{global_epoch:03d}.pt\"\r\n"
    "                )\r\n"
    "                torch.save({\r\n"
    "                    \"model_state_dict\": model.state_dict(),\r\n"
    "                    \"val_acc\":    vl_acc,\r\n"
    "                    \"train_acc\":  tr_acc,\r\n"
    "                    \"train_loss\": tr_loss,\r\n"
    "                    \"val_loss\":   vl_loss,\r\n"
    "                    \"stage\":      stage_id,\r\n"
    "                    \"epoch\":      epoch + 1,\r\n"
    "                    \"global_epoch\": global_epoch,\r\n"
    "                    \"hospital_id\":  hospital_id,\r\n"
    "                }, periodic_path)\r\n"
    "                print(f\"    [CKPT] Epoch {global_epoch:03d} saved -> {periodic_path}\")\r\n"
    "\r\n"
)

assert OLD_SAVE in src, "Could not find OLD_SAVE block in train_client.py"
src = src.replace(OLD_SAVE, NEW_SAVE, 1)

with open(tc_path, "wb") as f:
    f.write(src.encode("utf-8"))

print("✅  train_client.py patched — periodic checkpoints every 15 epochs added.")

# ─────────────────────────────────────────────────
# 2.  Patch federated_pipeline.py — save global
#     model after every fed round
# ─────────────────────────────────────────────────
fp_path = os.path.join(os.path.dirname(__file__), "federated_pipeline.py")
with open(fp_path, "rb") as f:
    raw2 = f.read()
src2 = raw2.decode("utf-8")

OLD_ROUND_END = (
    "        round_dt = time.time() - round_start\r\n"
    "        print(f\"  Round {fed_round} completed in {round_dt:.1f}s.\")\r\n"
)

NEW_ROUND_END = (
    "        round_dt = time.time() - round_start\r\n"
    "        print(f\"  Round {fed_round} completed in {round_dt:.1f}s.\")\r\n"
    "\r\n"
    "        # ── Save global model after every federated round ──────────────\r\n"
    "        out_dir_r = Path(cfg.OUTPUT_DIR)\r\n"
    "        round_ckpt = out_dir_r / f\"global_model_round_{fed_round:02d}.pt\"\r\n"
    "        torch.save({\r\n"
    "            \"model_state_dict\": global_effnet.state_dict(),\r\n"
    "            \"global_prototypes\": global_prototypes,\r\n"
    "            \"round\": fed_round,\r\n"
    "            \"fed_history\": fed_history,\r\n"
    "        }, round_ckpt)\r\n"
    "        print(f\"  [CKPT] Global model saved -> {round_ckpt}\")\r\n"
)

assert OLD_ROUND_END in src2, "Could not find round-end block in federated_pipeline.py"
src2 = src2.replace(OLD_ROUND_END, NEW_ROUND_END, 1)

with open(fp_path, "wb") as f:
    f.write(src2.encode("utf-8"))

print("✅  federated_pipeline.py patched — global model saved after every fed round.")
print("\nAll patches applied successfully.")
