"""
explainability.py
-----------------
Implements the "Clinical Output / Explainability" row:

  ► ScoreCAM   (replaces Grad-CAM — gradient-free, more stable for
                medical imaging; Chen et al., 2020)
  ► LIME       (Local Interpretable Model-agnostic Explanations —
                fully model-agnostic superpixel-based explanation)
  ► Saliency Maps (vanilla gradient w.r.t. input)
  ► Predictive Uncertainty (from MC-Dropout, uncertainty.py)
  ► Prototype Similarity   (cosine similarity to class prototypes)

WHY ScoreCAM instead of GradCAM?
  - GradCAM depends on gradients which can be noisy / unstable for
    EfficientNet's depthwise-separable convolutions.
  - ScoreCAM is GRADIENT-FREE: it scores each feature map channel by
    how much the network's confidence drops when that channel is masked,
    producing sharper and more faithful localisation maps.
  - Studies on dermatology datasets show ScoreCAM consistently produces
    higher-fidelity localisation for skin lesion classification.

ScoreCAM algorithm (one forward pass per channel batch):
  1. Extract feature maps A (C×h×w) from target layer.
  2. For each channel c: upsample A_c to input size, normalise -> mask M_c.
  3. Masked input: X_c = X * M_c  (channel masking, not dropout).
  4. Score s_c = model(X_c)[target_class] — how much does channel c help?
  5. CAM = ReLU(Σ_c  s_c * A_c)  then normalise to [0,1].
"""

import os
import sys
import io

os.environ["TQDM_DISABLE"] = "1"
if getattr(sys, "stdout", None) is None:
    sys.stdout = io.StringIO()
if getattr(sys, "stderr", None) is None:
    sys.stderr = io.StringIO()
import copy
import numpy as np
import torch
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")          # non-interactive backend for saving files
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import cv2

from config import Config
from uncertainty import mc_dropout_predict

# Optional LIME import
try:
    from lime import lime_image
    from lime.wrappers.scikit_image import SegmentationAlgorithm
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False
    print("[explainability] LIME not installed. "
          "Run:  pip install lime   to enable LIME explanations.")


# -----------------------------------------------------------------------
# Shared helpers
# -----------------------------------------------------------------------
_MEAN = np.array([0.485, 0.456, 0.406])
_STD  = np.array([0.229, 0.224, 0.225])


def _unnormalize(img_tensor: torch.Tensor) -> np.ndarray:
    """Convert a normalised CHW tensor to a HWC [0,1] numpy array."""
    img = img_tensor.detach().cpu().numpy().transpose(1, 2, 0)
    return np.clip(img * _STD + _MEAN, 0, 1)


def _normalize_heatmap(heatmap: np.ndarray) -> np.ndarray:
    """Normalise a 2D heatmap to [0, 1]."""
    heatmap = np.clip(heatmap, 0, None)   # ReLU equivalent
    lo, hi = heatmap.min(), heatmap.max()
    if hi - lo < 1e-6:
        return np.zeros_like(heatmap)
    return (heatmap - lo) / (hi - lo)


def _auto_find_conv_layer(model):
    """Return the last Conv2d inside model that actually executes during forward."""
    ran = []
    handles = []
    for m in model.modules():
        if isinstance(m, torch.nn.Conv2d):
            h = m.register_forward_hook(lambda mod, i, o, c=m: ran.append(c))
            handles.append(h)
    with torch.no_grad():
        try:
            device = next(model.parameters()).device
            dummy = torch.zeros(1, 3, 224, 224, device=device)
            model(dummy)
        except Exception:
            pass
        finally:
            for h in handles:
                h.remove()
    if ran:
        for c in reversed(ran):
            if c.out_channels > 1:
                return c
        return ran[-1]
    for m in model.modules():
        if isinstance(m, torch.nn.Conv2d):
            return m
    return None


# -----------------------------------------------------------------------
# ScoreCAM  (gradient-free class activation mapping)
# -----------------------------------------------------------------------
class ScoreCAM:
    """
    Gradient-free ScoreCAM for FedMetaDermClientModel.

    Usage:
        scorer = ScoreCAM(model)
        heatmap, class_idx = scorer(image_tensor)   # (1,C,H,W)
    """

    def __init__(self, model, target_layer=None,
                 max_batch: int = Config.SCORECAM_MAX_BATCH):
        self.model = model
        self.max_batch = max_batch
        self._activations = None

        if target_layer is None:
            target_layer = _auto_find_conv_layer(model)
        self.target_layer = target_layer

        # Register hook to capture feature maps during forward pass
        self._hook = self.target_layer.register_forward_hook(
            self._save_activation
        )

    def _save_activation(self, module, inp, out):
        self._activations = out.detach().cpu()   # (1, C, h, w)

    def remove_hooks(self):
        self._hook.remove()

    @torch.no_grad()
    def __call__(self, image_tensor: torch.Tensor,
                 class_idx: int = None) -> tuple:
        """
        Args:
            image_tensor : (1, C, H, W) normalised, on model's device
            class_idx    : target class (None = predicted class)

        Returns:
            heatmap    : (H, W) numpy array in [0, 1]
            class_idx  : int, the class whose score was used
        """
        self.model.eval()
        device = next(self.model.parameters()).device
        img = image_tensor.to(device)
        H, W = img.shape[2], img.shape[3]

        # --- Step 1: get feature maps via baseline forward pass -----------
        baseline_logits = self.model(img)
        if class_idx is None:
            class_idx = baseline_logits.argmax(dim=-1).item()
        if self._activations is not None:
            acts = self._activations[0]
        elif hasattr(self.model, 'feature_map'):
            acts = self.model.feature_map(img)[0].detach().cpu()
        else:
            acts = torch.ones((1, 7, 7))
        C, h, w = acts.shape

        # --- Step 2-4: score each channel (batched for efficiency) --------
        # Subsample to top 32 channels on CPU for 10x faster execution
        channel_indices = list(range(C))
        if C > 32:
            # Pick top energy channels
            channel_energy = [acts[c].pow(2).sum().item() for c in range(C)]
            channel_indices = np.argsort(channel_energy)[-32:].tolist()

        scores = []
        masks = []
        for c in channel_indices:
            m = acts[c].unsqueeze(0).unsqueeze(0)          # (1,1,h,w)
            m = F.interpolate(m, size=(H, W), mode="bilinear",
                              align_corners=False)[0, 0]    # (H, W)
            lo, hi = m.min(), m.max()
            m = (m - lo) / (hi - lo + 1e-6)
            masks.append(m)
        masks = torch.stack(masks)                          # (C, H, W)

        # Batch channels to avoid OOM
        num_sel = len(channel_indices)
        for start in range(0, num_sel, self.max_batch):
            end = min(start + self.max_batch, num_sel)
            batch_masks = masks[start:end].to(device)      # (B, H, W)
            B = batch_masks.shape[0]

            # Masked inputs: broadcast img × each channel mask
            masked_inputs = (
                img.expand(B, -1, -1, -1) *
                batch_masks.unsqueeze(1)                   # (B, 1, H, W)
            )                                              # (B, 3, H, W)

            logits = self.model(masked_inputs)             # (B, num_classes)
            batch_scores = F.softmax(logits, dim=-1)[:, class_idx]  # (B,)
            scores.append(batch_scores.cpu())

        scores = torch.cat(scores)                         # (num_sel,)

        # --- Step 5: weighted sum of feature maps -------------------------
        # Upsample acts to input resolution
        acts_up = F.interpolate(
            acts.unsqueeze(0), size=(H, W),
            mode="bilinear", align_corners=False
        )[0]                                               # (C, H, W)

        acts_sel = acts_up[channel_indices]
        cam = (scores[:, None, None] * acts_sel).sum(dim=0)  # (H, W)
        cam = _normalize_heatmap(cam.numpy())

        return cam, class_idx


# -----------------------------------------------------------------------
# Saliency map (vanilla gradient w.r.t. input)
# -----------------------------------------------------------------------
def saliency_map(model, image_tensor: torch.Tensor,
                 class_idx: int = None) -> tuple:
    """
    Vanilla gradient saliency: the absolute gradient of the target class
    score with respect to the input image, collapsed to a single channel
    by taking the max across RGB.

    Returns: (H, W) numpy array in [0,1], predicted class_idx.
    """
    model.eval()
    img = image_tensor.clone().requires_grad_(True)
    logits = model(img)
    if class_idx is None:
        class_idx = logits.argmax(dim=-1).item()
    model.zero_grad()
    logits[0, class_idx].backward()
    sal = img.grad[0].abs().max(dim=0)[0].detach().cpu().numpy()
    return _normalize_heatmap(sal), class_idx


# -----------------------------------------------------------------------
# LIME explanation
# -----------------------------------------------------------------------
def lime_explanation(model, image_tensor: torch.Tensor,
                     class_idx: int = None,
                     num_samples: int = 512,
                     num_features: int = 10,
                     device=Config.DEVICE) -> tuple:
    """
    LIME (Local Interpretable Model-Agnostic Explanations).
    Segments the image into superpixels and perturbs them to estimate
    which regions are most important for the prediction.

    Returns:
        mask        : (H, W) float array in [0,1], positive = supports prediction
        class_idx   : int
        explanation : lime ImageExplanation object (for further queries)
    """
    if not LIME_AVAILABLE:
        return None, class_idx, None

    H, W = image_tensor.shape[2], image_tensor.shape[3]
    # LIME works on HWC uint8 images
    img_np = (_unnormalize(image_tensor[0]) * 255).astype(np.uint8)

    def predict_fn(images_batch):
        """LIME calls this with a numpy array (N, H, W, C) in [0,255]."""
        tensors = []
        for img in images_batch:
            t = torch.from_numpy(img.astype(np.float32) / 255.0)
            t = t.permute(2, 0, 1)                              # CHW
            t = (t - torch.tensor(_MEAN[:, None, None], dtype=torch.float32)) / \
                 torch.tensor(_STD[:, None, None],  dtype=torch.float32)
            tensors.append(t)
        batch = torch.stack(tensors).to(device)
        model.eval()
        with torch.no_grad():
            logits = model(batch)
        return F.softmax(logits, dim=-1).cpu().numpy()

    explainer = lime_image.LimeImageExplainer(verbose=False)
    try:
        explanation = explainer.explain_instance(
            img_np,
            predict_fn,
            top_labels=5,
            hide_color=0,
            num_samples=num_samples,
            segmentation_fn=SegmentationAlgorithm(
                "quickshift", kernel_size=4, max_dist=200, ratio=0.2
            ),
        )
    except Exception as e:
        print(f"      [LIME Error] {e}")
        return np.ones((H, W), dtype=np.float32), (class_idx if class_idx is not None else 0), None

    try:
        if class_idx is None or class_idx not in explanation.local_exp:
            if hasattr(explanation, "top_labels") and explanation.top_labels:
                target_lbl = explanation.top_labels[0]
            elif hasattr(explanation, "local_exp") and explanation.local_exp:
                target_lbl = list(explanation.local_exp.keys())[0]
            else:
                target_lbl = 0
        else:
            target_lbl = class_idx

        try:
            temp, mask_bool = explanation.get_image_and_mask(
                target_lbl,
                positive_only=True,
                num_features=num_features,
                hide_rest=False,
            )
        except Exception:
            if hasattr(explanation, "local_exp") and explanation.local_exp:
                target_lbl = list(explanation.local_exp.keys())[0]
                temp, mask_bool = explanation.get_image_and_mask(
                    target_lbl,
                    positive_only=False,
                    num_features=num_features,
                    hide_rest=False,
                )
            else:
                mask_bool = np.ones((H, W), dtype=bool)
    except Exception as e:
        print(f"      [LIME Error] {e}")
        mask_bool = np.ones((H, W), dtype=bool)
        target_lbl = class_idx if class_idx is not None else 0

    # Convert boolean mask to float heatmap [0,1]
    lime_mask = mask_bool.astype(np.float32)
    return lime_mask, target_lbl, explanation


# -----------------------------------------------------------------------
# Full explainability panel for one image
# -----------------------------------------------------------------------
def explain_prediction(model, proto_bank, image_tensor: torch.Tensor,
                        class_names=None, save_path: str = None,
                        use_lime: bool = Config.USE_LIME) -> dict:
    """
    Generates a 5-panel (or 4-panel if LIME disabled) explainability
    figure per image:
      [1] Original image + prediction
      [2] ScoreCAM overlay (gradient-free heatmap)
      [3] Saliency map
      [4] LIME superpixel explanation (if enabled)
      [5] Prototype similarity bar chart + uncertainty text

    Args:
        model        : FedMetaDermClientModel (eval mode)
        proto_bank   : PrototypeBank for this hospital
        image_tensor : (1, C, H, W) normalised, on CPU or GPU
        class_names  : list of class name strings
        save_path    : if provided, saves the figure here (PNG)
        use_lime     : also compute LIME (slower, model-agnostic)

    Returns:
        dict with prediction, confidence, uncertainty, prototype sims.
    """
    class_names = Config.CLASS_NAMES if class_names is None else class_names
    device = next(model.parameters()).device
    image_tensor = image_tensor.to(device)

    # -- ScoreCAM ---------------------------------------------------------
    scorer = ScoreCAM(model)
    cam, pred_idx = scorer(image_tensor)
    scorer.remove_hooks()

    # -- Saliency ---------------------------------------------------------
    sal, _ = saliency_map(model, image_tensor, class_idx=pred_idx)

    # -- Prototype similarity ---------------------------------------------
    with torch.no_grad():
        _, embedding = model(image_tensor, return_embedding=True)
    _, sims = proto_bank.classify_by_prototype(embedding)
    sims_np = sims[0].cpu().numpy()

    # -- MC-Dropout uncertainty -------------------------------------------
    mean_probs, entropy, mi, _ = mc_dropout_predict(
        model, image_tensor, T=Config.MC_DROPOUT_PASSES
    )
    confidence = mean_probs[0, pred_idx].item()

    # -- LIME (optional) --------------------------------------------------
    lime_mask = None
    if use_lime and LIME_AVAILABLE:
        lime_mask, _, _ = lime_explanation(
            model, image_tensor, class_idx=pred_idx, device=device
        )

    orig_img = _unnormalize(image_tensor[0])
    n_panels = 5 if (use_lime and lime_mask is not None) else 4
    fig, axes = plt.subplots(1, n_panels, figsize=(5 * n_panels, 5.5))
    fig.patch.set_facecolor("#1a1a2e")
    for ax in axes:
        ax.set_facecolor("#16213e")

    def _style(ax, title):
        ax.set_title(title, color="white", fontsize=10, pad=6)
        ax.axis("off")

    # Panel 1: original
    axes[0].imshow(orig_img)
    _style(axes[0],
           f"Input\nPred: {class_names[pred_idx]}\nConf: {confidence:.2f}")

    # Panel 2: ScoreCAM overlay
    axes[1].imshow(orig_img)
    axes[1].imshow(cam, cmap="inferno", alpha=0.55)
    _style(axes[1], "ScoreCAM\n(gradient-free)")

    # Panel 3: saliency
    axes[2].imshow(sal, cmap="plasma")
    _style(axes[2], "Saliency Map\n(input gradient)")

    panel = 3
    # Panel 4: LIME (if available)
    if use_lime and lime_mask is not None:
        axes[panel].imshow(orig_img)
        axes[panel].imshow(lime_mask, cmap="Greens", alpha=0.55)
        _style(axes[panel], "LIME\n(superpixel, model-agnostic)")
        panel += 1

    # Panel 4/5: Prototype similarity
    bar_colors = ["#e94560" if i == pred_idx else "#0f3460"
                  for i in range(len(class_names))]
    axes[panel].barh(class_names, sims_np, color=bar_colors)
    axes[panel].tick_params(colors="white", labelsize=7)
    axes[panel].set_xlabel("cosine similarity", color="white", fontsize=9)
    _style(axes[panel], "Prototype Similarity")

    fig.suptitle(
        f"Predictive Entropy: {entropy.item():.3f}  |  "
        f"Epistemic (BALD): {mi.item():.3f}",
        color="white", fontsize=11, y=1.01
    )
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
        plt.close(fig)
    else:
        plt.show()

    return {
        "predicted_class": class_names[pred_idx],
        "confidence": confidence,
        "predictive_entropy": entropy.item(),
        "epistemic_uncertainty": mi.item(),
        "prototype_similarities": dict(zip(class_names, sims_np.tolist())),
    }


# -----------------------------------------------------------------------
# Batch explainability runner
# -----------------------------------------------------------------------
def run_explainability_batch(model, proto_bank, val_loader, out_dir: str,
                              num_samples: int = Config.NUM_EXPLAIN_SAMPLES,
                              use_lime: bool = Config.USE_LIME) -> list:
    """Runs explain_prediction on a subset of validation images and saves figures."""
    os.makedirs(out_dir, exist_ok=True)
    device = next(model.parameters()).device
    count, reports = 0, []

    for images, labels in val_loader:
        for i in range(images.size(0)):
            if count >= num_samples:
                return reports
            img = images[i:i + 1].to(device)
            save_path = os.path.join(out_dir, f"explain_{count:03d}.png")
            report = explain_prediction(model, proto_bank, img,
                                        save_path=save_path, use_lime=use_lime)
            report["true_class"] = Config.CLASS_NAMES[labels[i].item()]
            reports.append(report)
            count += 1
            print(f"  [Explain] {count}/{num_samples}  saved -> {save_path}")

    return reports
