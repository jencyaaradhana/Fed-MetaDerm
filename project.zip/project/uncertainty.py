"""
uncertainty.py -- MC-dropout (Module 7, Eq. 12), FIXED.

Bug in the old version: model.train() switched BatchNorm to batch statistics
(and corrupted running stats) during the T stochastic passes. Now only Dropout
layers are stochastic; everything else stays in eval mode, and the model's
original mode is restored afterwards.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


def _enable_dropout_only(model: nn.Module):
    model.eval()
    for m in model.modules():
        if isinstance(m, (nn.Dropout, nn.Dropout2d, nn.Dropout3d)):
            m.train()


def mc_dropout_predict(model: nn.Module, images: torch.Tensor, T: int = 10):
    """Returns (mean_probs, entropy H, epistemic = mutual information (BALD), var_probs).
    entropy  = -sum p_bar log p_bar          (predictive uncertainty, paper Eq. 12)
    epistemic= H[p_bar] - mean_t H[p_t]       (mutual information)
    """
    was_training = model.training
    _enable_dropout_only(model)
    device = next(model.parameters()).device
    images = images.to(device)
    probs = []
    with torch.no_grad():
        for _ in range(T):
            probs.append(F.softmax(model(images), dim=-1))
    model.train(was_training)

    P = torch.stack(probs)                                   # [T,B,C]
    mean_probs = P.mean(0)
    entropy = -(mean_probs * torch.log(mean_probs + 1e-8)).sum(-1)
    exp_entropy = -(P * torch.log(P + 1e-8)).sum(-1).mean(0)
    mutual_info = (entropy - exp_entropy).clamp_min(0)
    return mean_probs, entropy, mutual_info, P.var(0)


def estimate_uncertainty_mc_dropout(model, images, num_samples=10, device="cpu"):
    return mc_dropout_predict(model, images, T=num_samples)


def compute_evidential_loss(alpha: torch.Tensor, labels: torch.Tensor, num_classes=None):
    S = alpha.sum(-1, keepdim=True)
    y = F.one_hot(labels, alpha.size(-1)).float()
    return ((y - alpha / S) ** 2 + alpha * (S - alpha) / (S * S * (S + 1))).sum(-1).mean()
