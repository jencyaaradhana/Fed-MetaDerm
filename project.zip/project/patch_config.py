import os, re

cfg_path = r"E:\final pro\project\project (6)\project (6)\project\config.py"
with open(cfg_path, "rb") as f:
    src = f.read().decode("utf-8")

OLD = "    KD_EPOCHS        = 3\r\n"
NEW = "    KD_EPOCHS        = 3\r\n    CHECKPOINT_INTERVAL = 15   # save a periodic .pt every N global epochs\r\n"

assert OLD in src, "KD_EPOCHS line not found"
src = src.replace(OLD, NEW, 1)

with open(cfg_path, "wb") as f:
    f.write(src.encode("utf-8"))
print("config.py patched")
