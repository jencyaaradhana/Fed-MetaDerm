"""
pdf_report.py
-------------
Utility for generating publication-quality PDF clinical diagnostic reports
for Meta-XPFL (Fed-MetaDerm).
"""

import io
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT


def generate_pdf_report(report_data: dict) -> bytes:
    """
    Generates a PDF clinical report buffer from diagnostic report_data dictionary.
    Returns raw PDF bytes for Streamlit st.download_button.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#1565C0'),
        alignment=TA_CENTER
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor('#555555'),
        alignment=TA_CENTER
    )
    heading_style = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=15,
        textColor=colors.HexColor('#1E88E5'),
        spaceBefore=8,
        spaceAfter=4
    )
    body_style = ParagraphStyle(
        'BodyTextCustom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=12.5,
        textColor=colors.HexColor('#222222')
    )
    bold_style = ParagraphStyle(
        'BoldBody',
        parent=body_style,
        fontName='Helvetica-Bold'
    )

    story = []

    # Title Banner
    story.append(Paragraph("🩺 Meta-XPFL Clinical AI Diagnostic Report", title_style))
    story.append(Paragraph("Explainable & Personalized Federated Meta-Learning for Skin Cancer Diagnosis", subtitle_style))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#1565C0'), spaceAfter=12))

    # Patient & Metadata Table
    patient_meta = report_data.get("patient_metadata", {})
    symptoms = patient_meta.get("symptoms", {})

    symp_list = []
    if symptoms.get("rapid_growth"): symp_list.append("Recent Rapid Growth")
    if symptoms.get("bleeding"): symp_list.append("Spontaneous Bleeding/Itching")
    if symptoms.get("asymmetric"): symp_list.append("Multi-colored / Asymmetric")
    symp_str = ", ".join(symp_list) if symp_list else "None reported"

    patient_table_data = [
        [Paragraph("<b>📋 Patient & Metadata Profile</b>", bold_style), Paragraph("<b>🔒 Federated System Context</b>", bold_style)],
        [
            Paragraph(f"<b>Patient Age:</b> {patient_meta.get('age', 'N/A')} years<br/>"
                      f"<b>Biological Sex:</b> {patient_meta.get('sex', 'N/A')}<br/>"
                      f"<b>Anatomical Location:</b> {patient_meta.get('anatomical_site', 'N/A')}<br/>"
                      f"<b>Uploaded Image:</b> {report_data.get('filename', 'N/A')}<br/>"
                      f"<b>Symptoms:</b> {symp_str}", body_style),
            Paragraph(f"<b>Framework:</b> Meta-XPFL (Fed-MetaDerm)<br/>"
                      f"<b>Federated Nodes:</b> 4 Hospitals (HAM10000, ISIC, Derm7pt, SD198)<br/>"
                      f"<b>Privacy Budget:</b> Differential Privacy (&epsilon; = 1.0)<br/>"
                      f"<b>Encryption:</b> Paillier Homomorphic + SMPC<br/>"
                      f"<b>Consensus:</b> PBFT Verified (4/4 Votes)", body_style)
        ]
    ]

    t_meta = Table(patient_table_data, colWidths=[270, 270])
    t_meta.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (1, 0), colors.HexColor('#E3F2FD')),
        ('TEXTCOLOR', (0, 0), (1, 0), colors.HexColor('#1565C0')),
        ('BACKGROUND', (0, 1), (1, 1), colors.HexColor('#F9F9F9')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#BBDEFB')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E0E0E0')),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_meta)
    story.append(Spacer(1, 10))

    # Diagnostic Findings Card
    diag_name = str(report_data.get("predicted_diagnosis", "UNKNOWN")).upper()
    conf = float(report_data.get("confidence_percentage", 0.0))
    unc = float(report_data.get("predictive_uncertainty_entropy", 0.0))
    risk = float(report_data.get("composite_risk_score", 0.0))
    risk_badge = "HIGH RISK" if risk > 60 else "LOW RISK"
    badge_fg = "#C62828" if risk > 60 else "#2E7D32"

    story.append(Paragraph("🔬 Diagnostic Findings & AI Risk Assessment", heading_style))

    diag_box_data = [
        [
            Paragraph(f"<font color='#1565C0' size=13><b>PREDICTED DIAGNOSIS: {diag_name}</b></font>", body_style),
            Paragraph(f"<font color='{badge_fg}' size=11><b>[{risk_badge}]</b></font>", ParagraphStyle('R', parent=body_style, alignment=TA_RIGHT))
        ],
        [
            Paragraph(f"<b>Model Prediction Confidence:</b> {conf:.2f}%<br/>"
                      f"<b>Predictive Uncertainty (Entropy):</b> {unc:.4f}<br/>"
                      f"<b>Composite Clinical Risk Index:</b> {risk:.1f} / 100", body_style),
            Paragraph(f"<b>Inference Architecture:</b><br/>"
                      f"Dual-stage EfficientNet-B0 augmented with Spatial Self-Attention & Monte Carlo Epistemic Uncertainty Estimation.", body_style)
        ]
    ]

    t_diag = Table(diag_box_data, colWidths=[270, 270])
    t_diag.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F0F7FF')),
        ('BOX', (0, 0), (-1, -1), 1.2, colors.HexColor('#1E88E5')),
        ('PADDING', (0, 0), (-1, -1), 8),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(t_diag)
    story.append(Spacer(1, 10))

    # Top-5 Differential Diagnosis Table
    story.append(Paragraph("📊 Top-5 Differential Diagnostic Probabilities", heading_style))
    top5 = report_data.get("top_5_probabilities", {})

    table_data = [[Paragraph("<b>Diagnostic Class Name</b>", bold_style), Paragraph("<b>Model Probability (%)</b>", bold_style)]]
    for cls_name, prob_val in top5.items():
        table_data.append([
            Paragraph(str(cls_name).title(), body_style),
            Paragraph(f"{prob_val:.2f}%", body_style)
        ])

    t_top5 = Table(table_data, colWidths=[380, 160])
    t_top5.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (1, 0), colors.HexColor('#1E88E5')),
        ('TEXTCOLOR', (0, 0), (1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CCCCCC')),
        ('PADDING', (0, 0), (-1, -1), 5),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8F9FA')]),
    ]))
    story.append(t_top5)
    story.append(Spacer(1, 15))

    # Disclaimer Footer
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#CCCCCC'), spaceAfter=6))
    footer_text = Paragraph(
        "<font color='#777777' size=7.5><i><b>Clinical Notice:</b> This automated diagnostic report was generated by the Meta-XPFL Privacy-Preserving AI System for research and clinical decision support. "
        "It is designed to assist medical practitioners and must be correlated with clinical observation and biopsy confirmation.</i></font>",
        ParagraphStyle('Footer', parent=styles['Normal'], alignment=TA_CENTER)
    )
    story.append(footer_text)

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
