"""
preprocessing.py  --  Section IV-B of the paper
-----------------------------------------------
1. Artifact removal : DullRazor-style hair removal (morphological black-hat at
                       several orientations -> mask -> inpainting).
2. Illumination     : CLAHE on the L channel in CIE-LAB (8x8 tiles, clip 2.0).

Usage
    from preprocessing import DermPreprocess
    pre = DermPreprocess()              # PIL.Image -> PIL.Image
    img = pre(Image.open(path).convert("RGB"))
"""
import hashlib
import os

import cv2
import numpy as np
from PIL import Image


def _line_kernel(length: int, angle_deg: float) -> np.ndarray:
    """Binary line structuring element of given length and orientation."""
    k = np.zeros((length, length), np.uint8)
    c = length // 2
    a = np.deg2rad(angle_deg)
    dx, dy = np.cos(a) * c, np.sin(a) * c
    cv2.line(k, (int(round(c - dx)), int(round(c - dy))),
             (int(round(c + dx)), int(round(c + dy))), 1, 1)
    return k


def hair_mask(rgb: np.ndarray, thresh: int = 20) -> np.ndarray:
    """Binary mask (uint8 0/255) of thin dark structures (hairs, ruler ticks)."""
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    # structuring-element length scaled to image size (17 px at 600 px width)
    length = int(max(7, round(17 * max(gray.shape) / 600.0))) | 1
    resp = np.zeros_like(gray)
    for ang in (0, 45, 90, 135):
        bh = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, _line_kernel(length, ang))
        resp = np.maximum(resp, bh)
    resp = cv2.GaussianBlur(resp, (3, 3), 0)
    _, mask = cv2.threshold(resp, thresh, 255, cv2.THRESH_BINARY)
    return cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)


def remove_hair(rgb: np.ndarray, thresh: int = 20, max_mask_fraction: float = 0.15,
                inpaint_radius: int = 3) -> np.ndarray:
    """DullRazor-style hair removal. Skips the image if the mask is implausibly
    large (that means the detector fired on lesion texture, not on hairs)."""
    mask = hair_mask(rgb, thresh)
    if mask.mean() / 255.0 > max_mask_fraction or mask.max() == 0:
        return rgb
    return cv2.inpaint(rgb, mask, inpaint_radius, cv2.INPAINT_TELEA)


def apply_clahe(rgb: np.ndarray, clip_limit: float = 2.0, tiles: int = 8) -> np.ndarray:
    """CLAHE on the luminance channel in CIE-LAB."""
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(tiles, tiles))
    lab[..., 0] = clahe.apply(lab[..., 0])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)


class DermPreprocess:
    """Callable: PIL RGB image -> preprocessed PIL RGB image.

    work_size : the long side is shrunk to this before processing (speed);
                the dataset transform resizes to the network size afterwards.
    cache_dir : if given, processed images are cached on disk keyed by path.
    """
    def __init__(self, hair=True, clahe=True, work_size=320, cache_dir=None):
        self.hair, self.clahe, self.work_size = hair, clahe, work_size
        self.cache_dir = cache_dir
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)

    def _process(self, img: Image.Image) -> Image.Image:
        w, h = img.size
        s = self.work_size / max(w, h)
        if s < 1.0:
            img = img.resize((max(1, int(w * s)), max(1, int(h * s))), Image.BILINEAR)
        arr = np.asarray(img.convert("RGB"))
        if self.hair:
            arr = remove_hair(arr)
        if self.clahe:
            arr = apply_clahe(arr)
        return Image.fromarray(arr)

    def __call__(self, img: Image.Image, key: str = None) -> Image.Image:
        if self.cache_dir and key:
            f = os.path.join(self.cache_dir,
                             hashlib.md5(key.encode()).hexdigest() + ".png")
            if os.path.exists(f):
                return Image.open(f).convert("RGB")
            out = self._process(img)
            out.save(f)
            return out
        return self._process(img)
